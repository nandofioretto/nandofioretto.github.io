/* Multifactorial Microarray data Class
 *
 * Load Syntax:
 * --microarray-multifactorial PATH_OF_DATA
*/

#ifndef GNOFF_MULTIFACTORIAL_DATA_H
#define GNOFF_MULTIFACTORIAL_DATA_H

#include <iostream>
#include <fstream>
#include <string>
#include "microarray.h"

class Multifactorial : public Microarray {
 public:
  Multifactorial (int argc, char* argv[], int& parse_pos);
  Multifactorial (std::string input);
  void init (std::string data_path, int model_no=1);
  void dump() const; 
};

#endif
