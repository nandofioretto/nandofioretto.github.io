/* Time Serie Microarray data Class
 * The first column of the matrix data holds the time stamp when the measurement
 * occurred; the other columns hold the normalized RNA-level measurement for 
 * each gene.
 *
 * Load Syntax:
 * --microarray-timeserie PATH_OF_DATA NUMOF_EXPERIMENTS
*/

#ifndef GNOFF_TIMESERIE_DATA_H
#define GNOFF_TIMESERIE_DATA_H

#include "globals.h"
#include "microarray.h"

class Timeserie : public Microarray {
 private:
  std::vector <double> times;
  
 public:
  Timeserie (int argc, char* argv[], int& parse_pos);
  Timeserie (std::string input, int model_no);
  Timeserie (std::vector< std::vector< double > > _data, std::vector< double > times);
  Timeserie (const Timeserie& other);
  Timeserie& operator= (const Timeserie& other);

  void init (std::string input, int model_no);
  void dump() const; 

  
  double get_value (int gene, int time) const;
  double get_time  (int pos) const;
  size_t numof_time_steps () const;
  
};

#endif
