/* WILDTYPES Microarray data Class
 * Load Syntax:
 * --microarray-wildtypes PATH_OF_DATA
*/

#ifndef GNOFF_WILDTYPES_DATA_H
#define GNOFF_WILDTYPES_DATA_H

#include "globals.h"
#include "microarray.h"

class Wildtypes : public Microarray {
 public:
  Wildtypes (int argc, char* argv[], int& parse_pos);
  Wildtypes (std::string data_path);
  void init (std::string data_path, int model_no=1);
  void dump() const; 
};

#endif
