#setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/scripts")
source("func_analysis.R")
source("func_datasets.R")
require(infotheo)
require(minet) # For ARACNE, CLR, MRNET and validation
require(lattice)
require(igraph)
require(Matrix)
require(c3net)
require(bc3net)

###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_C3net <- function ( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5), 
dataset=c("mf", "ko", "all"), sym=F, path_out=NULL, exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	data <- get_data( path.dataset, dataset )
	gold <- get_goldstd( path.dataset, names(data) )
	pred <- c3net( t(data) )
	if( !is.null(path_out) ) save_prediction(pred, path_out)
	tbl = ccn_validate(pred, gold, sym)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}#-

ccn_BC3net <- function ( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5), 
dataset=c("mf", "ko", "all"), sym=F, path_out=NULL, exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	data <- get_data( path.dataset, dataset )
	gold <- get_goldstd( path.dataset, names(data) )
	pred <- bc3net( t(data), igraph=FALSE )
	if( !is.null(path_out) ) save_prediction(pred, path_out)
	tbl = ccn_validate(pred, gold, sym)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}#-