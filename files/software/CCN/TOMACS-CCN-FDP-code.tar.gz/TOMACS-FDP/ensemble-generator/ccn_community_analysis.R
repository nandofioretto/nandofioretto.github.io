setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/ensemble-generator/")
source("func_analysis.R")
source("func_datasets.R")

require(infotheo)
require(minet) # For ARACNE, CLR, MRNET and validation


	P <- read_data.frame_predictions(gene_network, network_no, size, dataset, methods, rank=T)
	D <- P$data
	I <- P$info
	n <- length(D)
	for ( i in 1:(n-2))
	{
		for ( j in (i+1):(n-1))
		{
			for( k in (j+1):n)
			{
			s <- sum(merge(merge(D[[i]][1:148,], D[[j]][1:148,],
						by=c("parent", "child", "value.gold") ),
						D[[k]][1:148,],
						by=c("parent", "child", "value.gold") )$value.gold)
					
				r <- sum(D[[i]][1:148,]$value.gold)
				r <- r + sum(D[[j]][1:148,]$value.gold) 
				r <- r + sum(D[[k]][1:148,]$value.gold) 
				cat("methods: ", i, " - ",j, " - ", k, ":", (r - s) , "\n")
			}
		}
	}


ccn.rank_avg <- function(gene_network, network_no, size, dataset, methods=c("pearson", "spearman", "kendall", "aracne", "mrnet", "clr", "c3net", "bc3net", "genie3", "tigress", "inferelator", "anova", "gln" ))
{
	genes <- read_data.genes_id(gene_network, network_no, size)
	path.dataset <- get_data.path(gene_network, size, network_no)
	gold <- get_goldstd( path.dataset, genes )

	P <- read_data.frame_predictions(gene_network, network_no, size, dataset, methods, rank=T)
	D <- P$data
	n <- length(D)
	for ( i in 1:n)
	{
		D[[i]] <- D[[i]][-4]
	}
	R <- capture.output(
		Reduce(function(...) merge(..., by=c("parent", "child", "value.gold"), all=T), D),
		file="/dev/null")
	A <- R[, 1:4]
	for( i in 1:nrow(R))
	{
		s <- mean(t(R[i, 4:length(R)]))
		A[i, 4] <- s
	}
	names(A) <- c("parent", "child", "gold", "rank")
	# A <- A[with(A, order(rank)),] # order
	pred <- prediction.as_matrix( A[-3], genes )
	pred = abs(pred - max(pred) )
	tbl = ccn_validate(pred, gold)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}