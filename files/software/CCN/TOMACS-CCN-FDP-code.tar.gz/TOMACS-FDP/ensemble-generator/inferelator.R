#setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/scripts")
require(minet) # For validation
require(Matrix)
suppressMessages(require(multicore,quietly=TRUE))
suppressMessages(require(elasticnet,quietly=TRUE))
suppressMessages(require(inline,quietly=TRUE))
suppressMessages(require(samr,quietly=TRUE))
source("func_analysis.R")
source("func_datasets.R")
source("Inferelator/init_util.R")
source("Inferelator/utils.R")
source("Inferelator/larsUtil.R")
source("Inferelator/bootstrapUtil.R")
source("Inferelator/d5_util.R")
source("Inferelator/prepare_data.R")
source("Inferelator/clr.R")
source("Inferelator/inferelator_utils.R")  
  
  
###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_Inferelator <- function 
( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5),  
  dataset=c("mf", "ko", "all"), sym=F, path_out=NULL, 
  bootstraps=10, exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
  	path.data <- NA
	if(dataset == "mf"){ path.data <- paste(path.dataset, file.mf, sep ="/")
	} else if( dataset == "ko"){ path.data <- paste(path.dataset, file.ko, sep ="/")
	}else if( dataset == "all") {path.data <- paste(path.dataset, file.all, sep ="/") }
    PARAMS <- get.params.PARAMS (path.data, n_bootstraps=bootstraps)
    INPUT <- get.params.INPUT( PARAMS )
    genes <-read_data.genes_id(gene_network, network_no, size, exp) 
	gold <- get_goldstd( path.dataset, genes )
 	#pred <- capture.output(inferelator_pipeline(INPUT, PARAMS), file="/dev/null")
 	pred <- inferelator_pipeline(INPUT, PARAMS)
	if( !is.null(path_out) ) save_prediction(pred, path_out)

  	tbl = ccn_validate(pred, gold, sym)
  	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}

###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_Inferelator.v2 <- function 
( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5),  
  dataset=c("mf", "ko", "all"), sym=F, path_out=NULL,
  bootstraps=10)
{ 
	exec.preproc="preprocess"
	path.exec.preproc <- file.path("preprocess", exec.preproc)
	path.file.out     <- file.path("preprocess", "pred")
    path.dataset <- get_data.path(gene_network, size, network_no)
	path.mf <- paste(path.dataset, file.mf, sep ="/")
	path.ko <- paste(path.dataset, file.ko, sep ="/")
    
    command = path.exec.preproc
    if(dataset == "mf" | dataset == "all")
    	command = paste( command, "--microarray-mf", path.mf )
  	if(dataset == "ko" | dataset == "all")
    	command  = paste( command, "--microarray-ko", path.ko )
	command = paste( command, "--path-out", path.file.out)
	system(command)   
		
    data.exp = paste( path.file.out, "expression_data.tsv", sep="_")
	data.tfs = NA  ## not working!
	# data.tfs = paste( path.file.out, "transcription_factors.tsv", sep="_")
	data.meta = paste( path.file.out, "chip_features.tsv", sep="_")
    PARAMS <- get.params.PARAMS (data.exp, data.tfs, data.meta, n_bootstraps=1)
    INPUT <- get.params.INPUT( PARAMS )
	cat("jere2\n")
    genes <-read_data.genes_id(gene_network, network_no, size) 
	gold <- get_goldstd( path.dataset, genes )

 	pred <- inferelator_pipeline(INPUT, PARAMS)
	if( !is.null(path_out) ) save_prediction(pred, path_out)

  tbl = ccn_validate(pred, gold, sym)
  return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}
