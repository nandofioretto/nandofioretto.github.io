setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/ensemble-generator/")
source("func_analysis.R")
source("func_datasets.R")
require(infotheo)
require(minet) # For ARACNE, CLR, MRNET and validation
require(plyr)
require(gtools)


ccn_analysis.evaluate <- function(
gene_networks = TRAINING.networks,
network_no    = TRAINING.net_ids, 
size          = TRAINING.size, 
dataset       = TRAINING.datasets,
methods       = TRAINING.methods,
path.out=NULL)
{
	res.table <- data.frame()
	for( net in gene_networks ) 
	{
		for( k in network_no ) 
		{
			path.dataset <- get_data.path(net, size, k)	
			genes <- read_data.genes_id(net, k, size)		
			gold <- get_goldstd( path.dataset, genes )
			for( ds in dataset )
			{
				for( met in methods )
				{
					pairs <- read_data.prediction(net, k, size, met, ds)
					pred <- prediction.as_matrix( pairs, genes )
					tbl = ccn_validate(pred, gold)
					res.table <- rbind( res.table, cbind(met, net, size, k, ds, round(auc.roc(tbl), 4), round(auc.pr(tbl),4) ))	
				}
			}
		}
	}
	if( !is.null(path.out) )
		write.table( res.table, quote=FALSE, row.names=FALSE, col.names=TRUE, 
			file=file.path(path.out, "results.txt"), sep="\t" )

	names( res.table ) <- c("method", "network", "size", "net_id", "data", "auroc", "auprc")
	return (res.table)
}



## In preprocess generate the powerset of methods 
## couting the TP and FP in the intersection and union for each! 
## later we can recycle this information
ccn_analysis.get_best_set <- function(gene_network, network_no, size, dataset, methods=METHODS, nbins, bin)
{
	P <- read_data.frame_predictions(gene_network, network_no, size, dataset, methods, rank=T)
	n <- length(methods)
	q <- (length(P$data[[1]][,1]) / nbins)
	stopifnot( bin > 0 & bin <= nbins )
	Qa = (bin-1)*q + 1; Qb = (bin)*q	
	best.score = -Inf; best.p = 0

	path.dataset <- get_data.path(gene_network, size, network_no)	
	genes <- read_data.genes_id(gene_network, network_no, size)		
	gold <- get_goldstd( path.dataset, genes )

	
	Perms <- permutations(2, n, c(T,F),repeats.allowed=TRUE)
	cat("idx\t")
	for( i in 1:n)	cat(substr(methods[i],1,5), '\t') 
	cat("TP_Un\tFP_In\tscore\tccn_auc\tccn_pr\n")

	for ( p in 2:nrow(Perms) ) # Scan all the subsets of (size k) in the power set
	{
		if( sum(Perms[p,]) <= 1 ) next
		cat(p,"\t")
		TP = 0; FP = 0
		all_edges = NULL
		for( i in 1:n )
		{
			cat(Perms[p,i], "\t")
			if( Perms[p,i] ) 
			{
				all_edges <- rbind( all_edges, P$data[[ i ]][Qa:Qb,] )
			}
		}
		D <-ddply( all_edges, .(parent, child), summarize, 
				sum_tp = sum(value.gold==1), sum_fp = sum(value.gold==0) )
		# count the number of TP in the Union
		TP = sum( D$sum_tp > 0 )
		# count the number of FP weighted by their number of methods contribuiting 
		# at the intersection: w_2 * s_1 \cap s2 .... + w_3 * s_1 \cap s2 \cap
		# s3 ... 
		FP = sum(D$sum_fp) - sum(D$sum_fp == 1)
		#compute Community network rank score
		B <-ddply( all_edges, .(parent, child, value.gold), summarize,  r=mean(rank) )
		B = prediction.as_matrix(B[-3], genes)
		B = 1/B; B[which(B == Inf ) ] = 0
		CCN.rank <- ccn_validate(B, gold)

		cat(sprintf("%5d\t%5d\t%5d\t%.4f\t%.4f\n", TP, FP, (TP-FP), auc.roc( CCN.rank ), auc.pr( CCN.rank )))
		if( best.score < (TP-FP))
		{
			best.score <- (TP - FP)
			best.p <- p
		}
	}
	# Retrieve best set
	cat("best idx = ", best.p , "\n")
	return( P$info$method[Perms[best.p, ]] )
}


# find the number of edges s.t AB TP is minimized for (within the intersection) upper buckets (20-50) and that individually A and B are maximized
# 
ccn_analysis.stats <- function( gene_network, network_no, size, dataset, methods=METHODS, nbins=10 )
{
  AllStats <- list()
   for( net in gene_network ) 
   {
     for( N in network_no )
	 {
	   for( ds in dataset )
	   {
	   	  cat("**** Network: ", net, N, " (100) data = ", ds, "****\n")
	   	  for( bin in 1:nbins )
	   	  {
	   	  	cat("Bin: ", bin, "/", nbins, "\n")
		    ccn_analysis.get_best_set(net, N, size, ds, methods, nbins, bin)
	   	  }
	   }
	 }
   }
}


# access to array with:
# pred[which( (pred.norm < 0.1 & pred.norm > 0), arr.ind=TRUE)]
normalize <- function( pred )
{	
	return( pred / max(pred) )
}
