#setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/scripts")
source("func_analysis.R")
source("func_datasets.R")
source("gln/Decide_Quantization_Level.R")
source("gln/d5c4-sort-edges.R")

require(infotheo)
require(minet) # For validation

###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_Gln <- function( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5), 
dataset=c("mf", "ko", "all"), sym=F, path_out=NULL , exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	data <- get_data( path.dataset, dataset )
	gold <- get_goldstd( path.dataset, names(data) )
	pred <- c_Gln(data)
	gold <- get_goldstd( path.dataset, rownames(pred) )
	if( !is.null(path_out) ) save_prediction(pred, path_out)
	tbl = ccn_validate(pred, gold, sym)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}#-


#DREAM 8 main script
#created by Yang Zhang 2013.9
c_Gln <- function(data)
{
	GLNProgram <- "gln/glnsp"
	rawDataMatrix <- data
	nodenum <- ncol(rawDataMatrix)
	qDataMatrix <- matrix(,nrow(rawDataMatrix), nodenum)
	geneNames <- colnames(rawDataMatrix)
	TCF <- "gln/insilico.TCF"
	RedoFlag <- FALSE
	FuncResult <- "gln/P5SummarizedResults.txt"

	#step1: quantize data and save into TCF
  	qlevels <- findClusterLevel(rawDataMatrix, "gln/mclustresult.txt")
  
 	for(index in 1:nodenum)
  	{
    	qDataMatrix[,index] <-  Ckmeans.1d.dp(rawDataMatrix[,index], qlevels[index])$cluster - 1
  	}
  
	write.table("TRAJECTORY_VER2", TCF, col.names=F, row.names=F, quote=F)
	write.table(paste(1,nodenum,0), TCF, col.names=F, row.names=F, quote=F, append=T)
	write.table(t(qlevels), TCF, col.names=F, row.names=F, quote=F, append=T)
	write.table(t(geneNames), TCF, col.names=F, row.names=F, quote=F, append=T)
	write.table(nrow(qDataMatrix), TCF, col.names=F, row.names=F, quote=F, append=T)
	write.table(qDataMatrix, TCF, col.names=F, row.names=F, quote=F, append=T)

	#step2: run functional GLN and save result
	if(file.exists(FuncResult))
	{
  		unlink(FuncResult)
	}

	cmd <- paste(GLNProgram, " -M estimation -R ",  TCF,  " -A 1 -K 0 -J 0 -P 5 -p 1 -X gln/P5", " > /dev/null ", sep="")
	system(cmd)

	#step3: sort edges and generate final result
	capture.output(Sort.Edges.Fast(FuncResult, "gln/insilicosorted.txt" ,10000, ""), file="/dev/null")
	sortedFinal <- read.table("gln/insilicosorted.txt")
	sortedFinal[,3] <- (sortedFinal[,3] - min(sortedFinal[,3])) / (max(sortedFinal[,3])-min(sortedFinal[,3]))


	ngenes = length(geneNames)
	pred = matrix(0, nrow=ngenes, ncol=ngenes, dimnames=list(geneNames, geneNames))
	N <- length(rownames(sortedFinal))
	for( i in 1:N)
	{
		x <- sortedFinal[i, 1]
		y <- sortedFinal[i, 2]
		pred[as.character(x), as.character(y)] <- sortedFinal[i, 3]
	}
	return (pred)
}
