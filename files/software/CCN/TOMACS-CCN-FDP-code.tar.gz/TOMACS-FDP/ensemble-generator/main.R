source("func_analysis.R")
source("func_datasets.R")

source("anova.R")
source("c3net.R")
source("correlation.R")
source("genie3.R")
source("inferelator.R")
source("mi.R")
source("tigress.R")
source("gln.R")

main <- function()
{
	ccn_training()
	ccn_DREAM3()
	ccn_DREAM4()
}

ccn_training <- function( 
gene_networks = TRAINING.networks,
network_no    = TRAINING.net_ids, 
size          = TRAINING.size, 
dataset       = TRAINING.datasets,
methods       = TRAINING.methods )
{
	res.table <- data.frame()
	for( met in methods ) 
	{
		cat( "\nMethod: ", met )
		for( net in gene_networks ) 
		{
			for( k in network_no ) 
			{
				for( ds in dataset )
				{
					cat(" Network:", net, " #", k, "- data: ", ds )
					fn <- paste( net, k, "_size_", size, "_met_", met, "_data_", ds, ".tsv", sep="")
					file = paste(path.out.training, fn, sep="/")
					if( met == "pearson") 
						res <- ccn_Correlation( net, size, k, ds, met="pearson", path_out=file )
					else if( met == "spearman") 
						res <- ccn_Correlation( net, size, k, ds, met="spearman", path_out=file )
					else if( met == "kendall") 
						res <- ccn_Correlation( net, size, k, ds, met="kendall", path_out=file )
					else if( met == "aracne")
						res <- ccn_Aracne( net, size, k, ds, path_out=file )
					else if( met == "mrnet") 
						res <- ccn_Mrnet( net, size, k, ds, path_out=file )
					else if( met == "clr") 
						res <- ccn_Clr( net, size, k, ds, path_out=file )
					else if( met == "c3net") 
						res <- ccn_C3net( net, size, k, ds, path_out=file )
					else if( met == "bc3net") 
						res <- ccn_BC3net( net, size, k, ds, path_out=file )
					else if( met == "genie3" ) 
						res <- ccn_Genie3( net, size, k, ds, path_out=file )
					else if( met == "tigress" ) 
						res <- ccn_Tigress( net, size, k, ds, path_out=file )
					else if( met == "inferelator" ) 
						res <- ccn_Inferelator( net, size, k, ds, path_out=file )
					else if( met == "anova" ) 
						res <- ccn_Anova( net, size, k, ds, path_out=file )
					else if( met =="gln" )
						res <- ccn_Gln( net, size, k, ds, path_out=file)
					cat(" :\t", res$auc.roc.tbl., " ", res$auc.pr.tbl., "\n")
					res.table <- rbind( res.table, cbind(met, net, size, k, ds, round(res, 4) ))	
				}
			}
		}
	}
	names( res.table ) <- c("method", "network", "size", "net_id", "data", "auroc", "auprc")
	write.table( res.table, quote=FALSE, row.names=FALSE, col.names=TRUE, 
			file=file.path(path.out.training, "results-training.txt"), sep="\t" )
	return(res.table)
}

ccn_DREAM3 <- function( 
gene_networks = c("Ecoli1", "Ecoli2", "Yeast1", "Yeast2", "Yeast3"),
size          = 100, 
dataset       = TRAINING.datasets,
methods       = TRAINING.methods )
{
	res.table <- data.frame()
	for( met in methods ) 
	{
		cat( "\nMethod: ", met, '\n')
		for( net in gene_networks ) 
		{
			for( ds in dataset )
			{
				cat(" Network:", net, " #", "- data: ", ds )
				fn <- paste( net, "_size_", size, "_met_", met, "_data_", ds, ".tsv", sep="")
				file = paste(path.out.DREAM3, fn, sep="/")
				if( met == "pearson") 
					res <- ccn_Correlation( net, size, 0, ds, met="pearson", path_out=file, exp='DREAM3' )
				else if( met == "spearman") 
					res <- ccn_Correlation( net, size, 0, ds, met="spearman", path_out=file, exp='DREAM3' )
				else if( met == "kendall") 
					res <- ccn_Correlation( net, size, 0, ds, met="kendall", path_out=file, exp='DREAM3' )
				else if( met == "aracne")
					res <- ccn_Aracne( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "mrnet") 
					res <- ccn_Mrnet( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "clr") 
					res <- ccn_Clr( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "c3net") 
					res <- ccn_C3net( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "bc3net") 
					res <- ccn_BC3net( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "genie3" ) 
					res <- ccn_Genie3( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "tigress" ) 
					res <- ccn_Tigress( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "inferelator" ) 
					res <- ccn_Inferelator( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met == "anova" ) 
					res <- ccn_Anova( net, size, 0, ds, path_out=file, exp='DREAM3' )
				else if( met =="gln" )
					res <- ccn_Gln( net, size, 0, ds, path_out=file, exp='DREAM3')

				cat(" :\t", res$auc.roc.tbl., " ", res$auc.pr.tbl., "\n")
				res.table <- rbind( res.table, cbind(met, net, size, ds, round(res, 4) ))	
			}
		}
	}
	names( res.table ) <- c("method", "network", "size", "data", "auroc", "auprc")
	write.table( res.table, quote=FALSE, row.names=FALSE, col.names=TRUE, 
			file=file.path(path.out.DREAM3, "results.txt"), sep="\t" )
	return(res.table)
}

ccn_DREAM4 <- function( 
gene_networks = c("Network1", "Network2", "Network3", "Network4", "Network5"),
size          = 100, 
dataset       = TRAINING.datasets,
methods       = TRAINING.methods )
{
	res.table <- data.frame()
	for( met in methods ) 
	{
		cat( "\nMethod: ", met, '\n')
		for( net in gene_networks ) 
		{
			for( ds in dataset )
			{
				cat(" Network:", net, " #", "- data: ", ds )
				fn <- paste( net, "_size_", size, "_met_", met, "_data_", ds, ".tsv", sep="")
				file = paste(path.out.DREAM4, fn, sep="/")
				if( met == "pearson") 
					res <- ccn_Correlation( net, size, 0, ds, met="pearson", path_out=file, exp='DREAM4' )
				else if( met == "spearman") 
					res <- ccn_Correlation( net, size, 0, ds, met="spearman", path_out=file, exp='DREAM4' )
				else if( met == "kendall") 
					res <- ccn_Correlation( net, size, 0, ds, met="kendall", path_out=file, exp='DREAM4' )
				else if( met == "aracne")
					res <- ccn_Aracne( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "mrnet") 
					res <- ccn_Mrnet( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "clr") 
					res <- ccn_Clr( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "c3net") 
					res <- ccn_C3net( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "bc3net") 
					res <- ccn_BC3net( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "genie3" ) 
					res <- ccn_Genie3( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "tigress" ) 
					res <- ccn_Tigress( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "inferelator" ) 
					res <- ccn_Inferelator( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met == "anova" ) 
					res <- ccn_Anova( net, size, 0, ds, path_out=file, exp='DREAM4' )
				else if( met =="gln" )
					res <- ccn_Gln( net, size, 0, ds, path_out=file, exp='DREAM4')

				cat(" :\t", res$auc.roc.tbl., " ", res$auc.pr.tbl., "\n")
				res.table <- rbind( res.table, cbind(met, net, size, ds, round(res, 4) ))	
			}
		}
	}
	names( res.table ) <- c("method", "network", "size", "data", "auroc", "auprc")
	write.table( res.table, quote=FALSE, row.names=FALSE, col.names=TRUE, 
			file=file.path(path.out.DREAM4, "results.txt"), sep="\t" )
	return(res.table)
}


ccn_TOMACS_case_study <- function( 
gene_networks = c("ecoli1", "ecoli2", "ecoli3"),
size          = 10, 
dataset       = c("mf", "ko"),
methods       = TRAINING.methods )
{
	res.table <- data.frame()
	for( met in methods ) 
	{
		cat( "\nMethod: ", met, '\n')
		for( net in gene_networks ) 
		{
			for( ds in dataset )
			{
				cat(" Network:", net, " #", "- data: ", ds )
				fn <- paste( net, "_size_", size, "_met_", met, "_data_", ds, ".tsv", sep="")
				file = paste(path.out.TOMACS_cs, fn, sep="/")
				if( met == "pearson") 
					res <- ccn_Correlation( net, size, 0, ds, met="pearson", path_out=file, exp='TOMACS' )
				else if( met == "spearman") 
					res <- ccn_Correlation( net, size, 0, ds, met="spearman", path_out=file, exp='TOMACS' )
				else if( met == "kendall") 
					res <- ccn_Correlation( net, size, 0, ds, met="kendall", path_out=file, exp='TOMACS' )
				else if( met == "aracne")
					res <- ccn_Aracne( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "mrnet") 
					res <- ccn_Mrnet( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "clr") 
					res <- ccn_Clr( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "c3net") 
					res <- ccn_C3net( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "bc3net") 
					res <- ccn_BC3net( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "genie3" ) 
					res <- ccn_Genie3( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "tigress" ) 
					res <- ccn_Tigress( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "inferelator" ) 
					res <- ccn_Inferelator( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met == "anova" ) 
					res <- ccn_Anova( net, size, 0, ds, path_out=file, exp='TOMACS' )
				else if( met =="gln" )
					res <- ccn_Gln( net, size, 0, ds, path_out=file, exp='TOMACS')

				cat(" :\t", res$auc.roc.tbl., " ", res$auc.pr.tbl., "\n")
				res.table <- rbind( res.table, cbind(met, net, size, ds, round(res, 4) ))	
			}
		}
	}
	names( res.table ) <- c("method", "network", "size", "data", "auroc", "auprc")
	write.table( res.table, quote=FALSE, row.names=FALSE, col.names=TRUE, 
			file=file.path(path.out.TOMACS_cs, "results.txt"), sep="\t" )
	return(res.table)
}
