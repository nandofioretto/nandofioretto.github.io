/*
	Copyright 2011 Robert Küffner Licensed under the
	Educational Community License, Version 2.0 (the "License"); you may
	not use this file except in compliance with the License. You may
	obtain a copy of the License at
	
	http://www.osedu.org/licenses/ECL-2.0

	Unless required by applicable law or agreed to in writing,
	software distributed under the License is distributed on an "AS IS"
	BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
	or implied. See the License for the specific language governing
	permissions and limitations under the License.
*/

const long BUFSIZE=65536*4;
typedef int(*cctype)(const void *, const void *);

void Error(const char *msg, ...){
	va_list args;
	va_start(args, msg);
	fprintf(stdout, "Error ");
	vfprintf(stdout, msg, args);
	fprintf(stdout, "\n");
	fflush(stdout);
	va_end(args);
	exit(1);  
}

FILE *OpenInFile(const char *f, ...) {
  	char	file[BUFSIZE];

  	va_list va_args;
  	va_start(va_args, f);
  	vsprintf(file, f, va_args);
  	va_end(va_args);
      
    FILE *i;
  	if (!(i = fopen(file, "rb")))
	    return 0;
  	return i;
}

FILE* OpenOutFile(const char *f, ...){
  	char	file[BUFSIZE];

  	va_list va_args;
  	va_start(va_args, f);
  	vsprintf(file, f, va_args);
  	va_end(va_args);

  	FILE *o;
  	if (!(o = fopen(file, "w")))
    	Error("\nOpenOutFile: Error opening %s for output\n", file);
  	return o;
}

long sicomp (const sparse *a, const sparse *b) {
	if (a->idx == b->idx) return 0;
	return (a->idx < b->idx) ? -1 : 1;
}

long icomp (const long *a, const long *b) {
	if (*a == *b) return 0;
	return (*a < *b) ? -1 : 1;
}

///////////////////////////////////////////////////////////////////////////////////

// allocates memory for a string f, copies and returns it
char* stralloc(char *f) {
	if (!f || !*f || *f=='\n')
		return 0;
		
	char *x = strchr(f, '\n');
	if (x)
	    *x = 0;
	x = new char[strlen(f)+1];
	strcpy(x, f);
	return x;
}

// count number of lines in a file
long rowcnt(const char *name, const char *ext) {
	FILE *f = OpenInFile("%s%s", name, ext);
	char line[BUFSIZE];
	long cnt = 0;
	while (fgets(line, BUFSIZE, f))
		++cnt;
	fclose(f);
	return cnt;
}

// get pointer to after the element	
char *rdcol(char *col) {
	if (!col)
	    return 0;
	char *s = strchr(col, '\t');
	if (s) {
		*s=0;
		return s+1;
	}
		
	s = strchr(col, '\n');
	*s=0;
	return 0;
}

// Read an element (can be a number or a string)
template <class T>
char* rdval(T &val, char *n)	{
	char *s=n;
	n = rdcol(s);

	if (!s || !*s || strstr(s, "NA")) {
		val = -1;
	} else {
		val = (typeid(T)==typeid(long)) ? ((*s=='G') ? atoi(s+1)-1 : atoi(s)) : atof(s);	
	}
	return n;
}


// count the number of 'c' in n
long strcnt(char *n, char c) {
	long cnt=0;
	--n;
	while (n=strchr(n+1, c))
		++cnt;
	return cnt;
}


char* rdslst(sparse *&list, char *n) {
	char *s1, *s2;
	n = rdcol(s1=n);
	n = rdcol(s2=n);

	if (!*s1 || strstr(s1, "NA")) {
		list = 0;
	} else {
		long c=strcnt(s1, ',');
		list = new sparse[c+2];

		char *n1=s1-1, *n2=(!*s2 || strstr(s2, "NA")) ? 0 : s2-1;
		c=0;
		do {
			list[c].idx = atoi(n1+2)-1;
			list[c].val = (n2) ? atof(n2+1) : -1;
			n2 = (n2) ? strchr(s2=n2+1, ',') : 0; 
			++c;
		} while (n1=strchr(s1=n1+1, ','));

		qsort(list, c, sizeof(sparse), (cctype)sicomp);
		list[c].idx = -1;
	}
	return n;
}


template <class T>
char* rdlist(T *&list, char *n)	{
	char *s=n;
	n = rdcol(s);

	if (!*s || strstr(s, "NA")) {
		list = 0;
	} else {
		long c=strcnt(s, ',');
		list = new T[c+2];

		char *n=s-1;
		c=0;
		do {
			list[c++] = (typeid(T)==typeid(long)) ? atoi(n+2)-1 : atof(n+1);			
		} while (n=strchr(s=n+1, ','));
		if (typeid(T)==typeid(long))
			qsort(list, c, sizeof(long), (cctype)icomp);
		list[c] = -1;
	}
	return n;
}

void update(long *up) {
	for (long i=*up; --i;) {
		up = (long*)((long)up-sizeof(chip));
		++*up;
	}
}

bool cmpslst(sparse *a, sparse *b) {
	if (!a && !b)
		return true;
	if (!a || !b)
		return false;
	while (a->idx>=0 && b->idx>=0)
		if (a++->idx!=b++->idx)
			return false;
	return a->idx==-1 && b->idx==-1;
}

template <class T>
bool cmplist(T *a, T *b) {
	if (!a && !b)
		return true;
	if (!a || !b)
		return false;
	while (*a>=0 && *b>=0)
		if (*a++ != *b++)
			return false;
	return *a==-1 && *b==-1;
}
