## Decide_Quantization_Level.r
##
## Haizhou Wang
## Created: September 16, 2010

require(Ckmeans.1d.dp,quietly=TRUE)
require(mclust,quietly=TRUE)
#file.raw.data = "Network2_expression_data.tsv"
#file.Q.levels = "ClusterLevel4Network2Genes.txt"
#file.RData = "ClusterLevel4Network2sGenes.Rdata"

findClusterLevel <- function( expre, file.Q.levels)
{
	##(input) file.raw.data:  original data, need to decide quantize level for each node
	##(output)file.Q.levels:  give the quantization level for each node.  Human readable
	##(output)file.RData:     give the quantization level for each node.  Programming use
	## fileN = file("ClusterLevel4Genes.txt","w")
	## expre = read.table("Network2_expression_data.tsv", head=TRUE)
	# expre = read.table(file.raw.data, header=TRUE)
	ClusterLevel = rep( -1, ncol(expre) )

	for( i in 1:ncol(expre) )
	{
		#Decide how many state we should have
		bic <- mclustBIC( expre[,i] )
		summary <- summary(bic, data=expre[,i] )
		
		if(!is.null(summary$G)) {
			if( summary$G == 1) {
				ClusterLevel[i] <- 3
			} else {	
				ClusterLevel[i] = summary$G
			}
			cat("The optimal number of Gene ", i, "(by MCLUST) is ", ClusterLevel[i], "\n",file=file.Q.levels,append=TRUE)
		} else {
			cat("MCLUST cannot obtain an optimal number of Gene ", i, file=file.Q.levels,append=TRUE)
		}
	}

	#save(ClusterLevel, file=file.RData)  ## "ClusterLevel4Network2sGenes.Rdata"
	return(ClusterLevel)
}

