#include "microarray.h"
#include "probe.h"
#include "math_statistics.h"

using namespace std;
using namespace statistics;

Microarray::Microarray () {
}//-

Microarray::Microarray (const Microarray& other) {
  gene_labels = other.gene_labels;
  microarray_vector = other.microarray_vector;
}//-

Microarray&
Microarray::operator= (const Microarray& other) {
  if (&other != this) {
    gene_labels = other.gene_labels;
    microarray_vector = other.microarray_vector;
  }
  return *this;
}//-

size_t
Microarray::numof_genes() const {
  return gene_labels.size();
}//-

string
Microarray::get_gene_label( int i ) {
  return gene_labels[ i ];
}//-

vector<string>
Microarray::get_gene_labels( ) {
  return gene_labels;
}//-

int 
Microarray::get_exp_type() const {
  return type; 
}//-

Probe&
Microarray::get_probe (size_t microarray_id, size_t  probe_id) {
  return microarray_vector[microarray_id][probe_id];
}//-

vector <double> 
Microarray::get_probes_values (size_t probe_id) {
  const size_t n = numof_vectors();
  vector <double> res(n);
  for (int i=0; i < n; i++) {
    res[i] = get_probe (i, probe_id).get_value();
  }
  return res;
}//-

vector <double> 
Microarray::get_microarray_values (size_t array_id) {
  const size_t n = numof_genes();
  vector <double> res(n);
  for (int i=0; i < n; i++) {
    res[i] = get_probe (array_id, i).get_value();
  }
  return res;
}//-

void
Microarray::compute_variance () {
  for (int m=0; m<numof_vectors(); m++) {
    compute_variance(m);
  }
}//-

void
Microarray::compute_variance (size_t m_id) {
  size_t n = numof_genes();
  double s (0), ss (0);

  for (int p_id = 0; p_id < n; p_id++) {
    double v = get_probe(m_id, p_id).get_value();
    s += v;
    ss += v*v;
  }
  double microarray_var = (ss-s*s/n)/(n-1);

  for (int p_id = 0; p_id < n; p_id++) {
    get_probe(m_id, p_id).set_variance(microarray_var);
  }
}//-

void
Microarray::compute_bandwidth () {
  size_t n = numof_vectors();
  vector <double> data (numof_genes());

  double prop = 1.06; // Gaussian
  int dim = 1; // Dimension of data

  for (size_t m_id = 0; m_id < n; m_id++) { 

    double std_dev = 
      sqrt (get_probe (m_id, 0).get_variance());

    for (size_t p_id = 0; p_id < numof_genes(); p_id++) { 
      data[p_id] = get_probe (m_id, p_id).get_value();
    }
    
    double iqr = interQuartileRange (data); 
    double iqrSig = .7413*iqr; // find interquartile range sigma est.
    if (iqrSig == 0) 
      iqrSig = std_dev;
    double sig = min (std_dev, iqrSig);
    // Computing bandwidth
    double h = prop * sig * pow((double)n, ((double)-1)/((double)(4+dim)));

    for (size_t p_id = 0; p_id < numof_genes(); p_id++)
      get_probe(m_id, p_id).set_bandwidth (h);
  }

}//-

size_t
Microarray::numof_vectors () const {
  return microarray_vector.size();
}


void
Microarray::normalize () {
  // pick max and min of data set and make proportions --> MAX = 1 while MIN = 0
  double _max = -1000, _min = 1000;
  for (int m = 0; m < numof_vectors(); m++) {
    for (int p = 0; p < numof_genes(); p++) {
      _max = std::max (_max, get_probe(m, p).get_value());
      _min = std::min (_min, get_probe(m, p).get_value());
    }
  }
  // Normalize
  for (int m = 0; m < numof_vectors(); m++) {
    for (int p = 0; p < numof_genes(); p++) {
      microarray_vector[m][p] = 
	(get_probe(m, p).get_value() - _min) / (_max-_min);
    }
  }    
}//-
