#include <fstream>
#include <sstream>
#include <cassert>

#include "knockouts.h"
#include "microarray.h"
#include "probe.h"

using namespace std;

Knockouts::Knockouts () 
{
  type = Microarray::EXP_KNOCKOUTS;
}

Knockouts::Knockouts (string path) {
  type = Microarray::EXP_KNOCKOUTS;
  Knockouts::init (path);
  Microarray::compute_variance();
  Microarray::compute_bandwidth();
}//-

Knockouts::Knockouts 
(int argc, char* argv[], int& parse_pos) {

  type = Microarray::EXP_KNOCKOUTS;
  string data_path;
  for (; parse_pos < argc; parse_pos++) {
    if (!strcmp ("--microarray-knockouts", argv[parse_pos])) {
      data_path = argv[++parse_pos];
      Knockouts::init (data_path);
      Microarray::compute_variance();
      Microarray::compute_bandwidth();
      break;
    }
  }

}//-

void Knockouts::load( string path )
{
  Knockouts::init (path);
  Microarray::compute_variance();
  Microarray::compute_bandwidth(); 
}

// This function will load only the first experiment.
void
Knockouts::init (string data_path, int model_no) {
  ifstream data_file;  
  data_file.open (data_path.c_str());
  assert (data_file.is_open()); 
  string line, token;
  int type = Microarray::TYPE_DREAM4;
  
  { //- Read Header
    getline (data_file, line);
     stringstream sline (line);

    while (!sline.eof()) {
      sline >> token;
      size_t del_l = token.find_first_of("\"");
      size_t del_r = token.find_last_of("\"");
      if (del_l != string::npos && del_r != string::npos)
	token = token.substr (del_l+1, del_r-1);
      
      // Skip line Token if DREAM3 format
      if (token == "strain") {
	type = Microarray::TYPE_DREAM3;
	continue;
      }	
 
      gene_labels.push_back(token);
    }
  } //-

  // Read the data set:
  // Skip first line (wt) if file is of DREAM3 format 
  if (type == Microarray::TYPE_DREAM3)
    getline (data_file, line);

  size_t numof_genes = gene_labels.size();
  double probe_val, probe_pval;
  size_t control = 0;
  do {
    getline (data_file, line);
    stringstream sline (line);
    microarray single_measurement (numof_genes);
    // Skip first token if file is of DREAM3 format
    if (type == Microarray::TYPE_DREAM3)
      sline >> token;

    for (int g = 0; g < numof_genes; g++) {
      sline >> token;
      probe_val = atof(token.c_str());
      Probe p(probe_val);
      if (g == control)
	p.set_control(true);
      single_measurement[g] = p;
    }
    microarray_vector.push_back (single_measurement);
    control++;

  } while (line.size() > 0 && microarray_vector.size() < numof_genes);
}//-


void
Knockouts::dump() const {
  cout << "KnockoutsData:\n";
  for (int i = 0; i < gene_labels.size(); i++) 
    cout << gene_labels[i] << "\t";
  cout << endl;

  cout.precision(2);
  for (size_t kg = 0; kg < numof_genes(); kg++) {
    for (size_t tg = 0; tg < numof_genes(); tg++) {
      cout << microarray_vector[kg][tg];
      //cout << math::round_to_zero(data[kg][tg],2); 
      if (kg == tg) cout << "*\t"; 
      else cout << "\t";
    }
    cout << endl;
  }
  cout << endl;  
}//-


/**************************************************************************
 * Data Mining Functinos
 **************************************************************************/
// void
// KnockoutsData::normalize_data (WildTypeData&  wildtype) 
// {
//   assert (wildtype.numof_genes() == this->numof_genes());
//   vector <double> normalized_g (this->numof_genes()); 
  
//   for (int kg = 0; kg < this->numof_genes(); kg++) { // knocked gene 
//     for (int tg = 0; tg < this->numof_genes(); tg++) { // target gene
//       if (kg != tg) {
// 	double wild_g    = wildtype.get_value (tg);
// 	double knocked_g = this->get_value (kg, tg);
// 	normalized_g[tg] = wild_g - knocked_g;
//       }
//       else {
// 	normalized_g[tg] = 0;
//       }
//     }
//     normalized_data.push_back (normalized_g);
//   }
// }//-

// pair<int, regulation> 
// KnockoutsData::mine_DI_Motif (size_t regulator, size_t regulated) {
//   string dbg = "KnockoutsData::mine_DI_Motif - ";
//   size_t kg = regulator-1; // knocked gene
//   size_t tg = regulated-1; // target gene

//   if (kg == tg) { 
//     return make_pair(-1, unknown);
//   }
//   // activation
//   if (normalized_data[kg][tg] >= eps_knockouts) {
//     int confidence = 
//       (int)(abs((normalized_data[kg][tg] / data[kg][tg])*100));
//     return make_pair(confidence, activation);
//   }
//   // inhibition
//   else if (normalized_data[kg][tg] <= (-1)*eps_knockouts) {
//     int confidence = 
//       (int)(abs((normalized_data[kg][tg] / data[kg][tg])*100));
//     return make_pair(confidence, inhibition);    
//   }
//   return make_pair(0, NA);
  
// }//-
