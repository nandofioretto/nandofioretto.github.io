####################
path.training = "~/Research/SystemBio/GRN_inference/Data/Training/"
path.DREAM3   = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/data/DREAM3"
path.DREAM4   = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/data/DREAM4"
path.TOMACS_cs = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/data/case_study"
path.out.training = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/TrainingSet"
path.out.DREAM3   = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/DREAM3"
path.out.DREAM4   = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/DREAM4"
path.out.TOMACS_cs = "~/Research/SystemBio/GRN_inference/Papers/TOMACS2014/results/case_study"
file.ko       = "knockouts.tsv"
file.mf       = "multifactorial.tsv"
file.all      = "all.tsv"
file.pr       = "multifactorial_perturbations.tsv"
file.mf.time  = "multifactorial_timeseries.tsv"
file.pr.time  = "multifactorial_perturbations_timeseries.tsv"
file.goldstd  = "goldstandard.tsv"
file.genes    = "gene_names.tsv"
####################

TRAINING.networks = c("ecoli", "yeast")
TRAINING.size = 100
TRAINING.net_ids = c(1,2,3,4,5) 
TRAINING.datasets = c('mf', 'ko', 'all')
TRAINING.methods = c("pearson", "spearman", "kendall", "aracne", "mrnet", "clr", "c3net", "bc3net", "genie3", "tigress", "inferelator", "anova", "gln" )

###
  # Set and return the dataset path
###
get_data.path <- function 
( gene_network=c("ecoli", "yeast"), size=c(100), network_no=c(1,2,3,4,5), exp='Training')
{
	if(exp == 'Training') {
		if( gene_network == "ecoli") path.net = "Ecoli"
		else if(gene_network == "yeast") path.net = "Scervise"
		else return(NULL)
		path.net = paste( path.net, "/size", size, sep="")
		path.net = paste( path.net, "/net", network_no, sep="")
		return (paste( path.training, path.net, sep= "") )
	}
	else if(exp == 'DREAM3') {
		return (paste(path.DREAM3, gene_network, sep='/'))
	}
	else if(exp == 'DREAM4') {
		return (paste(path.DREAM4, gene_network, sep='/'))
	}
	else if(exp == 'TOMACS') {
		return (paste( path.TOMACS_cs, gene_network, sep='/'))
	}
	return (NULL)
}#-


###
  # Import Gold Standard into a [3 x N] vector
###
read_data.gold_std <- function(gene_network, network_no, size, exp)
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	file.path <- file.path(path.dataset, file.goldstd)
	data <- read.csv(file=file.path, header=FALSE, sep="\t")
	names(data) <- c("parent", "child", "value")
	return (data)
}

###
  # Import Dataset into a [M x N] vector
###
read_data.prediction <- function(gene_network, network_no, size, method, dataset)
{
	file <- paste( gene_network, network_no, "_size_", size, "_met_", method, "_data_", dataset, ".tsv", sep="")
	file.path <- file.path(path.out.training, file)
	data <- NULL
	if(file.exists(file.path))
	{
		data <- read.csv(file=file.path, header=FALSE, sep="\t")
		names(data) <- c("parent", "child", "value")
	}
	return (data)	
}

# Note the use of [[]] indexing on FOO:  FOO[i] would be a list shortened 
# to just one element; FOO[[i]] is that element.  (This distinction only 
# matters when working with types like lists.  There's no such thing as a 
# numeric value that's not in a numeric vector, so x[[2]] and x[2] are the 
# same thing if x is numeric.)
read_data.frame_predictions <- function	( gene_network, network_no, size, dataset, method=METHODS, rank=F, exp )
{
	Preds.data <- list()
	Preds.info <- list()
	i <- 1
	
	genes <- read_data.genes_id(gene_network, network_no, size, exp)		
	gold <- read_data.gold_std(gene_network, network_no, size, exp)
	
	for( met in method )
	{
		pred <- read_data.prediction(gene_network, network_no, size, met, dataset)
		if(!is.null(pred)) {
			if( nrow(pred) != nrow(gold))
			{
	 	 		warning("Gold Standard and Prediction lenghts differ!",
		  		immediate.=TRUE)
		  		return()
			}
			Preds.data[[i]] <- merge(pred, gold, by=c("parent", "child"))
			names( Preds.data[[i]]) <- c("parent", "child", "value.pred", "value.gold")
			# sort predictions
			Preds.data[[i]] <- 
				Preds.data[[i]][with(Preds.data[[i]], order(-value.pred)), ]
			if(rank) {
				Preds.data[[i]] <- cbind( "rank"=seq(1:nrow(Preds.data[[i]])), Preds.data[[i]] )
			}
			Preds.info <- (rbind( Preds.info, data.frame( "network"=gene_network, 
			"num"=network_no, "size"=size, "dataset"=dataset, "method"=as.character(met))))
		}
		i = i+1
	}
 	return(list("data"=Preds.data, "info"=Preds.info) ) 
 }#-


###
  # Import Gene Id
###
read_data.genes_id <- function(gene_network, network_no, size, exp)
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	file.path <- file.path(path.dataset, file.genes)
	return (names(read.csv(file=file.path, header=TRUE, sep="\t")))
}

###
  # Read the desired datasets
###
get_data <- function (path, dataset=c("ko","mf","all"))
{
	if(dataset == "ko") {
		path.ko = paste(path, file.ko, sep ="/")
		data <- read.csv(file=path.ko, header=TRUE, sep="\t")
	}
	else if(dataset == "mf") {
		path.mf = paste(path, file.mf, sep ="/")
		data <- read.csv(file=path.mf, header=TRUE, sep="\t")
	}
	else {
		path.mf = paste(path, file.mf, sep ="/")	
		path.ko = paste(path, file.ko, sep ="/")
		data <- rbind(read.csv(file=path.mf, header=TRUE, sep="\t"), 
	  				  read.csv(file=path.ko, header=TRUE, sep="\t"))
	}

	return(data)
}#-

###
  # Import the Gold standard and organize it as a matrix with causality:
  # row -> col. i.e., if element [i, j] = 1 then i -> j.
###
get_goldstd <- function (path, genes_name)
{
	path.gold = paste(path, file.goldstd, sep="/")
	gold.data <- read.table(file= path.gold, header=FALSE)
	N <- length(genes_name)
	gold <- matrix(data=0, nrow=N, ncol=N, dimnames=list(genes_name, genes_name))
	a <- table(gold.data[, 3])
	for( i in 1:a[names(a)==1] ) {
		gold[ as.character(gold.data$V1[i]),  as.character(gold.data$V2[i]) ] = 1
	}
	return(gold)
}#-

###
  # Get a list of gene paris with an associated confidence value and
  # returns the associated matrix G x G of the prediction values.
###
prediction.as_matrix <- function( pairs.prob, genes )
{
	ngenes = length(genes)
	pred = matrix(0, nrow=ngenes, ncol=ngenes, dimnames=list(genes, genes))
	N <- length(rownames(pairs.prob))
	for( i in 1:N)
	{
		x <- pairs.prob[i, 1]
		y <- pairs.prob[i, 2]
		pred[as.character(x), as.character(y)] <- pairs.prob[i, 3]
	}
	return (pred)

}
###
  # Write Predictions on file
###  
save_prediction <- function( pred, file.out )
{
	out <- build_prediction_table( colnames(pred), pred, NULL )
	write.table(out, quote=FALSE, row.names=FALSE, col.names=FALSE, 
	file=file.out, sep="\t" )
}