#include "knowledge_base.h"
#include "globals.h"
#include "graph.h"

using namespace std;

KnowledgeBase::KnowledgeBase ( int argc, char* argv[] ) 
{
  string path_gold, path_pred, path_names;
  string path_pred_clr, path_pred_genie3, path_pred_tigress, path_pred_infer;
  size_t size = 0;
  
  for( int i=0; i < argc; i++ ) 
  {
    if ( ! strcmp( "--gene-names", argv[ i ] ) )
      path_names = argv[ ++i ];
    if ( ! strcmp( "--gn-size", argv[ i ] ) ) 
      size = atoi( argv[ ++i ] );
    if( ! strcmp( "--gold-std", argv[ i ] ) ) 
      path_gold = argv[ ++i ];
    if( ! strcmp( "--prediction-community", argv[ i ] ) )
      path_pred = argv[ ++i ];    
    if( ! strcmp( "--prediction-clr", argv[ i ] ) )
      path_pred_clr = argv[ ++i ];    
    if( ! strcmp( "--prediction-genie3", argv[ i ] ) )
      path_pred_genie3 = argv[ ++i ];    
    if( ! strcmp( "--prediction-tigress", argv[ i ] ) )
      path_pred_tigress = argv[ ++i ];    
    if( ! strcmp( "--prediction-inferelator", argv[ i ] ) )
      path_pred_infer = argv[ ++i ];    
  }

  // GENE NAMES
  if( ! path_names.empty() )
  {
    read_names( path_names );
  }
  // GOLD STANDARD NETWORK
  if( size > 0 && !path_gold.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_gold );
    data.push_back( make_pair( G, GOLD_STD ) );
  }
  // NETWORK PREDICTION-CLR
  if( size > 0 && !path_pred_clr.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_pred_clr, true );
    data.push_back( make_pair( G, CLR ) );
  }
  // NETWORK PREDICTION-GENIE3
  if( size > 0 && !path_pred_genie3.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_pred_genie3 );
    data.push_back( make_pair( G, GENIE3 ) );
  }
  // NETWORK PREDICTION-TIGRESS
  if( size > 0 && !path_pred_tigress.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_pred_tigress );
    data.push_back( make_pair( G, TIGRESS ) );
  }
  // NETWORK PREDICTION-INFLEATOR
  if( size > 0 && !path_pred_infer.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_pred_infer );
    data.push_back( make_pair( G, INFERELATOR ) );
  }
  // NETWORK PREDICTION-COMUNITY 
  if( size > 0 && !path_pred.empty() ) 
  {
    Graph G( size, true );
    read_graph( G, path_pred );
    data.push_back( make_pair( G, COMMUNITY_RANK ) );
  }

}
//-

KnowledgeBase::~KnowledgeBase () 
{ }
//-

void KnowledgeBase::read_names( string path )
{
  ifstream in;
  in.open (path.c_str());
  assert (in.is_open()); 
  string gene_name;
  static size_t gene_id = 1;
  
  in >> gene_name;
  while( !in.eof() )
  {
    g_gene_names[ gene_name ] = gene_id++;
    in >> gene_name;
  }
}
//-

void KnowledgeBase::read_graph( Graph &G, string path, bool accept_zero)
{
  ifstream data_file;
  data_file.open (path.c_str());
  assert (data_file.is_open()); 
  string line;

  do
  {
    getline ( data_file, line );
    stringstream sline( line );
    string parent, child;
    double confidence = 0.0;

    sline >> parent >> child >> confidence;
    
    if ( accept_zero || confidence > 0 )
    {
      if ( parent != child )
	G.insert( g_gene_names[ parent ], 
		  g_gene_names[ child ], 
		  confidence );
    }
  } while (line.size() > 0);
  
}
//-

bool KnowledgeBase::has( inference_method type ) const
{
  for( int i = 0; i < data.size(); i++ )
  {
    if ( data[ i ].second == type )
      return true;
  }
  return false;
}
//-

Graph* KnowledgeBase::get( inference_method type )
{
  for( int i = 0; i < data.size(); i++ )
  {
    if ( data[ i ].second == type )
      return &data[ i ].first;
  }
  return NULL;
}
//-

kb_entry KnowledgeBase::get( int index )
{
  return data[ index ];
}
//-

int KnowledgeBase::size() const
{
  return data.size();
}
//-
