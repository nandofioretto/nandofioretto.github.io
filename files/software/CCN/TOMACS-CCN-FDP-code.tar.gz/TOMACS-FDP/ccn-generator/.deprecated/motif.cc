#include "motif.h"
#include "graph.h"
#include "knowledge_base.h"

Motif::Motif(int x, int y, int z, motif_type t, double r1, double r2)
  : X( x ), Y( y ), Z( z ), type( t ), rank1( r1 ), rank2( r2 ) 
{ }
//-

Motif::Motif( const Graph& G, int x, int y, int z, double THS)
  : X( x ), Y( y ), Z( z ), type( NONE ), rank1( 0.0 ), rank2( 0.0 )
{
  double xy = G.get_edge_weight( x, y );
  double xz = G.get_edge_weight( x, z );
  double yz = G.get_edge_weight( y, z );

  if( xy > THS && yz > THS && xz >THS ) // FFL 
  {
    rank1 = (xy + yz + xz);
    rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( y, z ) * G.get_edge_rank( x, z );
    type  = FFL; 
  }
  else if( xy <= THS && yz > THS && xz >THS ) // FAN-IN 
  { 
    rank1 = (yz + xz);
    rank2 = G.get_edge_rank( y, z ) * G.get_edge_rank( x, z );
    type  = FAN_IN; 
  }
  else if( xy > THS && yz <= THS && xz >THS ) // FAN-OUT 
  {
    rank1 = (xy + xz);
    rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( x, z );
    type  = FAN_OUT; 
  }
  else if( xy > THS && yz > THS && xz <=THS ) // CASCADE 
  {
    rank1 = (xy + yz);
    rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( y, z );
    type  = CASCADE; 
  }

}
//-


void Motif::dump()
{
  if (type == FFL)     std::cout << "FFL\t";
  if (type == FAN_IN)  std::cout << "FAN-IN\t";
  if (type == FAN_OUT) std::cout << "FAN-OUT\t";
  if (type == CASCADE) std::cout << "CASCADE\t";
  printf("%d -> %d, %d -> %d, %d -> %d \t %f  %f",
	 X, Y, X, Z, Y, Z, rank1, rank2);
}
//-


motif_type check_type( const Graph &G, int x, int y, int z )
{
  if ( G.edge( x, y ) && G.edge( y, z ) && G.edge( x, z ) ) return FFL; 
  if ( !G.edge( x, y ) && G.edge( y, z ) && G.edge( x, z ) ) return FAN_IN; 
  if ( G.edge( x, y ) && !G.edge( y, z ) && G.edge( x, z ) ) return FAN_OUT; 
  if ( G.edge( x, y ) && G.edge( y, z ) && !G.edge( x, z ) ) return CASCADE; 
  return NONE;
}//-


void count_motifs(const Graph &G, int &ffl, int &fin, int &fout, int &cas ) 
{
  int x, y, z;
  motif_type type;
 
  int _ffl=0, _fin=0, _fout=0, _cas=0;
  for( int ix = 0; ix < G.V(); ix++ )
  {
    x = G.get_nodeid( ix );
    for( int iy = 0; iy < G.V(); iy++ )
    {
      if( iy == ix ) continue;
      y = G.get_nodeid( iy );
      for( int iz = 0; iz < G.V(); iz++ )
      {
	if( iz == iy || iz == ix ) continue;
	z = G.get_nodeid( iz );

	type = check_type( G, x, y, z );
	_ffl  += ( type == FFL );
	_fin  += ( type == FAN_IN );
	_fout += ( type == FAN_OUT );
	_cas  += ( type == CASCADE );
      }
    }
  }
  ffl = _ffl; fin = _fin; fout = _fout; cas = _cas;
}

//-
std::vector< std::pair< Motif, bool > > find_all_motifs( const Graph& G, double THS ) 
{
  std::vector< std::pair<Motif, bool> > motifs;
  int x, y, z;
  motif_type type;
  double xy, xz, yz, rank1, rank2;
  Graph *gstd = g_KB->get( GOLD_STD );

  for( int ix = 0; ix < G.V(); ix++ )
  {
    x = G.get_nodeid( ix );
    for( int iy = 0; iy < G.V(); iy++ )
    {
      if( iy == ix ) continue;
      y = G.get_nodeid( iy );
      xy = G.get_edge_weight( x, y );
      
      for( int iz = 0; iz < G.V(); iz++ )
      {
	if( iz == iy || iz == ix ) continue;
	z = G.get_nodeid( iz );
	xz = G.get_edge_weight( x, z );
	yz = G.get_edge_weight( y, z );

	if( xy > THS && yz > THS && xz >THS ) // FFL 
	{
	  rank1 = xy + yz + xz;
	  rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( y, z ) * G.get_edge_rank( x, z );
	  type  = FFL; 
	}
	else if( xy <= THS && yz > THS && xz >THS ) // FAN-IN 
	{ 
	  rank1 = yz + xz;
	  rank2 = G.get_edge_rank( y, z ) * G.get_edge_rank( x, z );
	  type  = FAN_IN; 
	}
	else if( xy > THS && yz <= THS && xz >THS ) // FAN-OUT 
	{
	  rank1 = xy + xz;
	  rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( x, z );
	  type  = FAN_OUT; 
	}
	else if( xy > THS && yz > THS && xz <=THS ) // CASCADE 
	{
	  rank1 = xy + yz;
	  rank2 = G.get_edge_rank( x, y ) * G.get_edge_rank( y, z );
	  type  = CASCADE; 
	}
	else continue;
	Motif m( x, y, z, type, rank1, rank2 );
	bool gt = check_type( *gstd, x, y, z ) == type;
	motifs.push_back( std::make_pair( m, gt ) );

      }// z
    }// y
  }// x

  return motifs;
}
//-
