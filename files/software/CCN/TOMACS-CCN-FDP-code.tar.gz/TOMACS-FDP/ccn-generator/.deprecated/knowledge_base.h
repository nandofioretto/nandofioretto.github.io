#ifndef GN_KNOWLEDGE_BASE_H
#define GN_KNOWLEDGE_BASE_H

#include "globals.h"

enum inference_method
{
  CLR, GENIE3, TIGRESS, INFERELATOR, N_METHODS, GOLD_STD,
  COMMUNITY_RANK, CORR_PEARSON, CORR_SPEARMAN, 
  ANOVA, ARACNE, ANY
};

class Graph;
typedef std::pair< Graph, inference_method > kb_entry;

/*
 * Add kb_gn and and kb_data by dynamical allocation.
 * Need to guarantee that such memory area will never 
 * will released.
 */
class KnowledgeBase {
 private:
  std::vector< kb_entry > data;

 public:
  KnowledgeBase();
  KnowledgeBase ( int argc, char* argv[] );
  ~KnowledgeBase();

  void read_names( std::string path );
  void read_graph( Graph &G, std::string path, bool accept_zero = false );
  bool has( inference_method type ) const;
  Graph* get( inference_method type );
  kb_entry get( int index );
  int size() const;

};

#endif
