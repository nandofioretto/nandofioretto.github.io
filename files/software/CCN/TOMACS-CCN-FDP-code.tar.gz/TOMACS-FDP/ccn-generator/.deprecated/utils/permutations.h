/* Permutations 
 * This class is used to generate the describe the possible node 
 * permutation of K nodes for a network of N nodes.
 */

#ifndef GNOFF_PERMUTATIONS_H
#define GNOFF_PERMUTATIONS_H

#include "globals.h"

class Permutations {
 private:
  int n, k;
  std::vector<std::vector<int> > permutations;

 public:
  Permutations(int n, int k);
  
  std::vector<int> operator[] (int idx) const;
  size_t size() const;
  int get_k() const;
  int get_n() const;
  void dump();
};

#endif
