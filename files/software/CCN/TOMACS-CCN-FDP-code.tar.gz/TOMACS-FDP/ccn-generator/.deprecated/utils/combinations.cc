#include "combinations.h"

using namespace std;

// Creates cominations of k elements among range [1 n] 
Combinations::Combinations (int _n, int _k) 
  : n(_n), k(_k) 
{   
  std::vector<bool> v(n);
  std::fill(v.begin() + k, v.end(), true);
  
  vector<int> combination;
  do {
    combination.clear();
    combination.reserve(k);
    for (int i = 0; i < n; ++i) {
      if (!v[i]) {
	combination.push_back(i+1);
      }
    }
    combinations.push_back(combination);
  } while (std::next_permutation(v.begin(), v.end())); 

}//-

vector<int> 
Combinations::operator[] (int idx) const {
  return combinations[idx];
}//-

size_t
Combinations::size() const {
  return combinations.size();
}

int 
Combinations::get_n() const {
  return n;
}//-

int 
Combinations::get_k() const {
  return k;
}//-

void 
Combinations::dump() {
  for (int i=0; i<combinations.size(); i++) {
    for (int ii=0; ii<combinations[i].size(); ii++) {
      cout << combinations[i][ii] << " ";
    }
    cout << endl;
  }
}//-
