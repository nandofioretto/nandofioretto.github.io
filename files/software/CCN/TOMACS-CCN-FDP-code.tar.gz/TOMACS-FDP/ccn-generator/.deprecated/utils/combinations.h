/* Combinations 
 * This class is used to generate the describe the possible node combinations of K nodes 
 * for a network of N nodes.
 */

#ifndef GNOFF_COMBINATIONS_H
#define GNOFF_COMBINATIONS_H

#include "globals.h"

class Combinations {
 private:
  int n, k;
  std::vector<std::vector<int> > combinations;

 public:
  Combinations(int n, int k);
  
  std::vector<int> operator[] (int idx) const;
  size_t size() const;
  int get_k() const;
  int get_n() const;
  void dump();
};

#endif
