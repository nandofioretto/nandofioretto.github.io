#include "math_statistics.h"
#include <functional>
#include <numeric>
#include <cmath>

using namespace std;

vector<int>
statistics::rank (vector <double> x) {
  size_t n = x.size();
  vector<int> x_rank (n,0);  
  for  (size_t i = 0; i < n; i++) {
    for (size_t j = 0; j < n; j++) {
      if (x[i] < x[j])
	x_rank[i]++;
    }
  }
  return x_rank;
}//-

double 
statistics::pearson_correlation (vector<double> x, vector <double> y) {
  double TINY_VALUE = 1e-20;
  size_t n = x.size();
  double ex(0), ey(0), xt(0), yt(0), sxx(0), syy(0), sxy(0);
  for (size_t i = 0; i < n; i++) { //Find the means.
    ex += x[i];
    ey += y[i];
  }
  ex /= n;
  ey /= n;

  for (size_t i = 0; i < n; i++) { //Compute the correlation coeﬃcient.
    xt = x[i] - ex;
    yt = y[i] - ey;
    sxx += xt * xt;
    syy += yt * yt;
    sxy += xt * yt;
  }
  return sxy/(sqrt(sxx*syy)+TINY_VALUE);
}//-

// p = 1 - (6 * \sum d_i^2) / (n (n^2 - 1)) 
// where d_i = rank_x_i - rank_y_i
double 
statistics::spearman_rank (vector<double> x, vector <double> y) {
  double TINY_VALUE = 1e-20;
  size_t n = x.size();
  vector<int> x_rank (n,0);
  vector<int> y_rank (n,0);

  // Rank x and y vectors 
  // Hank! This is inefficient! Quadratic!!
  for  (size_t i = 0; i < n; i++) {
    for (size_t j = 0; j < n; j++) {
      if (x[i] < x[j])
	x_rank[i]++;
      if (y[i] < y[j])
	y_rank[i]++;
    }
  }

  //Find the differences.
  double sum_dd(0);
  for (size_t i = 0; i < n; i++) { 
    sum_dd += ((x_rank[i] - y_rank[i]) * (x_rank[i] - y_rank[i]) );
  }

  return 1 - ( (6 * sum_dd) / (n * (n*n - 1)));  
}//-


// Assuming X and Y are random variables that follow a Gaussian 
// distribution:
// -1/2 log (1 - rho^2)
double 
statistics::MI (vector <double> X, vector <double> Y, int type) {
  double TINY_VALUE = 1e-10;

  if (type == MI_GAUSSIAN) {
    return (-1)*(0.5 * log (1 - (pow (spearman_rank (X, Y), 2) - TINY_VALUE)));
  }
}


double 
statistics::gaussian_CDF (double x) {
  // constants
  double a1 =  0.254829592;
  double a2 = -0.284496736;
  double a3 =  1.421413741;
  double a4 = -1.453152027;
  double a5 =  1.061405429;
  double p  =  0.3275911;

  // Save the sign of x
  int sign = 1;
  if (x < 0)
    sign = -1;
  x = fabs(x)/sqrt(2.0);

  // A&S formula 7.1.26
  double t = 1.0/(1.0 + p*x);
  double y = 1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1)*t*exp(-x*x);

  return 0.5*(1.0 + sign*y);
}//


// The function \phi(x) is the cumulative density function (CDF) of a standard 
// normal (Gaussian) random variable.  It is closely related to the error function erf(x).
double
statistics::average (vector <double> data, bool rm_NA) {
  double avg = 0;
  int n = 0;
  for (int i=0; i<data.size(); i++) {
    avg += data[i];
    n += ( data[i] != 0 ) ? 1 : 0;
  }
  return avg/n;
}//-


// Biased 
double
statistics::std_dev (vector <double> v, bool rm_NA) 
{
  double sum = std::accumulate(v.begin(), v.end(), 0.0);
  double mean = sum / v.size();

  std::vector<double> diff(v.size());
  std::transform(v.begin(), v.end(), diff.begin(),
		 std::bind2nd(std::minus<double>(), mean));
  double sq_sum = std::inner_product(diff.begin(), diff.end(), diff.begin(), 0.0);
  return std::sqrt(sq_sum / v.size());
}//-

double 
statistics::median (vector <double> data, bool sorted){
  if (!sorted)
    sort ( data.begin(), data.end() );

  double median ;
  const int n = data.size();
  const int lhs = (n - 1) / 2 ;
  const int rhs = n / 2 ;

  if (n == 0)
    return 0.0 ;

  if (lhs == rhs){
    median = data.at(lhs) ;
  }
  else {
    median = ( data.at(lhs) + data.at(rhs)) / 2.0 ;
  }
  return median;
}//-

double 
statistics::interQuartileRange(vector <double> data){
  // Q(1) = median(y(find(y<median(y))));
  sort (data.begin(), data.end());
  int medianIndex = (data.size() + 2) / 2;
  vector<double> subset;
  for (int i = 0; i < (medianIndex - 1); i++){
    subset.push_back( data[i] );
  }

  double q1 = median( subset ); 
  // Q(3) = median(y(find(y>median(y))));
  medianIndex = (data.size() + 1) / 2;
  subset.clear();
  for (int i = medianIndex; i < data.size(); i++){
    subset.push_back( data[i] );
  }
  double q3 = median( subset, true );
  subset.clear();
  return q3 - q1;
}//-

double 
statistics::normalPDF(double dx, double sigma){
  double y = exp(-0.5 * pow((dx/sigma), 2)) / (sqrt(2 * M_PI) * sigma);
  return y;
}

double 
statistics::multinormalPDF(double dx, double dy, double sigmaX, double sigmaY){
  double y = exp(-0.5 * (pow((dx / sigmaX), 2) + pow((dy / sigmaY), 2)));
  y = y /(2 * M_PI * sigmaX * sigmaY);
  return y;
}


double 
statistics::gaussian_kernel (vector <double> x, vector <double> y, size_t i, double sigmaX, double sigmaY) {
  double fxy = 0.0;
  double fx = 0.0;
  double fy = 0.0;

  const size_t size = x.size();

  for (int j = 0; j < size; j++ ) {
    double mu_x = x[j];
    double mu_y = y[j];

    double dx = std::abs( x[i] - mu_x );
    double dy = std::abs( y[i] - mu_y );
    fx += normalPDF (dx, sigmaX);
    fy += normalPDF (dy, sigmaY);
    fxy += multinormalPDF (dx, dy, sigmaX, sigmaY);

  }

  return ( ( fxy * size ) / ( fx * fy ) );
}//-
