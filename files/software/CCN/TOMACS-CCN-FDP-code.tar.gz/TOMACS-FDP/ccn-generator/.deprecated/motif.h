#ifndef _GN_MOTIF_H_
#define _GN_MOTIF_H_

#include "globals.h"
class Graph;

enum motif_type
{
  FFL = 0, FAN_IN, FAN_OUT, CASCADE, NONE,  N_MOTIFS
};
  
struct Motif
{
  /* static const int FFL     = 0; */
  /* static const int FAN_IN  = 1; */
  /* static const int FAN_OUT = 2; */
  /* static const int CASCADE = 3; */
  /* static const int NONE    = 4; */
  /* static const int NMOTIFS = 5; */

  int X; int Y; int Z;
  motif_type type;
  double rank1;
  double rank2;

  Motif(int x, int y, int z, motif_type t, double r1, double r2);
  Motif( const Graph& G, int x, int y, int z, double THS);
  void dump();
};

std::vector< std::pair<Motif, bool> > find_all_motifs( const Graph& G, double THS = 0.0 ); 
void count_motifs(const Graph &G, int &ffl, int &fin, int &fout, int &cas );


#endif
