#ifndef _SOLUTION_H
#define _SOLUTION_H

#include "globals.h"

class Solution
{
 private:
  std::vector< double > _states; // domain elements
  double _AUROC;
  double _AUROC2;
  double _AUPR;
  double _Fscore;
  
 public:
  Solution();
  Solution( std::vector<double> state );
  Solution( const Solution& other );
  double& operator[]( size_t pos );
  double operator[]( size_t pos ) const;
  bool operator() ( const Solution& lhs, const Solution& rhs ) const;
  bool operator< ( const Solution& other ) const;
  bool operator<= ( const Solution& other ) const;

  size_t size();
  std::vector<double> get_states();
  double get_AUROC();
  double get_AUROC2();
  double get_AUPR();
  double get_Fscore();
  void dump();
};

#endif
