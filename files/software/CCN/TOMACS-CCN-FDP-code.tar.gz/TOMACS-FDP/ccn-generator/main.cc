// CP Core headers
#include "cpff_headers.h"
#include "statistics.h"

// CRNIFF headers
#include "globals.h"
#include "graph.h"
#include "inference_ensemble.h"
#include "solution.h"
#include "solopt_utils.h"

#include "io_utils.h"
#include "solver_utils.h"
#include "math_utils.h"
#include "prior_utils.h"

using namespace std;

#define OUTPUT_LATEX
//#define VERBOSE

int main (int argc, char* argv[]) 
{
  g_stats.set_timer( t_init );
  srand (time(NULL));

  /**************************************************************
   * Preprocess
   *************************************************************/
#ifdef VERBOSE
  cout << "Parsing inputs...\n";
#endif
  IO::parse( argc, argv );
  Graph* g_GoldStd = g_InfKB.goldStd;
  
#ifdef VERBOSE
  cout << "Setting CN ensemble...\n";
#endif
  InferenceEnsemble g_Ensemble( argc, argv );
  g_Ensemble.makeCN( BORDA_rank );
  
  /* Get the Consensus Network and the Gold Std */
  Graph* g_ComNet  = g_Ensemble.get( make_pair( CN, MetType_undef ) );
  /* Create m=n^2-n variables x_1, ... x_m and set D(xi) = RANK[xi] */   
#ifdef VERBOSE
  cout << "Creating CP variables and constraints...\n";
#endif
  Utils::create_variables( g_Ensemble );
  Solution CN_rank;
  Utils::create_constraints( argc, argv, g_Ensemble );

  g_constraint_store = new ConstraintStore (); /* needs all constraints to 
						  be set already */
  g_stats.stopwatch( t_init );  

  /**************************************************************
   * Search Phase
   *************************************************************/
  g_stats.set_timer( t_sampling );
  if( g_TFs.empty() ) {
    MonteCarlo_vlab* mc = new MonteCarlo_vlab( argc, argv );
    mc->search();
  }
  else {
    TFsFirstSearch* tffs = new TFsFirstSearch( argc, argv );
    tffs->search();
  }
  g_stats.stopwatch( t_sampling );

  /**************************************************************
   * Post-Process
   *************************************************************/
#ifdef OUTPUT_LATEX
  SolOpt::summary( g_solutions, CN_rank, true );
#else
  SolOpt::summary( g_solutions, CN_rank, false );
#endif

  g_stats.dump();

  //delete search_engine;
  delete g_constraint_store;
  return 0;
}//-
