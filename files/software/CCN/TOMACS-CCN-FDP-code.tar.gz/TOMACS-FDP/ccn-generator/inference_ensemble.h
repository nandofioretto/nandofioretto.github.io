#ifndef INFERENCE_ENSEMBLE_H
#define INFERENCE_ENSEMBLE_H

#include "globals.h"

enum e_InfMet{ MI, Cor, LR, ByN, BlN, ODE, Stat, GS, CN, CCN, InfMet_undef };
enum e_MetType{ Pure, Hybrid, MetType_undef };
enum CNType{ BORDA_rank, BORDA_conf, invChi2 };
class Graph;

typedef std::pair< e_InfMet, e_MetType > _metEntry;
typedef std::pair<Graph*, double> _gEntry;
typedef std::pair< _metEntry, _gEntry > _infEntry;
typedef std::vector< _infEntry > _infSet;


/*
 * Add kb_gn and and kb_data by dynamical allocation.
 * Need to guarantee that such memory area will never 
 * will released.
 */
class InferenceEnsemble 
{
 private:
  _infSet ensemble;
  
  e_InfMet getInfMet( char* meth );
  e_MetType getMetType( char* meth );

 public:
  InferenceEnsemble();
  InferenceEnsemble ( int argc, char* argv[] );
  ~InferenceEnsemble();

  // Community Networks
  void makeCN( CNType type );

  Graph* get( _metEntry met );
  _infEntry get( int index );
  int size() const;
  void dump();
  void dump(int i);
};

#endif
