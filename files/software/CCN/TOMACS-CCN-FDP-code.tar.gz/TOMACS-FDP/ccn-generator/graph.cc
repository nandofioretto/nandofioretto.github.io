#include "graph.h"  
#include "globals.h"
#include "io_utils.h"
#include "math_utils.h"

using namespace std;

#define _GRAPH_UTILS_MAX_SIZE_ 1000

int g_kruskal_cicles[ _GRAPH_UTILS_MAX_SIZE_ ];
bool Visit[ _GRAPH_UTILS_MAX_SIZE_ ];
bool InStk[ _GRAPH_UTILS_MAX_SIZE_ ];
int Low[ _GRAPH_UTILS_MAX_SIZE_ ], depth;
int Ind[ _GRAPH_UTILS_MAX_SIZE_ ];
stack<long> Stk;
vector< vector <int> > components;


/* *******************************************************
 * Graph Class Functions
 * *******************************************************/
Graph::Graph( int nodes, bool dir )  
  : n_nodes ( nodes ), n_edges( 0 ), directed( dir ), _edges_are_sorted( false )
{
}//-

Graph::Graph( int nodes, vector<edge_t> edges, bool dir )  
  : n_nodes ( nodes ), n_edges( 0 ), directed( dir ), _edges_are_sorted( false )
{
  for ( int i=0; i < edges.size(); i++)
  {
    insert( edges[ i ].first.first, edges[ i ].first.second, edges[ i ].second );
  }
  sortEdges();
}
//-

Graph::Graph( const Graph& other ) 
{
  n_nodes = other.n_nodes;
  n_edges = other.n_edges;
  directed = other.directed;
  _edges_are_sorted = other._edges_are_sorted;
  link_map = other.link_map;
  nodes_id = other.nodes_id;
  _sorted_edges = other._sorted_edges;
}
//-
      
Graph& Graph::operator=( const Graph& other )
{
  if( this != &other )
  {
    n_nodes = other.n_nodes;
    n_edges = other.n_edges;
    directed = other.directed;
    _edges_are_sorted = other._edges_are_sorted;
    link_map = other.link_map;
    nodes_id = other.nodes_id;
    _sorted_edges = other._sorted_edges;
  }
  return *this;
}
//-
Graph::~Graph()  
{ }
//-

// Add a link: map node pair with weight  
void Graph::insert( int s, int t, double weight )  
{
  // Insert ID of Current Nodes
  node_it nit;
  nit = find( nodes_id.begin(), nodes_id.end(), s );
  if ( nit == nodes_id.end() ) nodes_id.push_back ( s );
  nit = find( nodes_id.begin(), nodes_id.end(), t );
  if ( nit == nodes_id.end() ) nodes_id.push_back ( t );
    
  pair<int,int> p1( s, t );
  pair<int,int> p2( t, s );
  link_map[ p1 ] = weight; 
  
  if ( !directed )
  {
    link_map[ p2 ] = weight;  
  }
  n_edges++;
  _edges_are_sorted = false;
}
//-

// Remove selected link - remove both directions  
// if graph is not directed  
void Graph::remove( int s, int t )
{
  pair<int,int> p1( s, t );
  map< pair<int,int>, double>::iterator mit = link_map.find( p1 );  
  link_map.erase( mit );

  if ( !directed )
  {
    pair<int,int> p2( t, s );  
    mit = link_map.find( p2 );  
    link_map.erase( mit );  
  }
  n_edges--;  
  _edges_are_sorted = false;
}
//-

void Graph::incr_edge_weight ( int s, int t, double w )
{
  double ew = get_edge_weight( s, t );
  remove( s, t );
  insert( s, t, std::max(1.0, ew + w) );
  _edges_are_sorted = false;
}
//-

void Graph::decr_edge_weight ( int s, int t, double w )
{
  double ew = get_edge_weight( s, t );
  remove( s, t );
  insert( s, t, std::max(0.0, ew - w) );
  _edges_are_sorted = false;
}
//-
      
// Return number of network nodes  
int Graph::V() const
{
  return n_nodes;  
}
//-
      
// Return number of edges  
int Graph::E() const
{
  return n_edges;  
}
//-

// Return true if graph is directed; false otherwose  
bool Graph::is_directed() const  
{  
  return directed;  
}
//-

// Check if link exists between two nodes id, s and t  
bool Graph::edge( int s, int t) const
{  
  return get_edge( s, t ) != link_map.end();  
}//-

// Get edge between two nodes id, s and t
clm_it Graph::get_edge( int s, int t ) const
{
  std::pair<int,int> p( s, t );
  clm_it mit = link_map.find( p );  
  return mit;
}  
//-

// Return all the neighbors of (node id) s connected by an edge with 
// weight at least min_w:
// {u | (s, u, w) /\ w >= min_w }
vector<edge_t> Graph::get_neighbors( int s, double min_w ) const
{  
  vector<edge_t> vec;
  for (int tidx = 0; tidx < V(); tidx++) 
  {
    int t = nodes_id[ tidx ];
    clm_it mit = get_edge( s, t );
    if ( mit != link_map.end() && min_w < mit->second ) 
    {
      vec.push_back ( *mit );
    }
  }
  sort(vec.begin(), vec.end(), cmp_second_geq<edge_t>);	
  return vec;
}
//-

// Return all the neighbors of (node id) s connected by an edge with 
// weight at least min_w:
// {u | (s, u, w) | (u, s, w) /\ w >= min_w }
vector<edge_t> Graph::get_undirect_neighbors( int s, double min_w ) const
{  
  vector<edge_t> vec;
  for (int tidx = 0; tidx < V(); tidx++) 
  {
    int t = nodes_id[ tidx ];
    clm_it mit = get_edge( s, t );
    clm_it mit_d = get_edge( t, s );
    if ( mit != link_map.end() && min_w < mit->second ) 
    {
      vec.push_back ( *mit );
    }
    else if ( mit_d != link_map.end() && min_w < mit_d->second ) 
    {
      vec.push_back ( *mit );
    } 
  }
  return vec;
}
//-

double Graph::get_edge_weight ( int s, int t ) const
{
  clm_it mit = get_edge( s, t );
  if ( mit != link_map.end() )
    return mit->second;
  return 0;
}
//-

int Graph::get_edge_rank ( int s, int t )
{
  if( ! _edges_are_sorted ) sortEdges(); 

  for( int i = 0; i < _sorted_edges.size(); i++ )
  {
    if (s == _sorted_edges[ i ].first.first &&
        t == _sorted_edges[ i ].first.second) 
      return i+1;
  }
  return n_nodes*n_nodes;
}
//-

int Graph::deg( int s, double min_w ) const 
{
  if ( !directed ) return out_deg ( s, min_w );
  return (in_deg( s, min_w ) + out_deg ( s, min_w )); 
}
//-

int Graph::in_deg( int s, double min_w ) const
{
  int deg = 0, t;
  for (int tidx=0; tidx < V(); tidx++)
  {
    t = nodes_id[ tidx ];
    if ( get_edge_weight( t, s ) > min_w )
    {
      deg += edge( t, s );
    }
  }
  return deg;
}
//-

int Graph::out_deg( int s, double min_w ) const 
{
  int deg = 0, t;
  for (int tidx=0; tidx < V(); tidx++)
  {
    t = nodes_id[ tidx ];
    if ( get_edge_weight( s, t ) > min_w )
    {
      deg += edge( s, t );
    }
  }
  return deg;
}
//-

// Compute the avg weight w.r.t. node degree for node s
double Graph::avg_weight( int s ) const
{
  double avg_w = 0.0;
  int neighbors = 0;
  clm_it mit;
  int t, i;

  for (i=0; i < V(); i++ )
  {
    t = nodes_id[ i ];
    mit = link_map.end();
    if( edge( s, t) ) mit = get_edge( s, t );
    else if( edge( t, s ) ) mit = get_edge( t, s ); 
    if ( mit != link_map.end() )
    {
      avg_w += mit->second;
      neighbors++;
    }
  }
  if (neighbors == 0) return 0;
  return (avg_w / neighbors);
}
//-

// Compute the avg weight w.r.t. node OUTdegree for node s
  double Graph::avg_weight_out( int s, double min_w ) const
{
  double avg_w = 0.0;
  int neighbors = 0;
  clm_it mit;
  int t, i;

  for (i=0; i < V(); i++ )
  {
    t = nodes_id[ i ];
    mit = get_edge( s, t );
    if ( mit != link_map.end() && mit->second >= min_w )
    {
      avg_w += mit->second;
      neighbors++;
    }
  }
  if (neighbors == 0) return 0;
  return (avg_w / neighbors);
}
//-


// Compute the avg weight w.r.t. node INdegree for node s
double Graph::avg_weight_in( int s, double min_w ) const
{
  double avg_w = 0.0;
  int neighbors = 0;
  clm_it mit;
  int t, i;

  for (i=0; i < V(); i++ )
  {
    t = nodes_id[ i ];
    mit = get_edge( t, s );
    if ( mit != link_map.end() && mit->second >= min_w )
    {
      avg_w += mit->second;
      neighbors++;
    }
  }
  if (neighbors == 0) return 0;
  return (avg_w / neighbors);
}
//-

// Print the network topology  
void Graph::dump() const  
{  
  clm_it mit = link_map.begin();
  
  for ( ; mit != link_map.end(); ++ mit )  
  {
    pair<int,int> p = (*mit).first;  
    if ( !directed && p.first < p.second ) 
      continue;
    
    std::cout << g_gene_names[p.first]  << "\t" 
	      << g_gene_names[p.second] << "\t" 
	      << (*mit).second << std::endl;  
  }
}//-

void Graph::dump_sorted()
{
  if( !_edges_are_sorted )
    sortEdges();

  for( int i=0; i< _sorted_edges.size(); i++)
    {
      std::cout << _sorted_edges[i].first.first << "\t"
		<< _sorted_edges[i].first.second << "\t"
		<< _sorted_edges[i].second << std::endl;
    }
}

void Graph::stats()
{
  int out = 0; // out-deg > indeg
  int in  = 0; // in-deg  > out-deg
  int tfs = 0;
  std::vector<int> out_degs;
  for( int i = 0; i < V(); i++ )
  {
    int od = out_deg( i ); int id = in_deg( i );
    if( od > id ) out ++;
    if( od < id ) in ++;
    if( od > 0 ) {tfs ++; out_degs.push_back(od); }
  }
  std::cout << "# Nodes: " << V() << " Edges: " << E() << endl
	    << "# TFs: " << tfs << endl
	    << "# nodes >in-deg:  " << in << endl
	    << "# nodes >out-deg: " << out << endl;

  int h = 0, h2=0;
  double od_avg = Math::mean( out_degs );
  double od_sd  = Math::sd( out_degs );
  for( int i=0; i < V(); i++ )
  {
    if( out_deg( i ) > od_avg ) h++;
    if( out_deg( i ) > (od_avg + od_sd) ) h2++; 
  }
  cout << "# hubs  od_MEAN: " << od_avg << " (" << h << ") "
       << " od_SD: " << od_sd << " (" << h2 << ")" << endl;
  
}
/* *******************************************************
 * Graph Utilities
 * ***************************************************** */
void Graph::sortEdges()
{
  _sorted_edges = sorted_edges();
  _edges_are_sorted = true;
};


// Sort the weighted edges
vector<edge_t> Graph::sorted_edges() const
{
  vector< edge_t > vec(link_map.begin(), link_map.end());
  sort(vec.begin(), vec.end(), cmp_second_geq<edge_t>);	
  return vec;
}
//-


// Rank Graph Edges
void Graph::normalizeWeigths()
{
  if( ! _edges_are_sorted ) sortEdges();
 
  int i = 0;
  while( _sorted_edges[ i ].first.first == _sorted_edges[ i ].first.second ){ i++; }
  double max = _sorted_edges[ i ].second;

  i = _sorted_edges.size();
  while( _sorted_edges[ i ].first.first == _sorted_edges[ i ].first.second ){ i--; }
  double min = _sorted_edges[ i ].second;

  double d = max - min;
  
  for( i = 0; i < _sorted_edges.size(); i++ )
  {
    int s = _sorted_edges[ i ].first.first;
    int t = _sorted_edges[ i ].first.second; 
    double w = _sorted_edges[ i ].second;
    remove(s, t);
    double new_w = std::max( 0.0, std::min( 1.0, ( (w - min) / d ) ) ); 
    insert(s, t , new_w );
  }
  _edges_are_sorted = false;
}
//-

// Get the Kruskal MST
Graph* Graph::kruskal( )
{
  int i, number, nnodes=0;
  Graph *MST = new Graph( V()-1, false );
  vector<edge_t> edges = sorted_edges();
  
  for( i=0; i < V(); i++) 
  {
    g_kruskal_cicles[ nodes_id [ i ] ] = nodes_id[ i ];
  }

  while( nnodes < ( V() - 1) && edges.size() )
  {
    edge_t e = edges[ 0 ];
    int vi = e.first.first; // take index of this number 
    int vj = e.first.second; // take index of this number
 
    if( g_kruskal_cicles[ vi ] != g_kruskal_cicles[ vj ] )
    {
      number = g_kruskal_cicles[ vj ];
      for( i=0; i < V(); i++ ) 
      {
	if( g_kruskal_cicles[ nodes_id[ i ] ] == number )
	{
	  g_kruskal_cicles[ nodes_id[ i ] ] = g_kruskal_cicles[ vi ];
	}
      }
      MST->insert( vi, vj, e.second );
      nnodes++;
    }
    edges.erase( edges.begin(), edges.begin() + 1 );
  }  
  
  return MST;
}//-


void Graph::OHMST 
( vector<int>& outliers, vector<int>& hubs, double THS, int THS_H, int THS_O)
{
  Graph *mst = kruskal ();
  // mst->dump();
  vector < pair <int,double> > avg_w ( V() );
  int i, s; double avg_s;

  // Compute AVG weight for each vertex in MST
  for (i=0; i < V(); i++)
  {
    s = mst->nodes_id[ i ];
    avg_w[ i ] = make_pair( s, mst->avg_weight( s ) );
  }
  sort( avg_w.begin(), avg_w.end(), cmp_second_geq< pair<int,double> > );

  for (i=0; i < V(); i++)
  {
    s = avg_w[ i ].first;
    avg_s = avg_w[ i ].second;
    if (avg_s >= THS)
    {
      if (mst->deg ( s ) >= THS_H) hubs.push_back( s );
      if (mst->deg ( s ) <= THS_O ) outliers.push_back( s );
    }
  }

  delete mst;
}
//-

void Graph::OHMST2
( vector<int>& outliers, vector<int>& hubs, double THS, int THS_H, int THS_O)
{
  vector < pair <int,pair<double,double> > > avg_w ( V() );
  int i, s; double avgin_s, avgout_s;

  for (i=0; i < V(); i++)
  {
    s = nodes_id[ i ];
    avg_w[ i ] = 
      make_pair( s, make_pair( avg_weight_in ( s, THS), 
			       avg_weight_out( s, THS) ) );
  }
  //sort( avg_w.begin(), avg_w.end(), cmp_second_geq< pair<int,double> > );
  cout << "  \t  IN  \t\t   OUT  \n";
  cout.precision(3);
  for (i=0; i < V(); i++)
  {
    s = avg_w[ i ].first;
    avgin_s  = avg_w[ i ].second.first;
    avgout_s = avg_w[ i ].second.second;
    cout << "V_" << s << ":\t" << avgin_s << " (" << in_deg ( s, THS ) 
	 << ") \t " << avgout_s <<  " (" <<  out_deg( s, THS ) << ")\n";

    if (avgin_s  > THS &&  in_deg ( s, THS ) <= THS_O)  outliers.push_back( s );
    else if (avgout_s > THS && out_deg ( s, THS ) >= THS_H)  hubs.push_back( s );
  }
}
//-


void Graph::SCC( int u, double w)
{
  Visit[ u ] = true; InStk[ u ] = true;
  Ind[ u ] = ++depth; Low[ u ] = depth;
  Stk.push( u );

  std::vector<edge_t> u_succs = get_neighbors ( u , w );

  for( int i = 0; i < u_succs.size(); i++ )
  {
    int v = u_succs[ i ].first.second;
    if( !Visit[ v ] )
    {
      SCC( v, w );
      Low[ u ] = min( Low[ u ], Low[ v ] );
    }
    else if( InStk[ v ] )
    {
      Low[ u ] = min( Low[ u ], Ind[ v ] ); // v in stack but not the DFS tree
    }
  }
  if( Low[ u ] != Ind[ u ] ) return;
  
  // found new component
  vector<int> component;
  while( Stk.top() != u )
  {
    int v = Stk.top();
    component.push_back( v );
    Stk.pop();
    InStk[ v ] = false;
  }
  component.push_back( u );
  Stk.pop();
  InStk[ u ] = false;

  if( !component.empty() ) 
  {
    sort( component.begin(), component.end() );
    components.push_back( component ); 
  }
}
//-

vector<vector<int> > Graph::Tarjans_SCC( double w )
{
  memset (Visit, false, sizeof (bool) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (InStk, false, sizeof (bool) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (Low, 0, sizeof(int) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (Ind, 0, sizeof(int) * _GRAPH_UTILS_MAX_SIZE_ );
  depth= 0;
  while (!Stk.empty()) Stk.pop();
  components.clear();

  for(int i = 0; i < n_nodes; i++ )
  {
    int u = nodes_id[ i ];
    if( Visit[ u ] ) continue;
    SCC( u , w);
  }
  return components;

}//-


void Graph::CC( int u, double w)
{
  Visit[ u ] = true; InStk[ u ] = true;
  Ind[ u ] = ++depth; Low[ u ] = depth;
  Stk.push( u );

  std::vector<edge_t> u_succs = get_undirect_neighbors ( u , w );
  for( int i = 0; i < u_succs.size(); i++ )
  {
    int v = u_succs[ i ].first.second;
    if( !Visit[ v ] )
    {
      CC( v, w );
      Low[ u ] = min( Low[ u ], Low[ v ] );
    }
    else if( InStk[ v ] )
    {
      Low[ u ] = min( Low[ u ], Ind[ v ] ); // v in stack but not the DFS tree
    }
  }
  if( Low[ u ] != Ind[ u ] )  return;
  
  vector<int> component;
  // found new component
  while( Stk.top() != u )
  {
    int v = Stk.top();
    component.push_back( v );
    Stk.pop();
    InStk[ v ] = false;
  }
  component.push_back( u );
  Stk.pop();
  InStk[ u ] = false;

  if( !component.empty() )
  {
    sort( component.begin(), component.end() );
    components.push_back( component ); 
  }
}
//-

vector<vector<int> > Graph::Tarjans_CC( double w )
{
  memset (Visit, false, sizeof (bool) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (InStk, false, sizeof (bool) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (Low, 0, sizeof(int) * _GRAPH_UTILS_MAX_SIZE_ );
  memset (Ind, 0, sizeof(int) * _GRAPH_UTILS_MAX_SIZE_ );
  depth= 0;
  while (!Stk.empty()) Stk.pop();
  components.clear();


  for(int i = 0; i < n_nodes; i++ )
  {
    int u = nodes_id[ i ];
    if( Visit[ u ] ) continue;
    CC( u , w);
  }
  return components;

}//-
