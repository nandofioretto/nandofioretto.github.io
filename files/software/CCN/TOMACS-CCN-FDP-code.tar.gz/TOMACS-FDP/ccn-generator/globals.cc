#include "globals.h"
#include "inference_ensemble.h"
#include "statistics.h"

class Variable;
class Solution;

// Associate Gene Names to ID
std::map<std::string,int> g_gene_ids;
std::map<int,std::string> g_gene_names;
// Associate Prediction Edges to CP Variables
std::map<std::pair<int,int>,int> g_edge_var;
std::map<int,std::pair<int,int> > g_var_edge;

std::vector<int> g_TFs;
std::vector<int> g_TGs;


std::map< int, std::vector< Variable* > > g_outgoing_edges_of_node;
std::map< int, std::vector< int > > g_neighbours;// node-> set of vars
 
std::vector< Solution* > g_solutions; 

s_Consts g_Consts; 
s_InfKB g_InfKB;
Statistics g_stats;

//vector<var_int*> g_nogoods;//tmp
