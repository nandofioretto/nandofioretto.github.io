#ifndef STATISTICS_H
#define STATISTICS_H

#include "globals.h"

enum t_stats { t_sampling, t_init, t_copy, t_statistics, t_stat_size};

class Statistics
{
 private:
  timeval time_stats[t_stat_size];  
  double t_search_limit;
  double t_total_limit;
  double time_start[t_stat_size];
  double time[t_stat_size];
  double total_time[t_stat_size];
  int n_MC_trials;
  int n_MC_fails;

 public:
  Statistics();
  Statistics(int argc, char* argv[]);
  ~Statistics();

  void reset(); 
  void set_search_timeout (double sec);
  void set_total_timeout (double sec);
  void set_timer (t_stats t);
  void force_set_time(t_stats t);
  double get_timer (t_stats t);
  double get_total_timer (t_stats t);
  void stopwatch (t_stats t);
  bool timeout ();  
  bool timeout_searchtime_only ();
  void set_nMC_trials( int ntrials );
  void incr_MC_fails();


  size_t getMaxRSS() const; 
  void dump( std::ostream &os=std::cout );

};

#endif
