#include "globals.h"
#include "io_utils.h"
#include "graph.h" // edge_t
#include "cpff_headers.h"
#include "inference_ensemble.h"
#include "solution.h"
#include "prior_utils.h"

//#define VERBOSE

using namespace std;

void IO::parse(int argc, char* argv[]) 
{
  string pathgs;
  bool set_tf = false;
  for( int i=0; i < argc; i++ ) 
  {
    if ( ! strcmp( "--gn-pred-file", argv[ i ] ) )
    {
      fout_sol = argv[ ++i ];
    }
    if( ! strcmp( "--components", argv[ i ] ) ) 
    {
      int size = read_names( argv[ ++i ] );  
      g_InfKB.nnodes = size;
      g_InfKB.nedges = size*size;
      g_InfKB.causal = true;
    }
    if ( ! strcmp( "--generate-dot", argv[ i ] ) ) 
    {
      fout_dot = argv[ ++i ];
      ths_dot  = atof( argv[ ++i ] );
    }
    if( ! strcmp( "--gold-std", argv[ i ] ) )
    { 
      pathgs  = argv[ ++i ]; 
    }
    if( ! strcmp( "--use-prior-tf", argv[ i ] ) )
    { 
      set_tf = true;
    }
  }
#ifdef VERBOSE
  cout << "  Importing gold standard...\n";
#endif
  g_InfKB.goldStd = new Graph( g_InfKB.nnodes, g_InfKB.causal );
  read_graph( g_InfKB.goldStd, pathgs, false );
#ifdef VERBOSE
  cout << "  N. genes: " << g_InfKB.nnodes 
       << " N. edges: " << g_InfKB.nedges << endl;
#endif  
  if( set_tf ) {
    if( g_TFs.empty() ) Prior::set_TFs();
    if( g_TGs.empty() ) Prior::set_TGs();
  }
}
//-

Graph* IO::make_graph (std::vector<Variable*> E)
{
  size_t n = g_gene_ids.size(); 
  Graph *G = new Graph(n);
  for( int i = 0; i < E.size(); i++ )
  {
    std::pair<int,int> edge = g_var_edge[ E[ i ]->id() ];
    double w = E[ i ]->value();
    G->insert( edge.first, edge.second, w );
  }
  
  return G;
}
//-

void IO::read_graph( Graph *G, string path, bool accept_zero)
{
  ifstream data_file;
  data_file.open (path.c_str());
  assert (data_file.is_open()); 
  string line;


  do
  {
    getline ( data_file, line );
    stringstream sline( line );
    string parent, child;
    double confidence = 0.0;
    
    sline.precision(16);
    sline >> parent >> child >> confidence;
    if ( accept_zero || confidence > 0 )
    {
      if ( parent.compare( child ) != 0 )
	G->insert( g_gene_ids[ parent ], 
		   g_gene_ids[ child ], 
		   confidence );
    }
  } while (line.size() > 0);
}
//-

/*
 * Read a list of components name and return the
 * size of the set.
 */
int IO::read_names( string path )
{
  ifstream in;
  in.open (path.c_str());
  assert (in.is_open()); 
  string gene_name;
  static size_t gene_id = 1;

  in >> gene_name;
  while( !in.eof() )
  {
    g_gene_names[ gene_id ] = gene_name;
    g_gene_ids[ gene_name ] = gene_id++;
    in >> gene_name;
  }
  return gene_id - 1;
}
//-


void IO::dump_csp_sol( int append ) 
{
  char fileout[256];
  if ( append >= 0 )
    sprintf( fileout, "%s_%d.txt", fout_sol.c_str(), append);
  else
    sprintf( fileout, "%s", fout_sol.c_str() );
  ofstream os (fileout /*fout_sol.c_str()*/, ios::out);

  if (!os.is_open()) {
    cout << "Error: cannot access to file: " << fout_sol 
	 << " while writing the gene network prediction\n";
    return;
  }

  // Sort Edges in descending order
  std::vector<edge_t> edges;
  std::map<std::pair<int,int>,int>::const_iterator vit = 
    g_edge_var.begin();
  for( ; vit != g_edge_var.end(); ++vit )
  {
    edges.push_back( make_pair( vit->first, 
				g_var_set[vit->second]->value() )); 
  }
  sort( edges.begin(), edges.end(), cmp_second_geq<edge_t> );

  // Dump prediction
  for( int e = 0; e < edges.size(); e++ ) 
  {
    if (edges[ e ].first.first != edges[ e ].first.second && 
	edges[ e ].second > 0) // we could avoid this check..
      { 
      os << "G" << edges[ e ].first.first << "\t"
	 << "G" << edges[ e ].first.second << "\t"
	 << edges[ e ].second << endl;
    }
  }
  os.close();
}
//-

void IO::dump_sol( Solution S, int append ) 
{
  char fileout[256];
  if ( append >= 0 )
    sprintf( fileout, "%s_%d.txt", fout_sol.c_str(), append);
  else
    sprintf( fileout, "%s", fout_sol.c_str() );
  ofstream os (fileout /*fout_sol.c_str()*/, ios::out);

  if (!os.is_open()) {
    cout << "Error: cannot access to file: " << fout_sol 
	 << " while writing the gene network prediction\n";
    return;
  }

  // Sort Edges in descending order
  std::vector<edge_t> edges;
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it, i++)
  {
    int vid = it->first; // var id / idx
    edges.push_back ( make_pair( g_var_edge[ vid ], (double)S[ i ] ) ); 
  }
  sort( edges.begin(), edges.end(), cmp_second_geq<edge_t> );

  // Dump prediction
  for( int e = 0; e < edges.size(); e++ ) 
  {
    if (edges[ e ].first.first != edges[ e ].first.second && 
	edges[ e ].second > 0) // we could avoid this check..
    {
      os << g_gene_names[ edges[ e ].first.first ] << "\t"
	 << g_gene_names[ edges[ e ].first.second ] << "\t"
	 << edges[ e ].second << endl;
    }
  }
  os.close();
}
//-


void IO::dump_sol( const Graph &G, int append ) 
{
  char fileout[256];
  if ( append >= 0 )
    sprintf( fileout, "%s_%d.txt", fout_sol.c_str(), append);
  else
    sprintf( fileout, "%s", fout_sol.c_str() );
  ofstream os (fileout /*fout_sol.c_str()*/, ios::out);
  
  if (!os.is_open()) 
  {
    cout << "Error: cannot access to file: " << fout_sol 
	 << " while writing the gene network prediction\n";
    return;
  }

  // Sort Edges in descending order
  std::vector<edge_t> edges = G.sorted_edges();

  // Dump prediction
  for( int e = 0; e < edges.size(); e++ ) 
  {
    if (edges[ e ].first.first != edges[ e ].first.second && 
	edges[ e ].second > 0) // we could avoid this check..
      { 
      os << "G" << edges[ e ].first.first << "\t"
	 << "G" << edges[ e ].first.second << "\t"
	 << edges[ e ].second << endl;
    }
  }
  os.close();
}
//-


// Syntactic sugar to plot DOT graphs
string find_DOT_color ( edge_t edge, const Graph& gold_std) 
{ 
  pair<int,int> e = edge.first;
  double w  = edge.second;
  string tp = "colorscheme=greens9, color=";
  string fp = "colorscheme=reds9, color=";
  stringstream ss;
  int i = (int) ( w * 10 );
  if (i >= 10) i = 9;
  if (i <= 2) i = 2;
  ss << i;
  // True Positive
  if ( gold_std.edge( e.first, e.second) ) return ( tp + ss.str() );  
  // False Positive
  return ( fp + ss.str() );  
}
//-

// Color Scheme is interpreted as follows:
// False Positive:   color=1 ... color=5  (with 1=worst)
// True Positive:    color=6 ... color=10 (with 10=best)
void IO::dump_DOT( const Graph& net, const Graph& gold_std, double THS ) 
{
  if (THS < 0) THS = ths_dot; 
  char fileout[256];
  sprintf( fileout, "%s_%f.dot", fout_dot.c_str(), THS);
  ofstream os (fileout /*fout_sol.c_str()*/, ios::out);
  if (!os.is_open()) {
    cout << "Error: cannot access to file: " << fout_dot 
	 << " while generating the DOT output file\n";
    return;
  }
  if (!os.is_open()) {
    cout << "Error: cannot access to file: " << fout_dot 
	 << " while generating the DOT output file\n";
    return;
  }

  os << "digraph G {\n" 
     << "size=\"8,8\"; " << "center = true; " << "overlap = false; "
     << endl;

  std::vector<edge_t> edges = net.sorted_edges();
  for( int i=0; i < edges.size(); i++ )
  {
    pair<int,int> edge = edges[ i ].first;
    double w = edges[ i ].second;
    if (w < THS) break;

    if( !net.is_directed() && edge.first > edge.second )
      continue;

    string color = find_DOT_color( edges[ i ], gold_std );
    os << edge.first << " -> " << edge.second << " [";
    if( !net.is_directed() ) os << "dir=none ";
    os << color << "]\n";
  }
  os << "}";
  os.close();
}
//-


// Color Scheme is interpreted as follows:
// False Positive:   color=1 ... color=5  (with 1=worst)
// True Positive:    color=6 ... color=10 (with 10=best)
void IO::dump_sol_DOT( Solution& S, Graph& gold_std, double THS ) 
{
  if (THS < 0) THS = ths_dot;

  char fileout[256];
  sprintf( fileout, "%s_%f.dot", fout_dot.c_str(), THS);
  ofstream os (fileout /*fout_sol.c_str()*/, ios::out);
  if (!os.is_open()) {
    cout << "Error: cannot access to file: " << fout_dot 
	 << " while generating the DOT output file\n";
    return;
  }

  os << "digraph G {\n" 
     << "size=\"8,8\"; " << "center = true; " << "overlap = false; "
     << endl;

  // Sort Edges in descending order
  std::vector<edge_t> edges;
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it, i++)
  {
    int vid = it->first; // var id / idx
    edges.push_back ( make_pair( g_var_edge[ vid ], (double)S[ i ] ) ); 
  }
  sort( edges.begin(), edges.end(), cmp_second_geq<edge_t> );

  for( int i=0; i < edges.size(); i++ )
  {
    pair<int,int> edge = edges[ i ].first;
    double w = edges[ i ].second;
    if (w < THS) break;

    string color = find_DOT_color( edges[ i ], gold_std );
    os << g_gene_names[ edge.first ] << " -> " 
       << g_gene_names[ edge.second ] << " [";
    os << color << "]\n";
  }
  os << "}";
  os.close();
}
//-


/* ******************************************************* *
 * STANDARD DUMP FUNCTIONS
 * ******************************************************* */
void IO::dump( std::vector< int > V )
{
  for ( int i=0; i < V.size(); i++ )
  {
    if (i % 30 == 29) std::cout << endl;
    std::cout << V[ i ] << " ";
  }
  std::cout << endl;
}
//-

void IO::dump( std::vector< double > V )
{
  cout.precision(2);
  for ( int i=0; i < V.size(); i++ )
  {
    if (i % 30 == 29) std::cout << endl;
    std::cout << V[ i ] << " ";
  }
  std::cout << endl;
}
//-


void IO::dump( std::vector< std::pair<int,int> > V )
{
  for ( int i=0; i < V.size(); i++ )
  {
    if (i % 10 == 9) std::cout << std::endl << "              ";
    std::cout << "(" << V[ i ].first << ", " << V[ i ].second << ") ";
  }
  std::cout << endl;
}
//-

void IO::dump( std::vector< edge_t > V )
{
  cout.precision(2);
  for ( int i=0; i < V.size(); i++ )
  {
    std::cout << g_gene_names[V[ i ].first.first]
	      << " -> " << g_gene_names[V[ i ].first.second]
	      << " / " << V[ i ].second << "\n ";
  }
  std::cout << endl;
}
//-
