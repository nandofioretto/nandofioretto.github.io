#include "globals.h"
#include "prior_utils.h"
#include "graph.h"
#include "inference_ensemble.h"
#include "math_utils.h"
#include "io_utils.h"

#include "cpff_headers.h"

// #define VERBOSE
using namespace std;

/**************************************************************
 * TF CONSTRAINT
 * - params ok! [ Dec. 14 2013 ]
 * - got the best combination out of many i could think
 *************************************************************/  
void Prior::set_constr_TF( InferenceEnsemble& g_Ensemble )
{
  if( g_TFs.empty() ) set_TFs();

  Graph* gComNet = g_Ensemble.get(make_pair(CN, MetType_undef));
  int k = log( g_InfKB.nnodes );
  int n = g_InfKB.nnodes;
  double theta = gComNet->sorted_edges()[ n ].second;
  double eta = gComNet->sorted_edges()[ n*log(n) ].second;
  double wCN_tf, wCN_tg;

#ifdef VERBOSE
  cout << " TF constraint, ATLEAST( k=" << k << ", theta=" << theta << ")\n";
#endif

  map<string,int>::iterator gn_i_it; // gene names to id
  vector<int> vars_dir(2);
  vector<int> icoef_dir;
  vector<double> rcoef_dir(2);

  for( int i = 0; i < g_TFs.size(); i++ )
   {
      vector<int> vars_tf;
      vector<int> icoef_tf;
      vector<double>rcoef_tf;
      int tf = g_TFs[ i ];
      gn_i_it = g_gene_ids.begin(); 
      for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
      {
	int tg = gn_i_it->second;
	int vout = g_edge_var[ make_pair( tf, tg ) ]; 
	int vin = g_edge_var[ make_pair( tg, tf ) ];	

	if( tf == tg ) continue;

	vars_tf.push_back( vout );		   // tf constraint
	
	if( g_var_set[ vout ]->dom.ub() < theta ) {
	  g_var_set[ vout ]->dom.add( theta );
	  g_var_set[ vout ]->reset_label();
	  g_var_set[ vout ]->unassign();
	}
	
	// -> try to add 0 only if tg not in TF set 
	if( find( g_TFs.begin(), g_TFs.end(), tg ) == g_TFs.end() )
	  {
	    vars_dir[ 0 ] = vout; vars_dir[ 1 ] = vin; // directionality constraint
	    wCN_tf = gComNet->get_edge_weight( tf, tg );
	    wCN_tg = gComNet->get_edge_weight( tg, tf );
	    rcoef_dir[ 0 ] = wCN_tf;
	    rcoef_dir[ 1 ] = wCN_tg;
	    g_var_set[ vin ]->dom.add( 0 );
	    new Constraint( ONE_DIR, vars_dir, icoef_dir, rcoef_dir );
	  }
      }
      icoef_tf.push_back( k );
      rcoef_tf.push_back( theta );
      new Constraint( ATLEAST_K_GE, vars_tf, icoef_tf, rcoef_tf );
    }
}


/**************************************************************
 * TG CONSTRAINT
 * - params ok! [ Dec. 9 2013 ]
 *************************************************************/  
void Prior::set_constr_TG( InferenceEnsemble& g_Ensemble )
{
  if( g_TGs.empty() ) set_TGs();
 
  vector<int> icoef;
  vector<double>rcoef;
  vector<int> vars;
  for( int tg = 0; tg < g_TGs.size(); tg++ )
  {
    icoef.clear(); rcoef.clear(); vars.clear();
  
    map<string,int>::iterator it; // gene names to id
    it = g_gene_ids.begin(); 
    for( ; it != g_gene_ids.end(); ++it )
    {
      int tf = it->second;
      if( tf == g_TGs[ tg ] ) continue;
      int v = g_edge_var[ make_pair( g_TGs[tg], tf ) ];
      vars.push_back( v );

      g_var_set[ v ]->dom.add( 0 );
      g_var_set[ v ]->set_label( 0 );
      g_var_set[ v ]->dom.set_singleton( 0 );
    }
  }
}

vector<int> get_co_reg( vector<edge_t> Ni, vector<edge_t> Nj) 
{
  vector<int> coreg;
  for( int i=0; i<Ni.size(); i++) {
    for( int j=0; j<Nj.size(); j++) {
      if( Ni[ i ].first.second == Nj[ j ].first.second &&
	  find(g_TFs.begin(), g_TFs.end(), Ni[i].first.second) == g_TFs.end())
	{ coreg.push_back( Ni[ i ].first.second ); break; }
    }
  }
  return coreg;
}

void Prior::set_constr_Co_TF( InferenceEnsemble& E )
{
  if( g_TFs.empty() ) set_TFs();
  Graph *gold = g_InfKB.goldStd;
  Graph* gComNet = E.get(make_pair(CN, MetType_undef));
  int k = log( g_InfKB.nnodes );
  int n = g_InfKB.nnodes;
  double theta = gComNet->sorted_edges()[ k ].second;
  
  // find all the genes regulated by 2 or more transcription factors.
  vector<int> icoef(1, k); vector<double> rcoef(1, theta);

  vector<int> vars_dir(2); 
  vector<int> icoef_dir;
  vector<double> rcoef_dir(2);

  map<string,int>::iterator gn_i_it; // gene names to id

  for( int i = 0; i < g_TFs.size()-1; i++ )
  {
    int tfi = g_TFs[ i ];
    vector<edge_t> Ni = gold->get_neighbors( tfi );
    for( int j = i+1; j < g_TFs.size(); j++ )
    {
      int tfj = g_TFs[ j ];
      vector<int> vars;
      vector<edge_t> Nj = gold->get_neighbors( tfj );
      vector<int> coregs = get_co_reg( Ni, Nj );
      
      if( coregs.size() > 1)
      {

	// retrieve all vars neigb. of tfi and tfj and save them one and one.
	gn_i_it = g_gene_ids.begin(); 
	for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
	{
	  int tg = gn_i_it->second;
	  int tfi_tg = g_edge_var[ make_pair( tfi, tg ) ]; 
	  int tfj_tg = g_edge_var[ make_pair( tfj, tg ) ];	
	  // DIRECTIONALITY CONSTRAINT: 
	  // add 0 only if tg not in TF set 
	  if( find( g_TFs.begin(), g_TFs.end(), tg ) == g_TFs.end() )
	  {
	    int tg_tfi = g_edge_var[ make_pair( tg, tfi ) ]; 
	    vars_dir[ 0 ] = tfi_tg; vars_dir[ 1 ] = tg_tfi;
	    rcoef_dir[ 0 ] = gComNet->get_edge_weight( tfi, tg );
	    rcoef_dir[ 1 ] = gComNet->get_edge_weight( tg, tfi );
	    g_var_set[ tg_tfi ]->dom.add( 0 );
	    new Constraint( ONE_DIR, vars_dir, icoef_dir, rcoef_dir );

	    int tg_tfj = g_edge_var[ make_pair( tg, tfj ) ]; 
	    vars_dir[ 0 ] = tfj_tg; vars_dir[ 1 ] = tg_tfj;
	    rcoef_dir[ 0 ] = gComNet->get_edge_weight( tfj, tg );
	    rcoef_dir[ 1 ] = gComNet->get_edge_weight( tg, tfj );
	    g_var_set[ tg_tfj ]->dom.add( 0 );
	    new Constraint( ONE_DIR, vars_dir, icoef_dir, rcoef_dir );
	  }
	  //-

	  if( g_var_set[ tfi_tg ]->dom.ub() < theta ) {
	    g_var_set[ tfi_tg ]->dom.add( theta );
	    g_var_set[ tfi_tg ]->reset_label();
	    g_var_set[ tfi_tg ]->unassign();
	  }
	  if( g_var_set[ tfj_tg ]->dom.ub() < theta ) {
	    g_var_set[ tfj_tg ]->dom.add( theta );
	    g_var_set[ tfj_tg ]->reset_label();
	    g_var_set[ tfj_tg ]->unassign();
	  }
	  vars.push_back( tfi_tg );
	  vars.push_back( tfj_tg );
	}
	new Constraint( COTF, vars, icoef, rcoef );
	break;
      }
            
    }
  }
}

/**************************************************************
 * Local Sparse CONSTRAINT
 * - params ok! [ Dec. 19 2013 ]
 * - Impose each gene with at most lg(n) outgoing edges 
 *************************************************************/  
void Prior::set_local_sparsness( InferenceEnsemble& E )
{
  std::map<string,int>::iterator gn_i_it; // gene names to id
  std::map<string,int>::iterator gn_j_it; // gene names to id
  Graph* cn = E.get( make_pair( CN, MetType_undef ) );

  int k = ceil(log(g_InfKB.nnodes));
  vector<int> vars(g_InfKB.nnodes);
  vector<int> icoef(1);
  vector<double> rcoef(1);

  gn_i_it = g_gene_ids.begin();
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    // uncomment if activate TF constraint
    if( find( g_TFs.begin(), g_TFs.end(), s ) != g_TFs.end() ) continue;

    double ths = 0.5; double ao = 0;
    do {
      ths += 0.01;
      ao = cn->avg_weight_out( s, ths );
    }while( cn->out_deg( s, ao ) > k );

    rcoef[0] = ths; // or ao ??
    icoef[0] = k;
    gn_j_it = g_gene_ids.begin();
    int i = 0;
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int u = gn_j_it->second;
      vars[i++] = g_edge_var[ make_pair( s, u ) ];
    }
    new Constraint( ATMOST_K_GE, vars, icoef, rcoef );
  }

}

/**************************************************************
 * Global Sparse CONSTRAINT
 * - params ok! [ Dec. 19 2013 ]
 * - Impose each gene with at most lg(n) outgoing edges 
 *************************************************************/
void Prior::set_global_sparsness( InferenceEnsemble& E )
{
  std::map<string,int>::iterator gn_i_it; // gene names to id
  std::map<string,int>::iterator gn_j_it; // gene names to id
  Graph* cn = E.get( make_pair( CN, MetType_undef ) );

  int k = ceil(log(g_InfKB.nnodes));
  vector<int> vars(g_InfKB.nnodes);
  vector<int> icoef(2);
  vector<double> rcoef(1);
  double avg = 0;

  gn_i_it = g_gene_ids.begin();
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    double ths = 0.5; double ao = 0;
    while( ao == 0 ) {
      ths-=0.1;
      ao = cn->avg_weight_out( s, ths );
    }// fix the ao if it is 0
    do {
      ths += 0.001;
      ao = cn->avg_weight_out( s, ths );
    }while( cn->out_deg( s, ao ) > k );
    avg += ths;
  }
  avg /= g_gene_ids.size();
  rcoef[0] = avg;
  icoef[0] = k*g_InfKB.nnodes; // Km
 
  gn_i_it = g_gene_ids.begin();
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    // the floowing line works only if TF constraint is active
    if( find( g_TFs.begin(), g_TFs.end(), s ) != g_TFs.end() ) continue;
  
    gn_j_it = g_gene_ids.begin();
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int u = gn_j_it->second;
      int vid = g_edge_var[ make_pair( s, u ) ];
      vars.push_back( vid );
    }
  }
  new Constraint( ATMOST_K_GE, vars, icoef, rcoef );


  int kl = g_InfKB.nnodes;
  vars.clear();
  avg = 0;

  gn_i_it = g_gene_ids.begin();
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    double ths = 1.0; double ao = 0;
    do {
      ths -= 0.001;
      ao = cn->avg_weight_out( s, ths );
    }while( cn->out_deg( s, ths ) <= 1 );
    avg += ths;
  }
  avg /= g_gene_ids.size();
  rcoef[0] = avg;
  icoef[0] = kl;

  gn_i_it = g_gene_ids.begin();
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    // the floowing line works only if TF constraint is active
    if( find( g_TFs.begin(), g_TFs.end(), s ) != g_TFs.end() ) continue;
  
    gn_j_it = g_gene_ids.begin();
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int u = gn_j_it->second;
      int vid = g_edge_var[ make_pair( s, u ) ];
      vars.push_back( vid );
    }
  }
  new Constraint( ATLEAST_K_GE, vars, icoef, rcoef );

}

void re_params
( InferenceEnsemble& E,  double &b1, double &b2, double &b3, double &b4 );

/**************************************************************
 * DIR-SEL CONSTRAINT
 * dir-sel( <s,t>, <t,s> ) = <t,s> < min( <s,t>, 1-<s,t> )
 *************************************************************/  
void Prior::set_constr_edge_dir( InferenceEnsemble& g_Ensemble )
{
  double a=0,b=0,c=0,d=0;
  re_params( g_Ensemble, a,b,c,d);
  vector<int> vars(2);
  vector<int> icoef;
  vector<double> rcoef(2);
  Graph* gComNet = g_Ensemble.get(make_pair(CN, MetType_undef));
  double wCN_req, wCN_red;
  int count_tftf = 0, count_tgtg = 0, count_tftg = 0, count_tgtf = 0;

  Graph* g_GoldStd = g_InfKB.goldStd;
  int count = 0;
  std::map<std::pair<int,int>,int>::iterator it;
  it = g_edge_var.begin();
  while( ++it != g_edge_var.end() )
    {
      int s = it->first.first, t = it->first.second;
      if (s == t ) continue;
      if (! is_redundant_edge(g_Ensemble, t, s, a, b,c,d ) ) continue;
      
      if( find( g_TFs.begin(), g_TFs.end(), t ) != g_TFs.end() ) continue;

      // t->s REDUNDANT / s->t REQUIRED
      vars[ 0 ] = g_edge_var[ make_pair(s, t) ]; // required
      vars[ 1 ] = g_edge_var[ make_pair(t, s) ]; // redundant
      
      if( g_GoldStd->edge(s,t) && g_GoldStd->edge(t,s) ) count_tftf++;
      if( g_GoldStd->edge(s,t) && !g_GoldStd->edge(t,s) ) count_tftg++;
      if( !g_GoldStd->edge(s,t) && g_GoldStd->edge(t,s) ) count_tgtf++;
      if( !g_GoldStd->edge(s,t) && !g_GoldStd->edge(t,s) ) count_tgtg++;

      wCN_req = gComNet->get_edge_weight( s, t );
      wCN_red = gComNet->get_edge_weight( t, s );
      rcoef[ 0 ] = wCN_req;
      rcoef[ 1 ] = wCN_red;

      Variable *vq = g_var_set[ g_edge_var[ make_pair(s, t) ] ];
      Variable *vd = g_var_set[ g_edge_var[ make_pair(t, s) ] ];

      double m = min( vq->dom.lb(),abs(1 - vq->dom.ub()));
      vd->dom.add( 0 );
      new Constraint( ONE_DIR, vars, icoef, rcoef );
    }

#ifdef VERBOSE
  cout << "Constraints: TF->TG: " << count_tftg << endl;
  cout << "Constraints: TF->TF: " << count_tftf << endl;
  cout << "Constraints: TG->TF: " << count_tgtf << endl;
  cout << "Constraints: TG->TG: " << count_tgtg << endl;
#endif
}


/**************************************************************
 * Network Module Constraint
 * simple assumption: 
 * - each module is identified by 1 TF and the set of genes it 
 *   regulates.
 * - it a TF regulates another TF, then the group could be inte-
 *   if both TF co-regulates at least X
 * - if a TF regulates another TF, then the latter cannot be
 *   constrainted on the number of outgoing arcs. 
 * ok - checked which variables goes in the ok and ko sets - Dec12
*************************************************************/  
void Prior::set_constr_network_module( InferenceEnsemble& E )
{
  // Get modules with 100% of accuracy.
  // s
  std::vector<int> TFs;
  Graph *gold = g_InfKB.goldStd;
  map<string,int>::iterator gn_i_it; // gene names to id
  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    if( gold->out_deg( s, 0 ) > 0 )
      {
	TFs.push_back( s );
      }
  }
  
  for( int i = 0; i < TFs.size(); i++ )
    {

      std::vector<int> vars;
      std::vector<int> icoef(3, 0); // 0 -> ko
				// 1 -> ok
				// 2 -> num max of ok
      std::vector<double> rcoef; // thresholds to set to turn on off
				// in last analysis will be 
      vector<int> dir_ok;
      vector<int> dir_ko;
      icoef[ 0 ] = 0; // num (k) of vars to turn off (first k vars)
      icoef[ 1 ] = 0; // num of vars that can be turned on (remaining)

      //<int, int>, double
      vector<edge_t> Ni = gold->get_neighbors( TFs[ i ], 0 );
      // scan all neighbours of TF_i
      for( int j = 0; j < Ni.size(); j++ )
	{	  
	  int tg_i = Ni[ j ].first.second;
	  int tf_tg = g_edge_var[ Ni[ j ].first ];
	  int tg_tf = g_edge_var[ make_pair( tg_i, TFs[ i ]) ];
	  
	  if( std::find( TFs.begin(), TFs.end(), tg_i ) == TFs.end() )
	    {
	      // these nodes won't have outgoing edges with any of the
	      // nodes inside the same group
	      dir_ok.push_back( tf_tg );  
	      dir_ko.push_back( tg_tf );
	      icoef[ 1 ] ++;
	      icoef[ 0 ] ++;
	    }
	  else
	    {
	      // these variables may have outgoing edges with nodes 
	      // inside this group.
	      dir_ok.push_back( tf_tg );  
	      dir_ok.push_back( tg_tf );
	      icoef[ 1 ]+=2;
	    }
	}
      // dir_ok are all the edges that could be turned on
      // dir_ko are all the edges that must be turned off

      vars = dir_ko;
      vars.insert (vars.end(), dir_ok.begin(), dir_ok.end());
      new Constraint( NET_MODULE, vars, icoef, rcoef );
    }
}



/**************************************************************
 * Aux Functions
 *************************************************************/  
bool Prior::is_redundant_edge( InferenceEnsemble& E, int t, int s, 
			       double b1, double b2, double b3, double b4 )
{
  int count = 0;
  // Genie3
  Graph* pred = E.get( 3 ).second.first;
  count += (pred->get_edge_weight(s,t) - pred->get_edge_weight(t,s)) > b1;

  // Tigress
  pred = E.get( 4 ).second.first;
  count += (pred->get_edge_weight(s,t) - pred->get_edge_weight(t,s)) > b2;
  
  pred = E.get( 5 ).second.first;
  count += (pred->get_edge_weight(s,t) - pred->get_edge_weight(t,s)) > b3;

  pred = E.get( 6 ).second.first;
  count += (pred->get_edge_weight(s,t) - pred->get_edge_weight(t,s)) > b4;

  return ( count >= 4/* OF 4 Methods*/ );
}

void Prior::community_network_params
( InferenceEnsemble& E, double &L, double &U, double &theta_d )
{
  Graph* gComNet = E.get( make_pair( CN, MetType_undef ) );
  map<string,int>::iterator gn_i_it; // gene names to id
  map<string,int>::iterator gn_j_it; // gene names to id
  double mu = 0.0;
  int mu_count = 0;
  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = g_gene_ids.begin(); 
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      
      double avg_wDiscordance   = 0.0;
      int    n_MethodsPairs = 0;
      for( int i = 0; i < E.size(); i++ )
      {
	if ( E.get( i ).first.first == CN ) continue;  // CN prediction 	
	_gEntry eGi = E.get( i ).second;
	double wi = eGi.first->get_edge_rank( s, t );
	for( int j = i+1; j < E.size(); j++ )
      	{
	  if ( E.get( j ).first.first == CN ) continue;  // CN prediction 
	  _gEntry eGj = E.get( j ).second;
	  double wj = eGj.first->get_edge_rank( s, t );
	  avg_wDiscordance += abs( wi - wj ); 
	  n_MethodsPairs ++;
	}
      }
      //-
      double wd_st = avg_wDiscordance / (double)(n_MethodsPairs * g_InfKB.nedges) ;
      mu += wd_st;
      mu_count ++;
    }//- node t
  }//- node s
  
  int N  = g_InfKB.nnodes; // 10 %
  int NN = g_InfKB.nedges - (g_InfKB.nedges/10);  // 90 %

  theta_d = ( mu / mu_count );
  L = gComNet->sorted_edges()[ NN ].second;
  U = gComNet->sorted_edges()[ N ].second;
}//-


void Prior::redundant_edge_params
( InferenceEnsemble& E,  double &beta )
{
  Graph* gComNet = E.get( make_pair( CN, MetType_undef ) );
  map<string,int>::iterator gn_i_it; // gene names to id
  map<string,int>::iterator gn_j_it; // gene names to id
  double mu = 0.0;
  int mu_count = 0;
  gn_i_it = g_gene_ids.begin(); 
  // Mean of the CN
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = gn_i_it;
    std::advance (gn_j_it,1);
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      mu += abs(gComNet->get_edge_weight( s, t ) -
  	gComNet->get_edge_weight( t, s ) );
      mu_count ++;
    }//- node t
  }//- node s
  
  mu /= (mu_count);
  // beta = mu;
  // return;
  
  // now compute the sd:
  double var = 0;
  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = gn_i_it;
    std::advance (gn_j_it,1);

    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      double xi = 
  	abs( gComNet->get_edge_weight( s, t ) -
  	     gComNet->get_edge_weight( t, s ) );
      var += (xi - mu) * (xi - mu);
    }//- node t
  }//- node s

  beta = ( var / mu_count );

}//-


void re_params
( InferenceEnsemble& E,  double &b1, double &b2, double &b3, double &b4 )
{
  Graph* gComNet = E.get( make_pair( CN, MetType_undef ) );
  map<string,int>::iterator gn_i_it; // gene names to id
  map<string,int>::iterator gn_j_it; // gene names to id
  double mu[4] = {0,0,0,0};
  int mu_count = 0;

  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = gn_i_it;
    std::advance (gn_j_it,1);
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      for( int i=0;i<4;i++)
	{
	  Graph* pred = E.get( i+3 ).second.first; 
	  mu[i] =(pred->get_edge_weight(s,t) - pred->get_edge_weight(t,s));
	}
      mu_count ++;
    }//- node t
  }//- node s
  
  for( int i=0;i<4;i++)
    mu[i] /= (mu_count);
  b1=mu[0];
  b2=mu[1];
  b3=mu[2];
  b4=mu[3];
}//-



void Prior::set_TFs( )
{
  Graph *gold = g_InfKB.goldStd;

  std::vector<std::pair<int,int> > out_degs;
  for( int v = 0; v < gold->V(); v++ )
  {
    if ( gold->out_deg( v, 0 ) > 0 )
      out_degs.push_back( make_pair( v, gold->out_deg( v ) ) );
  }
  std::sort( out_degs.begin(), out_degs.end(), cmp_second_geq<pair<int,int> > );
  
  for( int s = 0; s < out_degs.size(); s++){
    g_TFs.push_back( out_degs[s].first );
  }
}

void Prior::set_TGs( )
{
  Graph *gold = g_InfKB.goldStd;
  map<string,int>::iterator gn_i_it; // gene names to id
  gn_i_it = g_gene_ids.begin(); 

  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    int s = gn_i_it->second;
    if ( gold->out_deg( s, 0 ) == 0 )
      g_TGs.push_back( s );
  }
}
