// SOLVER_UTILS
#include "globals.h"
#include "solver_utils.h"
#include "graph.h"
#include "inference_ensemble.h"
#include "cpff/cpff_headers.h"
#include "math_utils.h"
#include "prior_utils.h"

using namespace std;

//#define DBG_VUTILS
//#define VERBOSE


void Utils::create_variables( InferenceEnsemble& E )
{
  /* Retireve the CN graph */
  Graph* gComNet = E.get( make_pair( CN, MetType_undef ) );

  /* Retrieve Parameters */
  double L,U,theta_d;
  Prior::community_network_params( E, L, U, theta_d );
#ifdef VERBOSE
  cout << "  CN params [" << L << " " << U << "] theta: " << theta_d << endl;  
#endif
  map<string,int>::iterator gn_i_it; // gene names to id
  map<string,int>::iterator gn_j_it; // gene names to id
  double A = 0; int nA = 0;
  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = g_gene_ids.begin();
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      vector<double> domain;
      double lb = -1, ub = -1;
      
      // Check that initial weight is well ranked!
      double wCN_st = gComNet->get_edge_weight( s, t );

      if ( Math::in_range(wCN_st, L, U) ) 
      {
	double avg_wDiscordance = 0.0;
	int    n_MethodsPairs   = 0;
	/* Compute the average parwise weight discordance among all the
	   methods in the enseble */
	for( int i = 0; i < E.size(); i++ )
	{
	  if ( E.get( i ).first.first == CN ) continue;  // CN prediction 
	  _gEntry eGi = E.get( i ).second;
	  double wi = eGi.first->get_edge_rank( s, t );
	  for( int j = i+1; j < E.size(); j++ )
      	  {
	    if ( E.get( j ).first.first == CN ) continue;  // CN prediction 
	    _gEntry eGj = E.get( j ).second;
	    double wj = eGj.first->get_edge_rank( s, t );
	    avg_wDiscordance += abs( wi - wj );
	    n_MethodsPairs ++;
	  }
	}
	//-
	double norm_avg_wDiscordance = 
	  avg_wDiscordance / (double)(n_MethodsPairs*g_InfKB.nedges);
	if( norm_avg_wDiscordance >= theta_d/2 )
	{
	  lb = max( 0.0, wCN_st - (norm_avg_wDiscordance/2.0) );
	  ub = min( 1.0, wCN_st + (norm_avg_wDiscordance/2.0) );
	}

	A += (norm_avg_wDiscordance/2.0); nA++;
      }
      //- done with discordance

      int l = 0;
      if( lb != -1 ) {domain.push_back( lb ); l++;}
      if( wCN_st != lb ) domain.push_back( wCN_st );
      if( ub != -1 && wCN_st != ub ) domain.push_back( ub );
      
      Variable *v = new Variable(domain);
      v->set_label( l );
      if( domain.size() > 1 ) v->unassign();

      // Save link Edge->Var
      g_edge_var[ make_pair( s, t ) ] = v->id(); // (<i,i>i)
      g_var_edge[ v->id() ] = make_pair( s, t ); // (i,<i,i>)
      g_outgoing_edges_of_node[ s ].push_back( v ); // (i, v...)
      g_neighbours[ s ].push_back( v->id() );	    // (i, v...)
    }//-j
  }//-i
#ifdef VERBOSE
  cout <<  "  Num. of variables: "   <<   g_var_set.size() << endl;
#endif
}
//-


void Utils::create_constraints
( int argc, char* argv[], InferenceEnsemble& E )
{
  for( int i=0; i < argc; i++ ) 
  {
    if ( ! strcmp( "--agreement-limit", argv[ i ] ) ) { ; }
    if ( ! strcmp( "--dir-sel", argv[ i ] ) || 
	 ! strcmp( "--red-edge", argv[ i ] ) ) 
    { 
      Prior::set_constr_edge_dir( E );
    }
    if(!strcmp("--l-sparse", argv[i]))
    {
      Prior::set_local_sparsness( E );
    }
    if(!strcmp("--g-sparse", argv[i]))
    {
      Prior::set_global_sparsness( E );
    }
    if ( ! strcmp( "--tf", argv[ i ] ) ) { 
      Prior::set_constr_TF( E );
    }
    if ( ! strcmp( "--cotf", argv[ i ] ) ) 
    { 
      Prior::set_constr_Co_TF( E ); 
    }
    if ( ! strcmp( "--smallworld", argv[ i ] ) ) { ; }
    if ( ! strcmp( "--freescale", argv[ i ] ) ){ ; }
    if ( ! strcmp( "--patway", argv[ i ] ) ) { ; }
    if ( ! strcmp( "--motif", argv[ i ] ) ) { ; }
    // need to be last one!!
    if ( ! strcmp( "--tg", argv[ i ] ) ) { 
      Prior::set_constr_TG( E );
    }
  }//-
#ifdef VERBOSE
  cout <<  "  Num. of constraints: " <<   g_constr_set.size() << endl;
#endif
}//-


void Utils::dump_variables()
{
  map<string,int>::iterator gn_i_it; // gene names to id
  map<string,int>::iterator gn_j_it; // gene names to id

  gn_i_it = g_gene_ids.begin(); 
  for( ; gn_i_it != g_gene_ids.end(); ++gn_i_it )
  {
    gn_j_it = g_gene_ids.begin(); 
    for( ; gn_j_it != g_gene_ids.end(); ++gn_j_it )
    {
      int s = gn_i_it->second, t = gn_j_it->second;
      Variable *v = g_var_set[ g_edge_var[ make_pair( s, t ) ] ];
      cout << g_gene_names[s] << " -> " << g_gene_names[t]
	   << " [val " << v->value() << "] ";
	v->dom.dump();
    }
  }

}//-
