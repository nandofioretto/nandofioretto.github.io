#ifndef _SOLOPT_FUNCTIONS_ 
#define _SOLOPT_FUNCTIONS_

#include "globals.h"
class Graph;
class Solution;

typedef std::vector< std::pair<Graph*, double> > w_graphs;


namespace SolOpt
{
  // TP: the edge occurs in both the true and the predicted network
  bool truePositive( std::pair<int,int> edge, double conf=1.0 );
  // FP: the edge is predicted but does not occur in the true network
  bool falsePositive( std::pair<int,int> edge, double conf=1.0 );
  // FN: the edge occurs in the true network but is not predicted
  bool falseNegative( std::pair<int,int> edge, double conf=1.0 );

  double get_AUROC( std::vector<double> S );
  double get_Fscore( std::vector<double> S );
  std::pair<double,double> get_measures( std::vector<double> S );
  std::pair<double,double> DREAM_AUC( std::vector<double> S  );

  // Summary and measures
  void summary( std::vector<Solution*> S, Solution CN_rank, bool latex );
  Solution average( std::vector<Solution*> S );
  Solution rank_mode( std::vector<Solution*> S );
  Solution weighted_average( std::vector<Solution*> S );
  Solution hamming_dist( std::vector<Solution*> S );
  Solution eucl_dist( std::vector<Solution*> S );

};

#endif


