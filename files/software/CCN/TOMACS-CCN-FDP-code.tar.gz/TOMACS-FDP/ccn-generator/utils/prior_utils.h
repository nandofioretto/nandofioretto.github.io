#ifndef _PRIOR_UTILS_H
#define _PRIOR_UTILS_H

#include "globals.h"
#include "cpff_headers.h"

class InferenceEnsemble;

namespace Prior
{

  void setRedEdges( InferenceEnsemble& E );
  void set_constr_edge_dir( InferenceEnsemble& E );
  void set_constr_directionality( InferenceEnsemble& E);

  void set_constr_TF( InferenceEnsemble& E );
  void set_constr_TG( InferenceEnsemble& E );
  void set_constr_Co_TF(InferenceEnsemble& E);

  void setSparseness( InferenceEnsemble& g_Ensemble );  
  void set_local_sparsness( InferenceEnsemble& E );

  void set_global_sparsness( InferenceEnsemble& E );
  

  // todo
  void set_constr_indirect_edge_removal( InferenceEnsemble& g_Ensemble );
  void set_constr_network_module( InferenceEnsemble& E );
  void setSmallWold();
  void setFreeScale();
  void setPathways();
  void setMotifs();

  // Parameter Estimation
  void community_network_params
    ( InferenceEnsemble& E, double &L, double &U, double &theta_d );
  void redundant_edge_params
    ( InferenceEnsemble& E,  double &beta );


  // Aux
  void set_TFs();
  void set_TGs();
  bool is_redundant_edge( InferenceEnsemble& E, int t, int s, double b1, double b2, double b3, double b4 );

}//-

#endif
