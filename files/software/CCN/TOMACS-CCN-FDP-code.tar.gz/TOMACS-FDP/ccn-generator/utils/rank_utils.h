#ifndef _RANKING_FUNCTIONS_ 
#define _RANKING_FUNCTIONS_

#include "globals.h"
#include "graph.h"
#include "math_utils.h"

typedef std::vector< std::pair<Graph*, double> > w_graphs;

namespace Rank
{
  inline double Borda_rank ( int x, int y, w_graphs predictions )
  {
    double wI_sum = 0.0,  W_sum = 0.0;
    for (int i = 0; i < predictions.size(); i++) 
    {
      wI_sum += (predictions[ i ].second * 
		 (predictions[ i ].first->get_edge_rank( x, y ) ) );

      W_sum  += predictions[ i ].second;
    }
    //std::cout << "borda rank: [" << x << " " << y << "] " << wI_sum << std::endl;  

    /* 1 - (1/100)  --> 1 - 0.1  = 0.99*/
    /* 1 - (99/100) --> 1 - 0.99 = 0.01 */
    /* 1 - (50/100) --> 1 - 0.5  = 0.5 */	     
    double avg_rank = (( 1 / W_sum ) * wI_sum);
    return Math::rank2pconf( avg_rank );
 
  }//-


  inline double Borda_confidence ( int x, int y, w_graphs predictions )
  {
    double wI_sum = 0.0,  W_sum = 0.0;
    for (int i = 0; i < predictions.size(); i++) 
    {
      wI_sum += (predictions[ i ].second * 
		 predictions[ i ].first->get_edge_weight( x, y ) );
      W_sum  += predictions[ i ].second;
    }
    return (( 1 / W_sum ) * wI_sum );
  }//-


  inline double FishersInvrseChiSquare ( int x, int y, w_graphs predictions )
  {
    double  Sxy = 0.0;
    for (int i = 0; i < predictions.size(); i++) 
    {
      Sxy += log( 1 - predictions[ i ].first->get_edge_weight( x, y ) );
    }
    return ( 1 - exp( Sxy ) );
  }//-

};

#endif


