#ifndef SOLVER_UTILS_H
#define SOLVER_UTILS_H

#include "globals.h"
class InferenceEnsemble;

namespace Utils
{
  void create_variables( InferenceEnsemble& E );
  void create_variables_via_feat_sel( InferenceEnsemble& E );
  void create_variables2( InferenceEnsemble& E );

  void create_constraints( int argc, char* argv[], InferenceEnsemble& E );
  void dump_variables();
};

#endif
