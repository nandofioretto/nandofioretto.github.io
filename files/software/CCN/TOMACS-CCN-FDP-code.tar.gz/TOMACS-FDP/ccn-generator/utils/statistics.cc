#include "statistics.h"
#include "globals.h"

Statistics::Statistics() 
  : t_search_limit( 0 ), t_total_limit( 0 ),
    n_MC_trials( 0 ), n_MC_fails( 0 )
{
  reset();
}

Statistics::Statistics(int argc, char* argv[]) 
  : t_search_limit( 0 ), t_total_limit( 0 ),
    n_MC_trials( 0 ), n_MC_fails( 0 )
{  
  /* Process the input parameters */
  for (int narg = 0 ; narg < argc  ; narg++) {
    if (!strcmp( "--timeout-search", argv[ narg ] ) )
    {
      t_search_limit = atoi( argv[ narg + 1 ] );      
    }//-
    if (!strcmp ("--timeout-total",argv[narg])) 
    {
      t_total_limit = atoi( argv[ narg + 1 ] );      
    }//-
  }

  reset();
}//-  

Statistics::~Statistics() 
{ }//-

void 
Statistics::reset () 
{
  for( int i = 0; i < t_stat_size; i++) 
  {
    time_start[ i ] = 0;
    time[ i ] = 0;
    total_time[ i ] = 0;
  }
}//-

void 
Statistics::set_search_timeout( double sec ) 
{
  t_search_limit = sec;
}//-

void 
Statistics::set_total_timeout( double sec ) 
{
  t_total_limit = sec;
}//-

void 
Statistics::set_timer( t_stats t ) 
{
  gettimeofday( &time_stats[ t ], NULL );
  time_start[ t ] = time_stats[ t ].tv_sec 
    + ( time_stats[ t ].tv_usec / 1000000.0);
}//-

void
Statistics::force_set_time( t_stats t ) 
{
  time[ t ] = t;
}

double 
Statistics::get_timer( t_stats t ) { 
  return time[ t ]; 
}//-

double 
Statistics::get_total_timer ( t_stats t ) 
{ 
  if( t != t_statistics )
    return( total_time[ t ] - total_time[ t_statistics ] );
  else
    return total_time[ t ];
}//-

void 
Statistics::stopwatch( t_stats t ) 
{
  gettimeofday( &time_stats[ t ], NULL );
  time[ t ] = time_stats[ t ].tv_sec 
    + ( time_stats[ t ].tv_usec / 1000000.0 ) 
    - time_start[ t ]; 
  // if( t == t_sampling ) // for t_search we use stopwatch without setting the initial time
  //   total_time[ t ] = time[ t ];
  // else
    total_time[ t ] += time[ t ];
}//-

bool 
Statistics::timeout () 
{
  if (t_total_limit <= 0) 
    return false;
  stopwatch( t_sampling );
  if (total_time[ t_sampling ] >= t_total_limit)
    return true;
  return false;
}//-


void Statistics::set_nMC_trials( int ntrials )
{
  n_MC_trials = ntrials;
}

void Statistics::incr_MC_fails( )
{
  n_MC_fails ++;
}


size_t
Statistics::getMaxRSS() const {
  int len = 0; 
  int srtn = 0;
  char procf[257] = { "" };
  FILE *fp = NULL;
  char line[2001] = { "" };
  char crap[2001] = { "" };
  char units[2001] = { "" };
  size_t maxrss = 0L;
  size_t maxrsskb = 0L;

  sprintf(procf,"/proc/%d/status",getpid());
  
  fp = fopen(procf, "r");
  if(fp == NULL){
    return -1;
  }
  
  while(fgets(line, 2000, fp) != NULL){
    if(strncasecmp(line,"VmPeak:",7) == 0){
      len = (int)strlen(line);
      line[len-1] = '\0';
      srtn = sscanf(line,"%s%ld%s",crap,&maxrss,units);
      if(srtn == 2){
        maxrsskb = maxrss / 1024L;
      }else if(srtn == 3){
        if( (strcasecmp(units,"B") == 0) || (strcasecmp(units,"BYTES") == 0) ){
          maxrsskb = maxrss / 1024L;
        }else if( (strcasecmp(units,"k") == 0) || (strcasecmp(units,"kB") == 0) ){
          maxrsskb = maxrss * 1L;
        }else if( (strcasecmp(units,"m") == 0) || (strcasecmp(units,"mB") == 0) ){
          maxrsskb = maxrss * 1024L;
        }else if( (strcasecmp(units,"g") == 0) || (strcasecmp(units,"gB") == 0) ){
          maxrsskb = maxrss * 1024L * 1024L;
        }else{
          maxrsskb = maxrss * 1L;
        }
      }
      break;
    }
  }
  
  fclose(fp);
  
  return maxrsskb;
}

void 
Statistics::dump (std::ostream &os) 
{
  os << "\t============ GD-Gibbs statistics ============\n";
  os << "COMPUTATION TIME" << std::endl
     << "  Init Time        :  " 
     << get_timer (t_init) << " s.\n"
     << "  Samples " << n_MC_trials - n_MC_fails 
     << " / " << n_MC_trials  << std::endl
     << "  Sampling Time    :  " 
     << get_timer (t_sampling) << " s.\n";  
  os << std::endl;
}//-
