#ifndef _IO_UTILS_H
#define _IO_UTILS_H

#include "globals.h"
#include "cpff_headers.h"

class Variable;
class Graph;
class Solution;

typedef std::pair<std::pair<int,int>,double> edge_t;

namespace IO
{
  static std::string fout_sol;
  static std::string fout_dot;
  static double ths_dot;

  void parse(int argc, char* argv[]);
  void read_graph( Graph *G, std::string path, bool accept_zero = false );
  int read_names( std::string path );


  Graph* make_graph (std::vector<Variable*> E);
  void dump_sol( Solution S, int append=-1 );
  void dump_csp_sol( int append=-1 );
  void dump_sol( const Graph &G, int append=-1 );

  void dump_DOT( const Graph& net, const Graph& gold_std, double THS=-1.0 );
  void dump_sol_DOT( Solution& S, Graph& gold_std, double THS=0.0 );
  void dump( std::vector< int > V );
  void dump( std::vector< double > V );
  void dump( std::vector< std::pair<int,int> > V );
  void dump( std::vector< edge_t > V );
}//-

#endif
