#ifndef _MATH_UTILS_H
#define _MATH_UTILS_H

#include "globals.h"

namespace Math
{
  // round precision to the i-th decimal
  inline double round_to_zero( double x, unsigned int i ) 
  {
    const double err = pow(10.0, (int)-i);
    return (abs(x) < err) ? 0 : x;
  }

  inline double round( double x )
  {
    return floor( x + 0.5 );
  }

  inline bool within( double a, double b, double EPS )
  {
    return ((b >= (a - EPS)) || (b <= (a + EPS)));
  }

  inline bool in_range( double a, double lb, double ub)
  {
    return ( a >= lb && a <= ub );
  }  

  inline int real2fd( double x ) 
  {
    return (int)( Math::round( x * g_Consts.confidenceRange ) ); 
  }

  inline double rank2pconf( double r )
  {
    return ( 1.0 - ( r / (double)g_InfKB.nedges ) );
  }
  
  
  template<class T> double mean( std::vector<T> V )
  {
    double mu = 0;
    for( int i = 0; i < V.size(); i++ ) 
      mu += (double)V[ i ];
    return ( mu / (double)V.size() );
  }

  template<class T> double sd( std::vector<T> V )
    {
      double mu = mean( V ), sd = 0;
      for(int i = 0; i < V.size(); i++)
	sd += ((double)(V[i]-mu)*(double)(V[i]-mu));
      return ( sqrt( 1/(double)V.size() * sd ) );
    }
  
}//-

#endif
