#include "solopt_utils.h"
#include "globals.h"
#include "cpff_headers.h"
#include "solution.h"
#include "graph.h"
#include <climits>

using namespace std;

/* Syntactic Sugar */
// sort in decreasing order.
// If both edges are evaluated false order true edge first - this is done
// to take account of the knowledge of non-regulatory interactions 
bool sort_decr_roc (std::pair<double,bool> lhs, std::pair<double,bool> rhs) 
{ 
  //if( lhs.first == 0 && rhs.first == 0 ) return (lhs.second > rhs.second);
  //else 
  return (lhs.first > rhs.first);
}

double trapezoid_area(double x1, double x2, double y1, double y2)
{
  double b = std::abs(x1 - x2);
  double h = ( ( y1 + y2 ) / 2 );
  return (b * h);
}//-

// TP: the edge occurs in both the true and the predicted network
bool SolOpt::truePositive( pair<int,int> edge, double conf )
{
  //  return (conf >= g_Consts.minTPconfidence && 
  return (g_InfKB.goldStd->edge( edge.first, edge.second ));
}//-

// FP: the edge is predicted but does not occur in the true network
bool SolOpt::falsePositive( pair<int,int> edge, double conf )
{
  //return (conf >= g_Consts.minTPconfidence &&
  return(!g_InfKB.goldStd->edge( edge.first, edge.second ));
}//-

// FN: the edge occurs in the true network but is not predicted
bool SolOpt::falseNegative( pair<int,int> edge, double conf )
{
  return (conf < g_Consts.minTPconfidence &&
	  g_InfKB.goldStd->edge( edge.first, edge.second ));
}//-


/* ***********************************************************
 * Namespace Methods
 * ***********************************************************/
double SolOpt::get_Fscore( std::vector<double> S ) 
{
  double tp = 0.0, fp = 0.0, fn = 0.0;
  
  // 1 to 1 relation between S[i] and g_var_set[i]
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it)
  {
    std::pair<int, int> edge = g_var_edge[ it->second->id() ];
    double f = S[ i++ ];
    tp += truePositive( edge, f );
    fp += falsePositive( edge, f );
    fn += falseNegative( edge, f );
  }

  double P = (tp / (tp + fp)); // precision
  double R = (tp / (tp + fn)); // recall  
  if (P == 0 || R == 0) return 0;
  else return (2 * ((P * R) / (P + R))); // == {1 + tp /(fn+fp)}
}//-



double SolOpt::get_AUROC( vector<double> S )
{
  Graph* gGoldStd = g_InfKB.goldStd;
  vector< pair<double,bool> > L;
    
  int P = gGoldStd->E();
  int N = g_var_set.size() - gGoldStd->V() - P;
  int tp_size = 0, fp_size = 0;
 
  // 1 to 1 relation between S[i] and g_var_set[i]
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it)
  {
    std::pair<int, int> edge = g_var_edge[ it->second->id() ];
    double f = S[ i++ ];
    // true positive  
    if ( truePositive( edge )) L.push_back( make_pair( f, true ) );
    // false positive
    else L.push_back( make_pair( f, false ) );
  }

  sort (L.begin(), L.end(), sort_decr_roc);

  int FP = 0, TP = 0, FPprev = 0, TPprev = 0;
  double A = 0;
  double f_prev = -1000;
  i = 0;
  
  while( i < L.size() ) 
  {
    if( L[ i ].first != f_prev )
    {
      A += trapezoid_area( FP, FPprev, TP, TPprev );
      f_prev = L[ i ].first;
      FPprev = FP; TPprev = TP;
    }
    if( L[ i ].second ) TP++; // positive example
    else FP++; // negative example
    i++;
  }

  A += trapezoid_area( N, FPprev, P, TPprev );
  A /= (P * N);
  return A;

}//-



pair<double,double> SolOpt::get_measures( vector<double> S  )
{
  Graph* gGoldStd = g_InfKB.goldStd;
  vector< pair<double,bool> > L;
  
  int pos =0;// gGoldStd->E();
  int neg =0;// g_cp_variables.size() /*- gGoldStd->V()*/ - pos;


  // 1 to 1 relation between S[i] and g_var_set[i]
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it)
  {
    std::pair<int, int> edge = g_var_edge[ it->second->id() ];
    double f = S[ i++ ]; 
    // true positive
    if ( truePositive( edge )) {pos++; L.push_back( make_pair( f, true ) );}
    // false positive
    else {neg++; L.push_back( make_pair( f, false ) );}
  }
  sort (L.begin(), L.end(), sort_decr_roc);

  int tp = 0, fp = 0;   // curr
  double tpl = 0, fpl = 0, ppl = 0; // prev 
  i = 0;
  double auc = 0, aupr = 0;
  
  while( i < L.size() ) 
  {
    if( L[ i ].second ) tp++; // positive example
    else fp++; // negative example
    i++;

    double tn  = neg - fp;
    double tpr = (tp / (double)pos);	  // recal = sensivity
    double fpr = 1 - (tn / (double)neg);    // specificity
    double ppv = tp / (double)(tp+fp);

    if ( tp+fp > 1 )
    {
      auc  += (fpr-fpl)*(tpr+tpl) / 2.0;
      aupr += (tpr-tpl)*(ppv+ppl) / 2.0;
    }

    tpl = tpr;
    fpl = fpr;
    ppl = ppv;
  }
  // getchar();
  double div = 1 - 1/(double)pos;
  return make_pair( auc, aupr/div);

}//-



double delta( double A, int k, int P, int FPk )
{
  if( k == 0 ) return (1/(double)P);
  return ( (1/(double)P) * ( 1 - (FPk * log( (k+1)/(double)k))));
}

pair<double,double> SolOpt::DREAM_AUC( vector<double> S  )
{
  // P = #positives
  // N = #negatives
  // Pk = all positives in gold standard.
  // Nk = all negatives in gold standard.
  // T = P + N

  Graph* gGoldStd = g_InfKB.goldStd;
  vector< pair<double,bool> > ordered_list;
  int P = 0;
  int N = 0;

  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  for (; it != g_var_set.end(); ++it, i++)
  {
    std::pair<int, int> edge = g_var_edge[ it->second->id() ];
    double f = S[ i ]; 
    // true positive
    if ( truePositive( edge )) {P++; ordered_list.push_back( make_pair( f, true ) );}
    // false positive
    else {N++; ordered_list.push_back( make_pair( f, false ) );}
  }
  sort (ordered_list.begin(), ordered_list.end(), sort_decr_roc);
  int L = ordered_list.size();
  int T = N + P;

  int k = 0;
  int TPk = 0;
  int FPk = 0;
  double Ak = 0;
  vector<double> rec(T, 0);
  vector<double> prec(T, 0);
  vector<double> tpr(T, 0);
  vector<double> fpr(T, 0);

  while( k < L )
    {
      k = k + 1;
      if( ordered_list[ k ].second ) // TP
	{
	  TPk = TPk + 1;
	  Ak  = Ak + delta(Ak, k, P, FPk);
	}
      else
	{
	  FPk = FPk + 1;
	}

      rec[ k ] = (TPk / (double)P);
      prec[ k ] = (TPk / (double)k);
      tpr[ k ] = rec[ k ];
      fpr[ k ] = (FPk / double(N));
    }

  // auroc
  double I = 0;
  for(int n = 0; n < L + P - TPk - 1; n++)
    {
      I += (fpr[n+1] + fpr[n]) * ((tpr[n+1] - tpr[n])/2.0);
    }
  double AUROC = 1 - I;
  double rho = ((P - TPk) / (double)(T - L));
  double rl = (TPk / (double)P);
  double Lp = L*rho;
  double AUPR = Ak + (rho * (1 - rl)) 
    + log(rho * (rl - Lp/(double)P) * log( (Lp + P *(1 - rl)) / Lp ));

  return make_pair( AUROC, AUPR );
}


/**************************************************************
 * Solution Ensemble measures
 *************************************************************/  
void SolOpt::summary( std::vector<Solution*> S, Solution CN_rank, bool latex )
{
  // cout << "Num. Solutions: " << g_solutions.size() << endl;
  // Best Solutions (min | median | max)
  std::vector<double> aucs(g_solutions.size());
  std::vector<double> aups(g_solutions.size());
  for( int i=0; i<g_solutions.size(); i++)
  {
    double b = g_solutions[ i ]->get_AUROC();
    aucs[ i ] = b;
    b = g_solutions[ i ]->get_AUPR();
    aups[i] = b;
  }
  std::sort( aucs.begin(), aucs.end() );
  std::sort( aups.begin(), aups.end() );

  Solution sol_avg = SolOpt::average( g_solutions );
  Solution sol_mode = SolOpt::rank_mode( g_solutions );
  //Solution sol_wavg = SolOpt::weighted_average( g_solutions );
  Solution sol_hd = SolOpt::hamming_dist( g_solutions );
  // Solution sol_ed = SolOpt::eucl_dist( g_solutions );

  int n = g_solutions.size()-1;
  if( n == 0 ) return;

  if( latex ) {
    cout.precision(3);
    cout << aucs[0] << " & " << aucs[n] << " & " << aucs[n/2] << " & "
	 << aups[0] << " & " << aups[n] << " & " << aups[n/2]
	 << " & " << sol_mode.get_AUROC() << " & " <<  sol_mode.get_AUPR()
	 << " & " << sol_avg.get_AUROC() << " & " << sol_avg.get_AUPR()
	 << " & " << sol_hd.get_AUROC() << " & "  << sol_hd.get_AUPR() 
	 << " \\\\ " << endl;
  }
  else {
    cout.precision(3);
    cout << aucs[0] << "," << aucs[n] << "," << aucs[n/2] << ","
	 << aups[0] << "," << aups[n] << "," << aups[n/2]
	 << "," << sol_mode.get_AUROC() << "," <<  sol_mode.get_AUPR()
	 << "," << sol_avg.get_AUROC() << "," << sol_avg.get_AUPR()
	 << "," << sol_hd.get_AUROC() << ","  << sol_hd.get_AUPR() 
	 << endl;
  }

}

Solution SolOpt::average( std::vector<Solution*> S )
{
  int nedges = g_InfKB.nedges;

  vector< double > _edges( nedges, 0 );
  // for all edges
  for( int e = 0; e < nedges; e++ )
  { 
    for( int i = 0; i < S.size(); i++ )
    {
      _edges[ e ] += (*S[ i ])[ e ];
    }
    _edges[ e ] /= S.size();
  }
  Solution sol( _edges );
  return( sol );
}


Solution SolOpt::rank_mode( std::vector<Solution*> S )
{
  int nedges = g_InfKB.nedges;
  std::vector< std::vector< std::pair<double,int> > > lab_count;
  
  // init (0) lab_count with vectors containing the number of labels
  // assosciated to each variable.
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;

  for (; it != g_var_set.end(); ++it)
  {
    int nlab = it->second->dom.size();
    std::vector< std::pair<double,int> > clabs(nlab);
    for( int i = 0; i < nlab; i++)
    {
      clabs[ i ].first = it->second->dom[ i ];
      clabs[ i ].second = 0;
    }
    lab_count.push_back( clabs );
  }

  
  vector< double > _edges( nedges, 0 );
  // for all edges
  for( int e = 0; e < nedges; e++ )
  { 
    for( int i = 0; i < S.size(); i++ )
    {
      int sval = (*S[ i ])[ e ];
      for( int l = 0; l < lab_count[ e ].size(); l++)
      {
	if( lab_count[ e ][ l ].first == sval ) 
	  lab_count[ e ][ l ].second ++;
      }
    }
    
    // get mode of lab_count[ e ]
    int max = -1;
    int lab = -1;
    for( int l = 0; l < lab_count[ e ].size(); l++)
    {
      if( lab_count[ e ][ l ].second > max ) { 
	lab = l;
	max = lab_count[ e ][ l ].second;
      }
    }
    _edges[ e ] = lab_count[ e ][ lab ].first;
  }

  Solution sol( _edges );
  return( sol );
}



Solution SolOpt::weighted_average( std::vector<Solution*> S )
{
  int nedges = g_InfKB.nedges;
  std::vector< std::vector< std::pair<double,int> > > lab_count;
  
  // init (0) lab_count with vectors containing the number of labels
  // assosciated to each variable.
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;

  for (; it != g_var_set.end(); ++it)
  {
    int nlab = it->second->dom.size();
    std::vector< std::pair<double,int> > clabs(nlab);
    for( int i = 0; i < nlab; i++)
    {
      clabs[ i ].first = it->second->dom[ i ];
      clabs[ i ].second = 0;
    }
    lab_count.push_back( clabs );
  }

  
  vector< double > _edges( nedges, 0 );
  // for all edges
  for( int e = 0; e < nedges; e++ )
  { 
    for( int i = 0; i < S.size(); i++ )
    {
      int sval = (*S[ i ])[ e ];
      for( int l = 0; l < lab_count[ e ].size(); l++)
      {
	if( lab_count[ e ][ l ].first == sval ) 
	  lab_count[ e ][ l ].second ++;
      }
    }
    
    // get mode of lab_count[ e ]
    int sum_w = 0;
    for( int l = 0; l < lab_count[ e ].size(); l++)
    {
      int weight = lab_count[ e ][ l ].second;
      double val = lab_count[ e ][ l ].first;
      _edges[ e ] += (weight * val);
      sum_w += weight;
    }
    _edges[ e ] /= sum_w;
  }

  Solution sol( _edges );
  return( sol );
}


// assume a and b of same size
double ed(std::vector<double> a, std::vector<double> b)
{
  double ed = 0;
  for( int i = 0; i < a.size(); i++ )
  {
    ed += std::abs( a[ i ] - b[ i ] );
  }
  return ed;
}

int hd(std::vector<double> a, std::vector<double> b)
{
  int hd = 0;
  for( int i = 0; i < a.size(); i++ )
  {
    hd += (a[ i ] != b[ i ] );
  }
  return hd;
}

Solution SolOpt::hamming_dist( std::vector<Solution*> S )
{
  int min_hd = INT_MAX;
  int min_hd_idx = 0;
  for( int si = 0; si < S.size(); si++ )
  {
    int hd_i = 0;
    for( int sj = 0; sj < S.size(); sj++ )
    {
      if( si == sj ) continue;
      hd_i += hd( S[ si ]->get_states(), S[ sj ]->get_states() );
    }
    if( hd_i < min_hd ) { min_hd = hd_i; min_hd_idx = si; }
  }

  return *S[ min_hd_idx ];  
}


Solution SolOpt::eucl_dist( std::vector<Solution*> S )
{
  double min_ed = INT_MAX;
  int min_ed_idx = 0;
  for( int si = 0; si < S.size(); si++ )
  {
    double ed_i = 0;
    for( int sj = 0; sj < S.size(); sj++ )
    {
      if( si == sj ) continue;
      ed_i += ed( S[ si ]->get_states(), S[ sj ]->get_states() );
    }
    ed_i /= (S.size()-1);
    if( ed_i < min_ed ) { min_ed = ed_i; min_ed_idx = si; }
  }

  return *S[ min_ed_idx ];  
}
