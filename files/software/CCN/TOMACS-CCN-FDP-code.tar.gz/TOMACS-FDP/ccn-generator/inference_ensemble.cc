#include "inference_ensemble.h"
#include "globals.h"
#include "graph.h"
#include "rank_utils.h"
#include "io_utils.h"

using namespace std;

//#define VERBOSE

InferenceEnsemble::InferenceEnsemble ( int argc, char* argv[] ) 
{
  size_t size = g_InfKB.nnodes;
  assert( size > 0 );

  for( int i=0; i < argc; i++ ) 
  {
    if( ! strcmp( "--inference", argv[ i ] ) )
    {
      e_InfMet  _inf_met  = getInfMet( argv[ ++i ] );
      e_MetType _met_type = getMetType( argv[ ++i ] );
      string path  = argv[ ++i ];
      int w = atof( argv[ ++i ] );

      Graph *G = new Graph( size, true );
      IO::read_graph( G, path, true );
      
      G->normalizeWeigths(); // normalize edges in [0,1]

      _gEntry graph = make_pair( G, w );
      _metEntry met = make_pair( _inf_met, _met_type );
      ensemble.push_back( make_pair( met, graph) );
#ifdef VERBOSE
      dump( ensemble.size()-1 );
#endif

    }
  }
}

InferenceEnsemble::~InferenceEnsemble () 
{
  for( int i = 0; i <  ensemble.size(); i++)
  {
    delete ensemble[ i ].second.first;
  }
}
//-


void InferenceEnsemble::makeCN( CNType type )
{
  size_t size = g_InfKB.nnodes;

  /* ranks the Ensemble imported via a Borda Ranking System */
  std::vector<_gEntry> raw_ensemble;
  for( int i=0; i<ensemble.size(); i++)
  {
    raw_ensemble.push_back( ensemble[ i ].second );
  }
  
  Graph *G = new Graph(size, true);
  std::map<string,int>::iterator ix, iy;
  double w = 0;
  for( ix = g_gene_ids.begin(); ix != g_gene_ids.end(); ++ix ) 
  {
    int x = ix->second;
    for( iy = g_gene_ids.begin(); iy != g_gene_ids.end(); ++iy )
    {
      int y = iy->second;
      switch( type )
      {
      case BORDA_rank:
	w = Rank::Borda_rank( x, y, raw_ensemble );
	break;
      case BORDA_conf:
	w = Rank::Borda_confidence( x, y, raw_ensemble );
	break;
      case invChi2:
	w = Rank::FishersInvrseChiSquare( x, y, raw_ensemble );
	break;
      }
      G->insert( x, y, w );
    }
  }
  G->normalizeWeigths(); // normalize edges in [0,1]

  _gEntry graph = make_pair( G, 1.0 );
  _metEntry met = make_pair( CN, MetType_undef );
  ensemble.push_back( make_pair( met, graph) );
}
//-

e_InfMet InferenceEnsemble::getInfMet( char* meth )
{
  if( !strcmp( meth, "MI") )  return MI;
  if( !strcmp( meth, "Cor") ) return Cor;
  if( !strcmp( meth, "LR") )  return LR;
  if( !strcmp( meth, "Byn") ) return ByN;
  if( !strcmp( meth, "BlN") ) return BlN;
  if( !strcmp( meth, "ODE") ) return ODE;
  if( !strcmp( meth, "Stat") ) return Stat;
  if( !strcmp( meth, "GS") )  return GS;
  if( !strcmp( meth, "CN") )  return CN;
  if( !strcmp( meth, "CCN") ) return CCN;
  else return InfMet_undef;
}//-

e_MetType InferenceEnsemble::getMetType( char* meth )
{
  if( !strcmp( meth, "p") ) return Pure;
  if( !strcmp( meth, "h") ) return Hybrid;
  else return MetType_undef;
}
//-

Graph* InferenceEnsemble::get( _metEntry method )
{
  for( int i = 0; i < ensemble.size(); i++ )
  {
    if ( ensemble[ i ].first.first == method.first &&
	 ensemble[ i ].first.second == method.second )
      return ensemble[ i ].second.first;
  }
  return NULL;
}
//-

_infEntry InferenceEnsemble::get( int index )
{
  return ensemble[ index ];
}
//-

int InferenceEnsemble::size() const
{
  return ensemble.size();
}
//-

void InferenceEnsemble::dump()
{
  for( int i = 0; i < ensemble.size(); i++ )
  {
    dump( i );
  }
}

void InferenceEnsemble::dump( int i )
{
    e_InfMet met   = ensemble[ i ].first.first; 
    e_MetType type = ensemble[ i ].first.second; 
    cout << "  Network Ensemble No. " << i
	 << " Method: ";
    if( met == MI ) cout << "Mutual Information "; 
    else if(met == Cor) cout << "Correlation "; 
    else if(met == LR)  cout << "Linear Regression "; 
    else if(met == ByN) cout << "Bayesian Network "; 
    else if(met == BlN) cout << "Boolean Network "; 
    else if(met == ODE) cout << "ODE "; 
    else if(met == Stat) cout << "Stat-based ";
    else if(met == GS)  cout << "Gold Standard "; 
    else if(met == CN)  cout << "Community "; 
    else if(met == CCN) cout << "Constrainted Community "; 
    else cout << " unknown ";

    if( type == Pure ) cout << " (Pure) ";
    else if( type == Hybrid ) cout << " (Hybrid) ";
    cout << endl;
}
