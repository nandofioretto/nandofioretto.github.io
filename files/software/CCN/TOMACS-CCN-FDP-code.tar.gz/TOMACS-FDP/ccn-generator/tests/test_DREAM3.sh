#!/bin/bash
_con_lsparsness='n'
_con_gsparsness=$1
_con_redundant_edge=$2
_con_tf=$3
_con_tg='n'
_con_cotf=$4

_ntrials=10000
## Paths and Solver configuration 
_solver=main

_uname=$(uname)
if [ $_uname == "Darwin" ]; then
  _path_base="../.."
elif [ $_uname == "Linux" ]; then
  _path_base="../.."
fi
_path_data=$_path_base"/data/DREAM3"
_path_solver=$_path_base"/ccn-generator"
_path_results=$_path_base"/predictions"
_path_CN=$_path_results"/DREAM3/individual-methods"
_file_goldstd="goldstandard.tsv"
_file_genes="gene_names.tsv"
########################################

_train_netname=("Ecoli1" "Ecoli2" "Yeast1" "Yeast2" "Yeast3") 
_train_netsize=100
_train_netdata=("mf" "ko" "all")

# Methods
_methods=("pearson" "spearman" "kendall" "aracne" "mrnet" "clr" "c3net" "bc3net" "genie3" "tigress" "inferelator" "anova" "gln" )
_cn_methods=("pearson" "clr" "bc3net" "genie3" "tigress" "inferelator" "gln")

netid=0
# Network Name and specifications
for dn in ${_train_netdata[@]}
do
    for net in ${_train_netname[@]}
    do
	_path_net=$_path_data"/"$net
	_file_out="pred.tsv"
	let "netid = $netid % 5 + 1"
	# echo "Processing Net: $net ($_train_netsize)  data: $dn"
	echo -n "d3_$netid,$dn,"

	EXE="--gn-pred-file $_path_results/$_file_out "
	EXE+="--components $_path_net/$_file_genes "
	EXE+="--gold-std $_path_net/$_file_goldstd "
   	
        # Include Prior TFs knowledge?
	if [[ $_con_tf == "y" || $_con_cotf == "y" ]]; then
	    EXE+="--use-prior-tf "
	fi
	    
	for met in ${_cn_methods[@]}
	do
	    _cn_file=$net"_size_"100"_met_"$met"_data_"$dn".tsv"
	    if [[ $met == "pearson" || $met == "spearman" || $met == "kendall" ]]; then
		_mtype="Cor p"
	    elif [[ $met == "aracne" || $met == "mrnet" || $met == "clr" ]]; then 
		_mtype="MI p"
	    elif [[ $met == "c3net" || $met == "bc3net" ]]; then
		_mtype="MI h"
	    elif [[ $met == "genie3" ]]; then
		_mtype="LR h"
	    elif [[ $met == "tigress" ]]; then
		_mtype="LR p"
	    elif [[ $met == "inferelator" ]]; then
		_mtype="ODE h"
	    elif [[ $met == "anova" || $met == "gln" ]]; then
		_mtype="Stat p"
	    fi
	    EXE+="--inference $_mtype $_path_CN/$_cn_file 1.0 "
	done
	
	if [ $_con_lsparsness == "y" ]; then
	    EXE+="--l-sparse "
	fi
	if [ $_con_gsparsness == "y" ]; then
	    EXE+="--g-sparse "
	fi
	if [ $_con_redundant_edge == "y" ]; then
	    EXE+="--dir-sel "
	fi
	if [ $_con_tf == "y" ]; then
	    EXE+="--tf "
	fi
	if [ $_con_tg == "y" ]; then
	    EXE+="--tg "
	fi
	if [ $_con_cotf == "y" ]; then
	    EXE+="--cotf "
	fi
    	EXE+="--max-numof-solutions $_ntrials "
    	EXE+="--mc-limit            $_ntrials "
	
	${_path_solver}/$_solver $EXE
    done
done
