#!/bin/bash

./test_FDP.sh y n n n | egrep "&|," > fdp_ynnn.csv
./test_FDP.sh n y n n | egrep "&|," > fdp_nynn.csv
./test_FDP.sh n n y n | egrep "&|," > fdp_nnyn.csv
./test_FDP.sh n n n y | egrep "&|," > fdp_nnny.csv
    # 2 constrs
./test_FDP.sh y y n n | egrep "&|," > fdp_yynn.csv
./test_FDP.sh y n y n | egrep "&|," > fdp_ynyn.csv
./test_FDP.sh y n n y | egrep "&|," > fdp_ynny.csv
./test_FDP.sh n y y n | egrep "&|," > fdp_nyyn.csv
./test_FDP.sh n y n y | egrep "&|," > fdp_nyny.csv   
./test_FDP.sh n n y y | egrep "&|," > fdp_nnyy.csv
    # 3 constr
./test_FDP.sh y y y n | egrep "&|," > fdp_yyyn.csv
./test_FDP.sh y y n y | egrep "&|," > fdp_yyny.cs
./test_FDP.sh y n y y | egrep "&|," > fdp_ynyy.csv
./test_FDP.sh n y y y | egrep "&|," > fdp_nyyy.csv
    # 4 constr
./test_FDP.sh y y y y | egrep "&|," > fdp_yyyy.csv
    # 0 constr
./test_FDP.sh n n n n | egrep "&|," > fdp_nnnn.csv

./test_DREAM3.sh y y n n | egrep "&|," > d3_yynn.csv
./test_DREAM3.sh y y y n | egrep "&|," > d3_yyyn.csv
./test_DREAM3.sh y y y y | egrep "&|," > d3_yyyy.csv
./test_DREAM3.sh y n y n | egrep "&|," > d3_ynyn.csv
./test_DREAM3.sh y n y y | egrep "&|," > d3_ynyy.csv

./test_DREAM4.sh y y n n | egrep "&|," > d4_yynn.csv
./test_DREAM4.sh y y y n | egrep "&|," > d4_yyyn.csv
./test_DREAM4.sh y y y y | egrep "&|," > d4_yyyy.csv  
./test_DREAM4.sh y n y n | egrep "&|," > d4_ynyn.csv  
./test_DREAM4.sh y n y y | egrep "&|," > d4_ynyy.csv  
