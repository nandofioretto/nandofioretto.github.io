#!/bin/bash

## CONSTRAINTS (enable/disable by sobstituting  n -> y / y -> n)

_con_lsparsness='n'
_con_gsparsness=$1
_con_redundant_edge=$2
_con_tf=$3
_con_tg='n'
_con_cotf=$4

_ntrials=10000

## Paths and Solver configuration 
_solver=main

_uname=$(uname)
if [ $_uname == "Darwin" ]; then
  _path_base="../.."
elif [ $_uname == "Linux" ]; then
  _path_base="../.."
fi
_path_data=$_path_base"/data"
_path_FDP=$_path_data"/FDP"
_path_solver=$_path_base"/ccn-generator"
_path_results=$_path_base"/predictions"
_path_CN=$_path_results"/FDP/individual-methods"
_file_goldstd="goldstandard.tsv"
_file_genes="gene_names.tsv"
########################################

# Training Data
_train_netname=("ecoli" "yeast")
_train_netsize=100
_train_netid=(1 2 3 4 5)
_train_netdata=("mf" "ko" "all")
# Methods
_methods=("pearson" "spearman" "kendall" "aracne" "mrnet" "clr" "c3net" "bc3net" "genie3" "tigress" "inferelator" "anova" "gln" )
_cn_methods=("pearson" "clr" "bc3net" "genie3" "tigress" "inferelator" "gln")
########################################

_train_netname=("ecoli" )
_train_netsize=100
_train_netid=(1)
_train_netdata=("mf")


# Network Name and specifications
for dn in ${_train_netdata[@]}
do
    for net in ${_train_netname[@]}
    do
	for id in ${_train_netid[@]}
	do
	    if [ "$net" == "ecoli" ]; then
		_netdir="Ecoli"
		echo -n "e$id,"
	    elif [ "$net" == "yeast" ]; then
		_netdir="Scervise"
		echo -n "s$id,"
	    fi
	    echo -n "$dn,"

	    _path_net=$_path_FDP"/"$_netdir"/size"$_train_netsize"/net"$id
	    _file_out="pred.tsv"
	    #echo "Processing Net: $net $id ($_train_netsize)  data: $dn"

	    EXE="--gn-pred-file $_path_results/$_file_out "
	    EXE+="--components $_path_net/$_file_genes "
	    EXE+="--gold-std $_path_net/$_file_goldstd "

	    # Include Prior TFs knowledge?
	    if [[ $_con_tf == "y" || $_con_cotf == "y" ]]; then
		EXE+="--use-prior-tf "
	    fi

	    for met in ${_cn_methods[@]}
	    do
		_cn_file=$net$id"_size_"100"_met_"$met"_data_"$dn".tsv"
		if [[ $met == "pearson" || $met == "spearman" || $met == "kendall" ]]; then
		    _mtype="Cor p"
		elif [[ $met == "aracne" || $met == "mrnet" || $met == "clr" ]]; then 
		    _mtype="MI p"
		elif [[ $met == "c3net" || $met == "bc3net" ]]; then
		    _mtype="MI h"
		elif [[ $met == "genie3" ]]; then
		    _mtype="LR h"
		elif [[ $met == "tigress" ]]; then
		    _mtype="LR p"
		elif [[ $met == "inferelator" ]]; then
		    _mtype="ODE h"
		elif [[ $met == "anova" || $met == "gln" ]]; then
		    _mtype="Stat p"
		fi
		EXE+="--inference $_mtype $_path_CN/$_cn_file 1.0 "
	    done
	    
	    if [ $_con_lsparsness == "y" ]; then
		EXE+="--l-sparse "
	    fi
	    if [ $_con_gsparsness == "y" ]; then
		EXE+="--g-sparse "
	    fi
	    if [ $_con_redundant_edge == "y" ]; then
		EXE+="--dir-sel "
	    fi
	    if [ $_con_tf == "y" ]; then
		EXE+="--tf "
	    fi
	    if [ $_con_tg == "y" ]; then
		EXE+="--tg "
	    fi
	    if [ $_con_cotf == "y" ]; then
		EXE+="--cotf "
	    fi
    	    EXE+="--max-numof-solutions $_ntrials "
    	    EXE+="--mc-limit            $_ntrials "
	    
	    ${_path_solver}/$_solver $EXE
	done
    done
done
