#ifndef _GRAPH_H_
#define _GRAPH_H_
#include "globals.h"

typedef std::pair<std::pair<int,int>,double> edge_t;
typedef std::map<std::pair<int,int>,double>::const_iterator clm_it;  
typedef std::vector<int>::const_iterator node_it;

class Graph
{
 private:  
  int n_nodes;
  int n_edges;
  bool directed;
  std::vector<int> nodes_id; // contains all the ids of the nodes (we will refer to nodes trough this vector
  std::map< std::pair<int,int>, double > link_map;

  std::vector< edge_t > _sorted_edges;
  bool _edges_are_sorted;

 public:
  Graph( int nodes, bool directed=true );
  Graph( int nodes, std::vector<edge_t> edges, bool directed=true ); 
  Graph( const Graph& other );
  Graph& operator=( const Graph& other );
  ~Graph();

  void insert( int s, int t, double weight );
  void remove( int s, int t );
  void incr_edge_weight ( int s, int t, double w );
  void decr_edge_weight ( int s, int t, double w );
  bool is_directed() const;
  bool edge( int s, int t ) const;
  clm_it get_edge( int s, int t ) const;
  std::vector<edge_t> get_neighbors( int s, double min_w=0.01 ) const;
  std::vector<edge_t> get_undirect_neighbors( int s, double min_w=0.01 ) const;
  
  double get_edge_weight ( int s, int t) const;
  int get_edge_rank ( int s, int t);

  int deg    ( int s, double min_w=0 ) const;
  int in_deg ( int s, double min_w=0 ) const;
  int out_deg( int s, double min_w=0 ) const;
  int V() const;
  int E() const;
  void dump() const;
  void dump_sorted();
  void stats();

  // Utilities
  void normalizeWeigths();
  double avg_weight( int s ) const;
  double avg_weight_in( int s, double min_w) const;
  double avg_weight_out( int s, double min_w ) const;
  std::vector<edge_t> sorted_edges() const;
  void sortEdges();

  int get_nodeid( int idx ) const { return nodes_id[ idx ];}
  
  Graph* kruskal();
  void SCC( int u, double w );
  std::vector<std::vector<int> > Tarjans_SCC( double w );
  void CC( int u, double w );
  std::vector<std::vector<int> > Tarjans_CC( double w );

  void OHMST ( std::vector<int>& outliers, std::vector<int>& hubs, 
	       double t=0.75, int THS_H=2, int THS_O=1 );
  void OHMST2 ( std::vector<int>& outliers, std::vector<int>& hubs,
		double t=0.75, int THS_H=2, int THS_O=1 );
};

#endif
