#include "propagator.h"
// #include "trailstack.h"
#include "constraint.h" // contains constr_type

using namespace Propagator;
using namespace std;

//#define DBG

// increase Lower Bound of Var s.t. min( D_v ) >= GT_val
void incr_lb( Variable* var, double GT_val )
{
  int new_lb = var->dom.lb_pos();
  while( new_lb <= var->dom.ub_pos() && var->dom[ new_lb ] < GT_val )
    { new_lb++; } // will cause lb > un if no feasible solution (ok!)
  var->dom.set_lb( new_lb );
}

// decrease Upper Bound of Var s.t. max( D_v ) <= LT_val
void decr_ub( Variable* var, double LT_val )
{
  int new_ub = var->dom.ub_pos();
   while( new_ub >= var->dom.lb_pos() && var->dom[ new_ub ] > LT_val )
    { new_ub--; } // will cause ub < lb if no feasible solution (ok!)
   var->dom.set_ub( new_ub );
}


/*
 * If new propagators are added modify here:
 * add a case to the following switch and add the associated 
 * propagator funcion.
 */
propagator Propagator::select( int cid )
{
  constr_type ctype = g_constr_set[ cid ]->type();
  switch( ctype )
    {
    case ATLEAST_K_GE: return (c_ATLEAST_K_GE);
    case ATMOST_K_GE: return (c_ATMOST_K_GE);
    case ATMOST_K_GE_FAST: return (c_ATMOST_K_GE_FAST);
    case RED_EDGE: return (c_RED_EDGE);
    case DIR_SEL: return (c_DIR_SEL);
    case ONE_DIR: return (c_ONE_DIR);
    case COTF: return(c_COTF);
    case NET_MODULE: return (c_NET_MODULE);
    default: return NULL;
    }
  return NULL;
}

bool Propagator::consistency( int vid )
{
  int event = g_var_set[ vid ]->dom.event();

  // PROPAGATOR ACTING ON BOUNDS ONLY
  switch( event )
    {
    case SING_EVENT: break;
    case DC_EVENT:
    case BC_EVENT:
      if( g_var_set[ vid ]->dom.lb_pos() > g_var_set[ vid ]->dom.ub_pos() ){
	return false;
      }
      break;
    case FAILED_EVENT: return false;
    case EMPTY_EVENT:  break;	// no need to check 
    }
  return true; 
}//-

bool Propagator::propagate( int cid )
{
  propagator p = select( cid );
  if( p == NULL) return false;
  return (  p( cid ) );
}


/*
 * When this constraint will reach a FIXPOINT will not be propagated anymore.
 * for all the successive labeling (managed by trailstack)
 * Constraint structure:
 *
 * int_coef[ 0 ] = K
 * real_coef[ 0 ] = THS
 */
// # tot = scope
// # sat = D(min) >= THS
// # unsat = D(max) < THS
// if #sat >= k then FIXPT
// if #tot-#unsat > k then FAIL (not enough #sat)
// if #tot-#unsat = k -> Prop:
//   ensure domain of !sat, !unsat to be s.t. min(D) >= THS
bool Propagator::c_ATLEAST_K_GE( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  int K   = C->int_coef( 0 );
  double THS = C->real_coef( 0 );

  /* Count the number of variables that violate the constriant ( coefficient ) */
  int n_sat = 0, n_unsat = 0, tot = C->scope_size();

  for( int i = 0; i < C->scope_size(); i++ )
  {
    Variable* v = C->scope( i );
    n_sat += ( v->dom.lb() >= THS );
    n_unsat += ( v->dom.ub() < THS );

    if( n_sat >= K )	// fixpoint reached 
    {
      C->set_fixpt();
      return true;
    }
  }
#ifdef DBG
  cout << " #Sat: " << n_sat << " #Unsat: " << n_unsat 
       << " (k=" << K << ") THS: " << THS << endl;
  getchar();
#endif
  if((tot - n_unsat) == K ) // sat + remaining = K
    {
      // propagate: ensure lb >= ths for all the vars which
      // are neither sat nor unsat
      for( int i = 0; i < C->scope_size(); i++ )
	{
	  Variable* v = C->scope( i );
	  if ( v->dom.lb() >= THS ) continue;
	  if ( v->dom.ub() < THS ) continue;

	  incr_lb( v, THS );
	}
    }
  else if((tot - n_unsat) < K ) // sat + remaining < K
  {
#ifdef DBG
    cout << "At least failing\n";
#endif
    return false; // FAIL
  }
  return true;
}//-


// icoeff[0]= k
// icoeff[1]= nsat
// icoeff[2...m] the variables' id which satisfy the constraint.
bool Propagator::c_ATMOST_K_GE_FAST( int c_id )
{
  int var_current_labelled = g_curr_var_labeled;
  if (var_current_labelled == -1) return c_ATMOST_K_GE( c_id );
  
  Constraint* C = g_constr_set[ c_id ];
  int K   = C->int_coef( 0 );
  double THS = C->real_coef( 0 );
  int n_sat = C->int_coef( 1 );
  if ( n_sat > 0 ) 
  {
    std::vector<int>::iterator it = C->int_coef_begin();
    std::advance(it, 2);
    if ( std::find( it, C->int_coef_end(),
	 var_current_labelled ) != C->int_coef_end() ) 
      {
         if( n_sat > K ) return false;
         return true;
      }
   }

  Variable* curr_var = g_var_set[ var_current_labelled ];
  if( curr_var->value() >= THS ) n_sat++;

  if( n_sat == K ) // limit reached --> propagate to lower ub(s)
  {
    cout << "Sparseness PROP\n";
    // propagate: ensure other vars are unsat: ub < ths:
     for( int i = 0; i < C->scope_size(); i++ )
     {
        Variable* v = C->scope( i );
        if ( v->dom.lb() >= THS ) continue; // already SAT
        if ( v->dom.ub() < THS ) continue;  // already UNSAT
	  
	decr_ub( v, v->dom.lb());//THS );
     }
     C->set_fixpt();
  }
  if( n_sat > K ) return false;
  return true;
}



/*
 * When this constraint will reach a FIXPOINT will not be propagated anymore.
 * for all the successive labeling (managed by trailstack)
 *
 * int_coef[ 0 ] = K
 * real_coef[ 0 ] = THS
 */
bool Propagator::c_ATMOST_K_GE( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  int K   = C->int_coef( 0 );
  double THS = C->real_coef( 0 );
    /* Count the number of variables that violate the constriant ( coefficient ) */
  int n_sat = 0, n_unsat = 0, tot = C->scope_size();

  for( int i = 0; i < C->scope_size(); i++ )
  {
    Variable* v = C->scope( i );
    n_sat += ( v->dom.lb() >= THS );
    n_unsat += ( v->dom.ub() < THS );
    
    if( n_sat > K ) {
#ifdef DBG
      cout << "At Most failing\n";
#endif
      //return false;
    }
  }

#ifdef DBG
  cout << " #Sat: " << n_sat << " #Unsat: " << n_unsat 
       << " (k=" << K << ") THS: " << THS << endl;
#endif
  if( n_sat >= K ) // limit reached --> propagate to lower ub(s)
    {
      //cout << "Sparseness PROP\n";
      // propagate: ensure other vars are unsat: ub < ths:
      for( int i = 0; i < C->scope_size(); i++ )
	{
	  Variable* v = C->scope( i );
	  if( v->is_assigned() ) continue;
	  if ( v->dom.lb() >= THS ) continue; // already SAT
	  //if ( v->dom.ub() < THS ) continue;  // already UNSAT
	  
	  decr_ub( v, v->dom.lb());//THS );
	}
      C->set_fixpt();
    }
  else if( n_sat + (tot-n_unsat) <= K ) // fixpoint
    { C->set_fixpt(); }
  //else  if( n_sat < K ) return true;
  return true;
}//-


/*
 * Note: cannot act only on bounds as the monteCarlo_vlab::labeling
 * will take all the domain elements that are active (bounds change 
 * do not force deactivation of domain elemenents) 
 *
 * When this constraint will reach a FIXPOINT will not be propagated anymore.
 * for all the successive labeling (managed by trailstack)
*/
// scope[0] = required var
// scope[1] = redundant var
// _real_coef[0] = tQ (theta)
// _real_coef[1] = tR (L)

// rule: x-req > tQ --> x_red < tD
// prop: min(D_x-req) > tQ
//       max(D_x-red) < tD
// moreover check when the vars are labeled.
bool Propagator::c_RED_EDGE( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  double tQ = C->real_coef( 0 );
  double tD = C->real_coef( 1 );
  Variable *var_req = C->scope( 0 );
  Variable *var_red = C->scope( 1 );

  if( var_req->is_assigned() && !var_red->is_assigned() )
    {
#ifdef DBG
      cout <<"    v-req (" << var_req->id() <<") assinged "
	   << " v-red (" << var_red->id() << ") NOT assigned: ";
#endif
      // x-req > tQ ===> ensure max(D_x-red) < tD
      if( var_req->value() > tQ )
	{
	  decr_ub( var_red, tD ); // >=
	}
      else { } // x-req <= tQ ===> Nothing  
    }
  else if( !var_req->is_assigned() && var_red->is_assigned() )
    {
#ifdef DBG
      cout <<"    v-req (" << var_req->id() <<") NOT assinged "
	   << " v-red (" << var_red->id() << ") assigned: ";
#endif
      // x-red < tD ===> ensure min(D_x-req) > tQ
      if( var_red->value() < tD )
	{
	  incr_lb(var_req, tQ); // <=
	}
      else // x-red >= tD ===> ensure max(D_x-req) <= tQ
	{
	  decr_ub( var_req, tQ ); // >
	}
    }
  else if( !var_req->is_assigned() && !var_red->is_assigned() )
    {
#ifdef DBG
      cout <<"    both v-req (" << var_req->id() <<") and  "
	   << " v-red (" << var_red->id() << ") NOT assigned: ";
      //ensure min(D_x-req) > tQ ...
#endif
      incr_lb( var_req, tQ ); // <=
      // ... and max(D_x-red) < tD
      decr_ub( var_red, tD ); // >=
    }
  else // both assigned --> check consistency
    {
#ifdef DBG
      cout <<"    both v-req (" << var_req->id() <<") and  "
	   << " v-red (" << var_red->id() << ") assigned: ";
#endif
      if( var_req->value() > tQ && var_red->value() > tD) 
	{
	return false;
	}
    }
  return true;
}


bool Propagator::c_DIR_SEL( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  Variable *var_req = C->scope( 0 ); // required
  Variable *var_red = C->scope( 1 ); // redundant
  double tD = C->real_coef( 0 );

  bool res = true;
  if( var_req->is_assigned() && !var_red->is_assigned() )
    {
      //cout << "  var_req ass. & var_red NOT ass.\n";
      double qval = var_req->value();
      double m = tD;
      if( qval > tD )
	m = min(qval, abs(1-qval));
      decr_ub( var_red, m );
    }
  // else if( !var_req->is_assigned() && var_red->is_assigned() )
  //   {
  //     //cout << "  var_req NOT ass. & var_red ass.\n";
  //     double dval = var_red->value();
  //     //if( dval > tD ) return false; // dval cannot be GT min(qval, 1-qval)
  //     if( dval < tD )
  // 	incr_lb( var_req, abs(1-dval) );
  //   }
  // else if ( var_req->is_assigned() && var_red->is_assigned() )
  //   {
  //     //cout << "  var_req NOT ass. & var_red NOT ass.\n";
  //     // check consistency
  //     double qval = var_req->value();
  //     double dval = var_req->value();
  //     res = ( dval < min(dval, 1-dval) );
  //   }

  // else ( !var_req->is_assigned() && !var_red->is_assigned() )
  // nothing ...
  //cout << "  returning\n";
  //getchar();
  return res;
}

bool Propagator::c_NET_MODULE( int c_id )
{

  Constraint* C = g_constr_set[ c_id ];
  Variable *var_tf = C->scope( 0 ); // main TF of the group
  int n_tfs = C->int_coef( 0 );

  // Apply a lower bound on the out-degree of the variables 


  //
  for( int i = n_tfs-1; i < C->scope_size(); i++)
    {

    }

  Variable *var_red = C->scope( 1 ); // redundant
  double tD = C->real_coef( 0 );

}

// c_ONE_DIR( tf, tg, cn_val_tf)
// is a diraectional constraint (left to right)
// (tf > cn_val_tf) => tg < min(tf, 1-tf)
bool Propagator::c_ONE_DIR( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  Variable *tf = C->scope( 0 );	// putative transc. factor (tf->tg)
  Variable *tg = C->scope( 1 );	// putative target (tg->tf)
  double cn_val_tf = C->real_coef( 0 );
  if( tf->is_assigned() )//&& tf->value() > cn_val_tf )
    {
      // reduce upper bound of tg
      double m = min(tf->value(), abs(1 - tf->value()));
      decr_ub( tg, m );
    }
  return true;
}


// at least k edges s.t. t' -> s and t'' -> s bigger than \theta
// scope: all edges t'  -> x
//        all edges t'' -> y
// scope salva una e una: t' -> a, t'' -> a, t' -> b, t'' -> b ...
/// only consistency for now
bool Propagator::c_COTF( int c_id )
{
  Constraint* C = g_constr_set[ c_id ];
  int K   = C->int_coef( 0 );
  double THS = C->real_coef( 0 );

  /* Count the number of variables that violate the constriant ( coefficient ) */
  int n_sat = 0, n_unsat = 0, tot = C->scope_size() / 2;
  for( int i = 0; i < C->scope_size()-1; i+=2 )
  {
    Variable* tf1_tg = C->scope( i );
    Variable* tf2_tg = C->scope( i+1 );

    n_sat   += ( tf1_tg->dom.lb() >= THS && tf2_tg->dom.lb() >= THS );
    n_unsat += ( tf1_tg->dom.ub() < THS || tf2_tg->dom.ub() < THS );

    if( n_sat >= K )	// fixpoint reached 
    {
      C->set_fixpt();
      return true;
    }
  }

  if((tot - n_unsat) == K ) // sat + remaining = K
    {
      // propagate: ensure lb >= ths for all the vars which
      // are neither sat nor unsat
      for( int i = 0; i < C->scope_size()-1; i+=2 )
      {
	Variable* tf1_tg = C->scope( i );
	Variable* tf2_tg = C->scope( i+1 );
	  
	Variable* v = C->scope( i );
	if ( v->dom.lb() >= THS ) continue;
	if ( v->dom.ub() < THS ) continue;
	
	if( tf1_tg->dom.lb() < THS && tf1_tg->dom.ub() >= THS &&
	    tf2_tg->dom.lb() < THS && tf2_tg->dom.ub() >= THS )
	  {	    
	    incr_lb( tf1_tg, THS );
	    incr_lb( tf2_tg, THS );
	  }
	}
    }
  else if((tot - n_unsat) < K ) // sat + remaining < K
  {
    return false; // FAIL
  }
  return true;
}//-

