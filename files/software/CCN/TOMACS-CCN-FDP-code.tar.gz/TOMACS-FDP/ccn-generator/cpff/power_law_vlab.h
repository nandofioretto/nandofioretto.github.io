/*********************************************************************
 * Search Engine Object
 * This search engine implements a variable selection strategy which 
 * following a power law distribution
 *********************************************************************/
#ifndef POWER_LAW_VLAB_SEARCH_ENGINE_H
#define POWER_LAW_VLAB_SEARCH_ENGINE_H

#include "cpff_globals.h"
#include "search_engine.h"

class PowerLaw_vlab : public SearchEngine {
 private:
  int _numof_vars;
  int _x_cdf;
  int _xmax_cdf, _xmin_cdf;

  int _mc_limit;
  int _curr_trial;

  std::default_random_engine generator;
  size_t seed;

  std::map< int, bool > selected_nodes;

  std::queue<int> _closed_nodes;
  std::queue<int> _open_nodes;

protected:
  void initialize();
  int step();
  /* bool can_label( int node, int n_vars, int min_val ); */
  /* void pick_next_active_node( int &seed_node ); */
  void process_solution();

 public:
  PowerLaw_vlab (int argc, char* argv[]);
  ~PowerLaw_vlab();
  
  void init ();
  void reset ();
  void search ();
  void dump_statistics (std::ostream &os = std::cout);
};

#endif
