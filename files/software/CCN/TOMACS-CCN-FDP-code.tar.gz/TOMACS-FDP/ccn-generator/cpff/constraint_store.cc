#include "constraint_store.h"
#include "variable.h"
#include "constraint.h"
// #include "trailstack.h"
#include "cpff_globals.h"
#include "propagator.h"
 
using namespace std;
using namespace Propagator;
//#define DBG


ConstraintStore::ConstraintStore() 
{
  size_t nc = g_constr_set.size();
  size_t nv = g_var_set.size();
  _con_queue.store = new int[ nc ];
  _con_queue.in_store = new bool[ nc ];
  memset( _con_queue.in_store, false, nc );
  _con_queue.capacity = nc;
  _con_queue.size = 0;

  _var_queue.store = new int[ nv ];
  _var_queue.in_store = new bool[ nv ];
  memset( _var_queue.in_store, false, nc );
  _var_queue.capacity = nv;
  _var_queue.size = 0;
}

ConstraintStore::~ConstraintStore() 
{
  delete[] _con_queue.store;
  delete[] _con_queue.in_store;
  delete[] _var_queue.store;
  delete[] _var_queue.in_store;
}

/*
 * Constraints added to the queue during variable selection.
 * Add an event only if the variable has been touched by the
 * labeling step or by the propagation of another variable.
 */
void ConstraintStore::add( int vid )
{
  // consume variable
  _var_queue.in_store[ vid ] = false;
   
  if ( g_var_set[ vid ]->dom.event() == EMPTY_EVENT ) return;

  for( int i=0; i<g_constr_of_var[ vid ].size(); i++ )
  {
    int cid = g_constr_of_var[ vid ][ i ]->id();
    //g_constr_set[ cid ]->dump();
    if( !_con_queue.in_store[ cid ] && 
	!g_constr_set[ cid ]->is_fixpt() )
    {
      _con_queue.store[ _con_queue.size++ ] = cid;
      _con_queue.in_store[ cid ] = true;
    }
  }
}

void ConstraintStore::flush()
{
  // flush variable queue
  while( _var_queue.size > 0 )
  {
    _var_queue.in_store[ _var_queue.store[ --_var_queue.size ] ] = false;
  }

  // flush constraint queue
  while( _con_queue.size > 0 )
  {
    _con_queue.in_store[ _con_queue.store[ --_con_queue.size ] ] = false;
  }
}

void ConstraintStore::reset()
{
  flush();
  std::map<int, Constraint*>::iterator it;
  for( it = g_constr_set.begin(); it != g_constr_set.end(); ++it )
    {
      it->second->unset_fixpt();
    }
}

// simplified version with no backtrack ...
bool ConstraintStore::ISOLVPAR()
{
  bool success; int c_id;

#ifdef DBG
  cout << "  Propagating...\n";
#endif
  while ( _con_queue.size > 0 )
  {
    // note: queue contains only constraints that have not reached fixpt yet 
    while( _con_queue.size > 0 )
    {
#ifdef DBG
      cout << "propagate con: " << _con_queue.size-1 << endl;
#endif
      success = Propagator::propagate( _con_queue.store[ _con_queue.size-1 ] );
      if ( !success ) { flush();  return false; }
      _con_queue.in_store[ _con_queue.store[ --_con_queue.size ] ] = false;
#ifdef DBG
      cout << "Prop ok\n";
#endif
    }
    
    for (int i = 0; i < _var_queue.size; i++) 
    {
      success = Propagator::consistency ( _var_queue.store[ i ] );
      if ( !success ) { flush(); return false; }
#ifdef DBG
      cout << "Cons ok\n";
#endif
    }
    
    // Very important! I will have TONS of variable
    while( _var_queue.size > 0 ) 
    {
      add( _var_queue.store[ --_var_queue.size ] );
    }
  }

  return true;
}
