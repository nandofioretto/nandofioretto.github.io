/*********************************************************************
 * Search Engine Object
 * This search engine implements a Monte Carlo Search for the value
 * variable selection to explore a prop-labelling tree.
 *********************************************************************/
#ifndef MONTE_CARLO_VLAB_SEARCH_ENGINE_H
#define MONTE_CARLO_VLAB_SEARCH_ENGINE_H

#include "cpff_globals.h"
#include "search_engine.h"

class MonteCarlo_vlab : public SearchEngine 
{
 private:
  int _height;
  int _curr_level;
  int _mc_limit;
  int _curr_trial;

  std::default_random_engine _generator;
  size_t _seed;

protected:
  Variable* variable_selection ();
  void initialize();
  bool labeling( Variable *v );
  void process_solution();
  int step();

 public:
  MonteCarlo_vlab (int argc, char* argv[]);
  ~MonteCarlo_vlab();
  
  void reset ();
  void search ();
  void dump_statistics (std::ostream &os = std::cout);
};

#endif
