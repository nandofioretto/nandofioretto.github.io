#include "tfs_first_search.h"
#include "variable.h"
#include "var_int.h"
#include "constraint.h"
#include "constraint_store.h"
#include "main_utils.h"
// #include "trailstack.h"

// Borrowed from CRNIff
#include "solution.h"
#include "statistics.h"

using namespace std;

//#define DBG
//#define VERBOSE

TFsFirstSearch::TFsFirstSearch( int argc, char* argv[] )
  : _curr_level( 0 ), _mc_limit( 0 ), _curr_trial( 0 )
{
  for (int narg=0; narg < argc; narg++) 
  {
    if (!strcmp ("--max-numof-solutions",argv[narg])) {
      SearchEngine::_max_numof_solutions = atoi(argv[narg + 1]);
    }
    if (!strcmp ("--mc-limit", argv[ narg ])) {
      _mc_limit = atoi( argv[ narg + 1 ] );
      g_stats.set_nMC_trials( _mc_limit );
    }
  }
  
  _g_CP_SOLUTIONS_COUNTER = 0;
  _height = g_var_set.size();
  _seed = 0;//chrono::system_clock::now().time_since_epoch().count();
  _generator.seed( _seed );
}
//-

// inefficient now -- later: create a vector of vars and 
// only move index to select next var -- then reset by setting
// back the index...
// Hack! check if to set bounds!
void TFsFirstSearch::reset()
{
  _curr_level = 0;
  g_curr_var_labeled = -1;

  g_constraint_store->reset();
  while( _assigned_vars.size() > _assigned_on_start ) {
    _remaining_vars.push( _assigned_vars.top() );
    Utilities::restore_var_state( g_var_set[ _assigned_vars.top() ] );
    _assigned_vars.pop();
  }

}

TFsFirstSearch::~TFsFirstSearch () { }

Variable* TFsFirstSearch::variable_selection()
{ 
  Variable* v = g_var_set[ _remaining_vars.top() ];
  _assigned_vars.push( _remaining_vars.top() );
  _remaining_vars.pop();
  return( v );
}

// Hack! check singlet event to set!
// note that here we choose to select from 1 to size, and not 
// from 0 to size-1 as we are going to select an ordinal 
// number 
bool TFsFirstSearch::labeling (Variable *v) 
{
  int size = v->dom.n_active();  /* random select among active elements: */
  if ( size == 0 ) { return false; }
  
  uniform_int_distribution<int> uni_distr( 1, size );
  int i_th =  uni_distr( _generator );
  // cout << "  Labeling: selecting " << i_th << "-th active\n";
  v->set_label_ith_active( i_th ); 
  // v->dump();
  v->dom.set_singleton( v->label() );
  g_constraint_store->add( v->id() );
  g_curr_var_labeled = v->id();

  return true;
}


// Assigns all the singleton variables and propagate the 
// constraints involving them.
void TFsFirstSearch::initialize()
{
  g_curr_var_labeled = -1;


  std::map<int,std::string>::iterator it;
  for( int i = 0; i < g_TGs.size(); i++ )
  {
    int gi = g_TGs[ i ];
    it = g_gene_names.begin();
    for( ; it != g_gene_names.end(); ++it )
    {
      int gj = it->first; 
      Variable *v = g_var_set[ g_edge_var[ make_pair(gi, gj) ] ];

      if( v->is_assigned() )
      {
	//cout << "v" << v->id() << " assigned - add constr: \n";
	_assigned_vars.push( v->id() );
	v->dom.set_singleton( v->label() );
	g_constraint_store->add( v->id() );
      }
      else 
      {
	_remaining_vars.push( v->id() );
	v->reset_label();
	Utilities::save_var_state( v );
      }
    }
  }

  for( int i = 0; i < g_TFs.size(); i++ )
  {
    int tf = g_TFs[ i ];
    it = g_gene_names.begin();
    for( ; it != g_gene_names.end(); ++it )
    {
      int tg = it->first; 
      Variable *v = g_var_set[ g_edge_var[ make_pair(tf, tg) ] ];

      if( v->is_assigned() )
      {
	//cout << "v" << v->id() << " assigned - add constr: \n";
	_assigned_vars.push( v->id() );
	v->dom.set_singleton( v->label() );
	g_constraint_store->add( v->id() );
      }
      else 
      {
	_remaining_vars.push( v->id() );
	v->reset_label();
	Utilities::save_var_state( v );
      }
    }
  }

  _assigned_on_start = _assigned_vars.size();

#ifdef VERBOSE
    cout << "  N. variables already assigned: " << _assigned_vars.size() << endl;
    cout << "  N. variables not assigned: " << _remaining_vars.size() << endl;
#endif

  if( _assigned_vars.size() > 0 )  // if there is any assigned variable already
  {
    if ( !g_constraint_store->ISOLVPAR( ) ) // propagate over all constraints
    {
      cout << "  Error: The CSP is not satisfiable\n";
      exit(-1);
    }
  }
}

void TFsFirstSearch::search()
{

#ifdef VERBOSE
  cout << "Starting MC-TFs FIRST SEARCH\n";
#endif
  initialize();

  while ( _g_CP_SOLUTIONS_COUNTER < SearchEngine::_max_numof_solutions 
	  && _curr_trial++ < _mc_limit )
  {
    // cout << "  curr trial: " << _curr_trial << " / " << _mc_limit << endl;
    while( step() == IN_PROGRESS ) ; 
    //getchar();
    TFsFirstSearch::reset();
  }
}

// Hack! Check the backtrack part on the bottom.
int TFsFirstSearch::step ()
{
  if(  _remaining_vars.empty() ) { process_solution(); return SUCCESS; }
  Variable *v = variable_selection ();
  // cout << "  Selected var: " << v->id() << endl;

  if ( labeling( v ) )
  {
    //    v->dump();
#ifdef DBG
    Utilities::dump_vars(); getchar();
#endif
    if ( g_constraint_store->ISOLVPAR( ) ) return IN_PROGRESS;
    else{ g_stats.incr_MC_fails(); { return FAILURE;}}
    //if ( SearchEngine::aborted() ) return FAILURE;
  }
  return FAILURE;
}

void TFsFirstSearch::process_solution() 
{
  _g_CP_SOLUTIONS_COUNTER++;  
  g_solutions.push_back( new Solution );
  //g_solutions.back()->dump();
}


void TFsFirstSearch::dump_statistics (ostream &os) {
  if (SearchEngine::aborted())
    os << "Search aborted, timeout of numof solutions limit reached.";
  else 
    os << "Compleately explored the search space. ";
  os << "[Num. of Solutions Found: " 
     << _g_CP_SOLUTIONS_COUNTER << "]" << endl;
  //<< " Best Fscore " << max_fscore << endl;

  //    << g_statistics->get_solutions_found()
  //    << " | Seach time: "
  //    << g_statistics->get_total_timer (t_search)
  //    << " s.| Best Rmsd: " << g_statistics->get_rmsd (protein) << "A]\n";
}//-
