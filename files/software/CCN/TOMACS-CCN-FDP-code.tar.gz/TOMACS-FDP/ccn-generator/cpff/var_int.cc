#include "var_int.h"
#include "trailstack.h"

// For OP constraints

using namespace std;

var_int::var_int ( ) :
  already_assigned ( false )
{
  dom_size = domain.size();
  dom_values.reserve( dom_size );
  for( int i=0; i < dom_size; i++)
    dom_values[ i ] = domain[ i ];
  domain.set_variable_ptr( this );
  lower_bound = 0;
  upper_bound = dom_size-1;
}//-

var_int::var_int ( vector< int > dom ) :
 already_assigned ( false ),
 dom_size ( dom.size() ),
 dom_values ( dom ) 
{
  Domain d( dom );
  domain = d;
  domain.set_variable_ptr( this );
  lower_bound = 0;
  upper_bound = dom.size()-1;
}//-

var_int::var_int (const var_int& other) {
  already_assigned = other.already_assigned;
  dom_size = other.dom_size;
  dom_values = other.dom_values;
  domain = other.domain;
  domain.set_variable_ptr( this );
  lower_bound = other.lower_bound;
  upper_bound = other.upper_bound;
}//-

var_int::~var_int () {
}//-

int
var_int::get_domain_size () {
  return dom_size;
}//get_domain_size

/* Bounds management */
int
var_int::get_lower_bound() {
  return /*dom_values[*/ lower_bound /*]*/;
}//get_lower_bound

int
var_int::get_upper_bound() {
  return /*dom_values[*/ upper_bound /*]*/;
}//get_upper_bound

void
var_int::reset_bounds() {
  lower_bound = 0;
  upper_bound = dom_values.size()-1;
  for( int i = lower_bound; i <= upper_bound; i++ )
    domain.set( i, true );
}//reset_bounds

void
  var_int::set_bounds ( int lb, int ub, bool check_assigned ) {
  lower_bound = lb;
  upper_bound = ub;
  for( int i = 0; i < lb; i++) domain.unset( i );
  for( int i = ub+1; i < dom_size; i++) domain.unset( i );

  if (check_assigned && lower_bound == upper_bound )
    already_assigned = true;
}//set_bounds

void
var_int::set_lower_bound ( int v ) {
  lower_bound = v;
  for( int i = 0; i < lower_bound; i++) domain.unset( i );

  if ( lower_bound == upper_bound )
    already_assigned = true;
}//set_lower_bound

void
var_int::set_upper_bound ( int v ) {
  upper_bound = v;
  for( int i = upper_bound+1; i < dom_size; i++) domain.unset( i );

  if ( lower_bound == upper_bound )
    already_assigned = true;
}//set_upper_bound

bool
var_int::is_already_assigned() {
  return already_assigned;
}

void
var_int::set_already_assigned() {
  already_assigned = true;
}

void
var_int::unset_already_assigned() {
  already_assigned = false;
}

void
var_int::set_unique_singleton() {
  set_already_assigned();
}//set_unique_singleton

void 
var_int::set_singleton ( size_t pos ) {
  domain.unset();
  domain.set ( pos );
  lower_bound = upper_bound = pos;
}//-

void
var_int::unset_singleton ( size_t pos ) {
  domain.unset( pos );
}//-

bool
var_int::is_singleton () {
  return ( lower_bound == upper_bound );
}//-
  
bool 
var_int::labeling () {
  label++;
  if (label < lower_bound) label = lower_bound;
  while ( ( label <= upper_bound ) &&
          ( !domain.is_valid( label ) ) ) {
    label++;
  }
  if ( label > upper_bound ) return false;
  
  //lower_bound = upper_bound = label; 
  //domain.set_singlet ( label );
  
  return true;
}//labeling

unsigned int*
var_int::get_dom_state() {
  return domain.get_state();
}//-

void 
var_int::set_dom_state( unsigned int* other_state ) {
  domain.set_state ( other_state );
}//-

void 
var_int::trail_back (TrailVariable& tv) {
  already_assigned = false;
  lower_bound = tv.lower_bound;
  upper_bound = tv.upper_bound;
  domain.set_state ( tv.dom_state );
}//-

void
var_int::print_value() {
  cout << dom_values[ label ];
}//print_value

int var_int::get_value() 
{
  return dom_values[ label ];
}//-

void
var_int::dump () {
  cout << "var_int_" << id << " ";
  if( label < 0 ) cout << "Val: ??\t";
  else cout << "Val: " << dom_values[ label ] << "\t";
  cout << "Dom: [ ";
  for( int i=0; i< dom_values.size(); i++)
    cout << dom_values[ i ] << ", ";
  cout  << " ]";
 // if (dom_values.size() > 0) 
 //  {
 //    cout << "Dom: [ " << dom_values[ lower_bound ] << ".." <<
 //    dom_values[ upper_bound ] << " ]";
 //  }
  if (already_assigned) cout << " ALREADY ASSIGNED ";
  cout << " LB: " << lower_bound << " UB: " << upper_bound << endl;
}//dump
