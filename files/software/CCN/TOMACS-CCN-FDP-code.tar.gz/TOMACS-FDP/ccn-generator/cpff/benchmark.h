#ifndef CP_BENCHMARK_
#define CP_BENCHMARK_

#include "cpff_globals.h"

// CP Core headers
#include "constraint_store.h"
#include "main_utils.h"

// CP Variables
#include "domain.h"
#include "variable.h"
#include "var_int.h"
//#include "var_bool.h"

// CP Constraints
#include "constraint.h"

namespace Benchmark {
  //string2constr
  constr_type string2constr (std::string constrType, int l);
  
  //parseInput
  void parseInput(std::string filename);
  
  //BaseTest
  void BaseTest(int n);
  void print_BaseTest();
  
  //NQueens
  void NQueens(int n);
  void print_NQueens();
}

#endif
