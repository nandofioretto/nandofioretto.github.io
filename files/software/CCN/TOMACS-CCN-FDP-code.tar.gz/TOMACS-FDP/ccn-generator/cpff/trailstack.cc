#include "trailstack.h"
#include "variable.h"
#include "var_int.h"

using namespace std;

//#define TRAILSTACK_DBG

/**********************************************
 * TrailFDVariable Methods
 **********************************************/
TrailVariable::TrailVariable ( Variable* v, size_t _cont ) :
 link_to_var ( v ),
 continuation ( _cont ) {
  lower_bound = v->get_lower_bound();
  upper_bound = v->get_upper_bound();
  memcpy ( dom_state, v->get_dom_state(), MAX_DIM * sizeof( unsigned int ) );
}//-

TrailVariable::~TrailVariable() {
}//-
  
TrailVariable::TrailVariable ( const TrailVariable& other ) {
  continuation = other.continuation;
  link_to_var  = other.link_to_var;
  lower_bound  = other.lower_bound;
  upper_bound  = other.upper_bound;
  memcpy ( dom_state, other.dom_state, MAX_DIM * sizeof( unsigned int ) );
}//-

TrailVariable&
TrailVariable::operator= ( const TrailVariable& other ) {
  if ( this != &other ) {
    continuation = other.continuation;
    link_to_var  = other.link_to_var;
    lower_bound  = other.lower_bound;
    upper_bound  = other.upper_bound;
    memcpy ( dom_state, other.dom_state, MAX_DIM * sizeof( unsigned int ) );
  }
  return *this;
}//-
  

/**********************************************
 * TrailStack Methods
 **********************************************/
void
TrailStack::backtrack (size_t continuation) {
  string dbg = "TrailStack::backtrack() - ";

  while (trailstack.size() > continuation)
  {
    TrailVariable tv = trailstack.top();
    
#ifdef TRAILSTACK_DBG
    cout << dbg << "Trailing VAR: "
	 << tv.link_to_var->get_id() << endl;
#endif
    
    tv.link_to_var->trail_back ( tv ); 
    
    trailstack.pop();
  };
  // Reset Constraint Fixpoints
  for( int i = 0; i < g_constraints.size(); i++)
    if ( gh_params.constraint_fixpoint[ i ] >= continuation )
      gh_params.constraint_fixpoint[ i ] = -1;

}//backtrack
  
size_t 
TrailStack::size () const {
  return trailstack.size();
}//-

bool 
TrailStack::is_empty () const {
  return trailstack.empty();
}//-

void
TrailStack::reset () {
  while ( !trailstack.empty() )
    trailstack.pop();
}//-

void
TrailStack::trail_variable ( Variable* v ) {
  size_t ttop = trailstack.size();
  TrailVariable te ( v, ttop );
  trailstack.push ( te );
}//trail_variable


void 
TrailStack::trail_constraint_fixpoint( int c_id ) {
  gh_params.constraint_fixpoint[ c_id ] = trailstack.size();
}
