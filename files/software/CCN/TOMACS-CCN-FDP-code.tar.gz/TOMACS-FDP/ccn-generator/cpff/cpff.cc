#include "cpff_globals.h"
// CP Core headers
#include "constraint_store.h"
#include "trailstack.h"
#include "depth_first_search.h"
#include "monte_carlo_vlab.h"
#include "main_utils.h"
// CP Variables
#include "domain.h"
#include "variable.h"
#include "var_int.h"
// CP Constraints 
#include "constraint.h"
// CP Benchmark
#include "benchmark.h"

using namespace std;
using namespace Utilities;

int main (int argc, char* argv[]) 
{
  srand (time(NULL));

  string dbg = "Main:: Main function - ";
  int vars_num = 0, b_test = -1;
  string file_to_parse="";
  int search_type = 0;
  timeval time_stats;
  double time_start, total_time;
  gettimeofday(&time_stats, NULL);
  gh_params.max_num_of_solutions = 1;

  for (int narg = 0; narg < argc; narg++) 
  {
    if (!strcmp ("--file", argv[narg]) || !strcmp ("-f", argv[narg]))
      file_to_parse = argv[narg + 1];
    if (!strcmp ("-s", argv[narg]) ) 
      search_type = atoi( argv[narg+1]);
    if (!strcmp ("-l", argv[narg]) ) 
      gh_params.max_num_of_solutions = atoi( argv[narg+1]);
  }

  /**************************************************************
   * Constraint Satisfaction Problem Modeling
   *************************************************************/  

  g_trailstack       = new TrailStack ();
  g_constraint_store = new ConstraintStore ();

  size_t nvars = 5;
  size_t nelem = 4;
  vector<int> dom;
  for (int i=0; i<nelem; i++) dom.push_back( i );

  for (int i = 0 ; i < nvars; i++) new var_int(dom);

  std::vector< int > vars( nvars );
  for (int i = 0; i < nvars; i++ ) vars[ i ] = i;

  std::vector< int > coeff;

  // coeff.push_back( 7 );  // K
  // coeff.push_back( 50 );  // >= THS
  // new Constraint( int_atmostk_ge, vars, coeff );

  // coeff.clear();
  // coeff.push_back( 5 );  // K
  // coeff.push_back( 80 );  // >= THS
  // new Constraint( int_atleastk_ge, vars, coeff2 );


  vars.clear(); coeff.clear();
  vars.push_back(2);  vars.push_back(3);
  coeff.push_back( 1 );
  new Constraint( int_agt_if_blt, vars, coeff );

  Utilities::alloc_variables();
  Utilities::alloc_constraints();
  
  if ( file_to_parse!="") 
  {
    Benchmark::parseInput( file_to_parse );
  }
  cout << dbg << "Num. of variables: "   <<   g_cp_variables.size() << endl;
  cout << dbg << "Num. of constraints: " <<   g_constraints.size() << endl;

  
  /**************************************************************
   * Search phase
   *************************************************************/
  g_constraint_store->init();
  
  time_start = time_stats.tv_sec + (time_stats.tv_usec/1000000.0);
  
  DepthFirstSearchEngine *dfs;
  MonteCarlo_vlab* mc;

  switch( search_type )
  {
  case 0:
    dfs = new DepthFirstSearchEngine();
    dfs->search();
    break;
  case 1:
    mc = new MonteCarlo_vlab(1000000);
    mc->search();
    break;
  
  }
  gettimeofday(&time_stats, NULL);
  total_time = time_stats.tv_sec + (time_stats.tv_usec/1000000.0) - time_start;
  cout << "Time: " << total_time << endl;
  
  //delete search_engine;
  delete g_constraint_store;
  delete g_trailstack;
  clear_all();
  
  return 0;
}//-
