#include "variable.h"
#include "domain.h"
// #include "trailstack.h"

using namespace std;

Variable::Variable () :
  _label ( -1 ),  _assigned ( false )
{
  static size_t _g_CP_VARIABLE_COUNTER = 0;
  _id = _g_CP_VARIABLE_COUNTER++;

  // Add reference to the global set of CP Variables
  g_var_set[ _id ] = this;
  dom.set_vptr( this );
}

Variable::Variable ( std::vector<double> values ) :
  _label ( -1 ),  _assigned ( false )
{
  static size_t _g_CP_VARIABLE_COUNTER = 0;
  _id = _g_CP_VARIABLE_COUNTER++;

  // Add reference to the global set of CP Variables
  g_var_set[ _id ] = this;
  Domain tmp( values );
  dom = tmp;
  dom.set_vptr( this );
}


Variable::Variable ( const Variable& other ) 
{
  _id          = other._id;
  _label       = other._label;
  _assigned    = other._assigned;
  dom         = other.dom;
}

Variable& Variable::operator= (const Variable& other) 
{
  if (this != &other) {
    _id          = other._id;
    _label       = other._label;
    _assigned    = other._assigned;
    dom         = other.dom;
  }
  return *this;
}

bool Variable::operator== (const Variable& other) 
{
  return (_id == other._id);
}

size_t Variable::id () const 
{
  return _id;
}

void Variable::assign () 
{
  _assigned = true;
}

void Variable::unassign () {
  _assigned = false;
}

bool Variable::is_assigned () const 
{
  return _assigned;
}

void Variable::set_label (int l) 
{
  _label = l;
  if ( _label >= 0 )
    _assigned = true;
}


// ith = 1
// n active = 1
// i = 0
// ac = 0
void Variable::set_label_ith_active( int ith )
{
  assert( ith <= dom.n_active() );

  int i = dom.lb_pos();
  int ac = 0;
  while( ith != 0 )
    {
      if( dom.is_valid( i++ ) ) ith--;
    }
  set_label( i-1 );
}

void::Variable::reset_label () 
{ 
  _label = -1;
}

int Variable::label () const 
{
  return _label;
}

bool Variable::labeling () // used?
{
  _label++;
  if ( _label < dom.lb_pos() ) 
    _label = dom.lb_pos();
  
  while ( ( _label <= dom.ub_pos() ) &&
          ( !dom.is_valid( _label ) ) ) {
    _label++;
  }
  if ( _label > dom.ub_pos() ) return false;
    
  return true;
}

// void Variable::trail_back (TrailVariable& tv) 
// {
//   // already_assigned = false;
//   dom.set_state ( tv.dom_state );
// }//-

double Variable::value() const
{
  return dom[ _label ];
}//-

void Variable::dump () 
{
  printf("var %zd ", _id);
  if( _label < 0 ) printf("[value: ??]\t");
  else printf("[value: %.2f]\t", value());
  printf("Dom: ");
  dom.dump();
  // if (dom_values.size() > 0) 
  //  {
  //    cout << "Dom: [ " << dom_values[ lower_bound ] << ".." <<
  //    dom_values[ upper_bound ] << " ]";
  //  }
  //if (already_assigned) cout << " ALREADY ASSIGNED ";
}
