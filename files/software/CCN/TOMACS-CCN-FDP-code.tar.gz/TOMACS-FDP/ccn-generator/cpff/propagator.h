#ifndef CP_PROPAGATOR_
#define CP_PROPAGATOR_

#include "cpff_globals.h"

typedef bool (*propagator)( int ); /* typedef to a function pointer which 
				      returns bool and takes in input int. */

namespace Propagator
{
  propagator select( int cid );
  bool consistency( int vid );
  bool propagate( int cid );
  bool c_ATLEAST_K_GE( int c_id );
  bool c_ATMOST_K_GE( int c_id );
  bool c_ATMOST_K_GE_FAST( int c_id );
  bool c_RED_EDGE( int c_id );
  bool c_DIR_SEL( int c_id );
  bool c_ONE_DIR( int c_id );
  bool c_COTF( int c_id );
  bool c_NET_MODULE( int c_id );

}

#endif
