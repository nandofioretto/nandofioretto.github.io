#include "constraint_store.h"
#include "variable.h"
#include "var_int.h"
#include "constraint.h"
#include "trailstack.h"
#include "cpff_globals.h"
#include "propagator.h"
 
using namespace std;
using namespace Propagator;

//#define CSTORE_DBG_ISOLVPAR


prop_func
func[ c_type_size ] = {
  c_int_lin_ne,
  c_int_ne,
  c_int_lin_le,
  c_int_atleastk_ge,
  c_int_atmostk_ge,
  c_int_agt_if_blt
  /* c_array_bool_and,
   c_array_bool_element,
   c_array_bool_or,
   c_int_ne_reif,
   c_int_eq, int_lt,
   c_int_plus,
   c_int_lin_eq */ };

ISolve::ISolve() {
  backtrack_action = -1;
  curr_labeled_var = 0;
}//-

ISolve::~ISolve() {
  free( dom_events );
  free( constraint_queue );
  free( already_set_cons );
}//-

void ISolve::reset()
{
  backtrack_action = -1;
  curr_labeled_var = 0;
  memset( dom_events, -1, (1 + gh_params.num_vars * 2) * sizeof(int) );
}

void
ISolve::init() 
{
  n_threads = min ( ((gh_params.max_dom_size/32)+1), MAX_DIM );
  n_threads = max ( n_threads, gh_params.max_scope_size );
  dom_events       = (int*) malloc( (1 + gh_params.num_vars * 2) * sizeof(int) );
  constraint_queue = (int*) malloc( gh_params.num_cons * sizeof(int) );
  already_set_cons = (int*) malloc( gh_params.num_cons * sizeof(int) );
  
  memset( dom_events, -1, (1 + gh_params.num_vars * 2) * sizeof(int) );
}//init

void
ISolve::set_singlet_event ( int v_idx, int label ) {
  dom_events[gh_params.num_vars + 1 + v_idx] = label;

  // Set Current labeled variable AUX structures for BOUNDS
  var_int* var = (var_int*)g_cp_variables[ v_idx ];
  int v_id = var->get_id();

  memcpy( &gh_params.domain_states[ MAX_DIM * v_id ], 
	  var->domain.get_state(), MAX_DIM * sizeof(unsigned int) );
  gh_params.domain_bounds[ 2*v_id ]     = label;
  gh_params.domain_bounds[ 2*v_id + 1 ] = label;
  // --

}//set_singlet_event

bool
ISolve::ISOLVPAR( vector<var_int> *V, bool trail ) 
{
#ifdef CSTORE_DBG_ISOLVPAR
  cout << "ISOLVPAR: enter..." << endl;
  getchar();
#endif
  
  // If backtrack -> copy the previous states
  //- NAN: note, this should not be done if we do not backtrack
  if ( backtrack_action >= 0 ) {
    copy_state_to_gpu( backtrack_action );
    backtrack_action = -1;
  }

  //// --->
  memset( already_set_cons, 0, gh_params.num_cons * sizeof(int) );
  constraint_queue_size = 0;
  for(int i = 0; i < V.size(); i++ )
  {
    int v_id = V[ i ]->get_id();
    int c_vi_size = gh_params.constraint_events[ v_id ][ ALL_EVENTS ].size();
    for( int ii = 0; ii < c_vi_size; ii++ )
    {
      int c_id = gh_params.constraint_events[ v_id ][ ALL_EVENTS ][ ii ];
      if( ! already_set_cons[ c_id ] )
	constraint_queue[ constraint_queue_size++ ] = c_id;
    }
  }
  //// <<---  

  int events_size = (1 + gh_params.num_vars) * sizeof(int);
  bool more_constraints = true;

  while ( more_constraints )
  {
#ifdef CSTORE_DBG_ISOLVPAR
    cout << "ISOLVPAR: while..." << constraint_queue_size << endl;
    getchar();
#endif
    
    more_constraints = false;
    
    memset( dom_events, EMPTY_EVENT, events_size );
    memset( already_set_cons, 0, gh_params.num_cons * sizeof(int) );

    bool success;
    for (int i = 0; i < constraint_queue_size; i++) 
    {
      int c_id  = constraint_queue[ i ];
      int c_idx = gh_params.constraint_descriptions_idx[ c_id ];

      if( gh_params.constraint_fixpoint[ c_id ] < 0 )
      {
	success = 
	  func[ gh_params.constraint_descriptions[ c_idx ] ] 
	  ( c_id, c_idx, gh_params.num_vars, n_threads,
	    gh_params.domain_states, gh_params.domain_bounds, dom_events );
	if ( !success ) 
	{ /*cout << "fail " << i << endl; getchar();*/ 
	  return false; 
	}
      }
      // else cout << "Fixpoint Reached at lev : " 
      // 		<< gh_params.constraint_fixpoint[ c_id ] << endl;
    }
    
    for (int i = 0; i < gh_params.num_vars; i++) 
    {
      /*
      if (dom_events[i] != EMPTY_EVENT) {
        cout << "V_" << i << " changed " << endl;
      }
      */
      h_check ( i, n_threads, 
		curr_labeled_var, 
		gh_params.domain_states, 
      		gh_params.domain_bounds, dom_events );
    }
    
    
 #ifdef CSTORE_DBG_ISOLVPAR
    cout << "ISOLVPAR: ...propagation done " << curr_labeled_var << endl;
    getchar();
 #endif
    
    if ( dom_events[gh_params.num_vars] == FAILED_EVENT ) { 
      // cout << "fail EV " << endl; getchar(); 
      return false; 
    }
    
    int c_id;
    constraint_queue_size = 0;
    // HACK! Handle not-consecutive labelings
    for (int i = 0; i < gh_params.num_vars; i++) 
    {
      if (dom_events[i] == EMPTY_EVENT) continue;
      for (int j = 0; j < gh_params.constraint_events[ i ][ dom_events[ i ] ].size(); j++) {
        c_id = gh_params.constraint_events[ i ][ dom_events[ i ] ][ j ];
        if ( !already_set_cons[ c_id ] ) 
	{
          constraint_queue[ constraint_queue_size++ ] = c_id;
          already_set_cons[ c_id ] = 1;
        }
      }
    }//i

    if ( constraint_queue_size > 0 ) more_constraints = true;
  }//while
  
#ifdef CSTORE_DBG_ISOLVPAR
  cout << "ISOLVPAR: exit..." << endl;
#endif

  copy_state_from_gpu( curr_labeled_var, trail );
  
  return true;
}//ISOLVPAR


/*
 * @note:
 * Copy the state of the variables before 
 * changing their domains during ISOLVPAR.
 */
void
ISolve::copy_state_to_gpu(int level)
{
  int v_id;
  var_int* var;
  // HACK! Handle not-consecutive labelings
  for (int i = level; i < gh_params.num_vars; i++) 
  {
    var = (var_int*)g_cp_variables[i];
    v_id = var->get_id();
    memcpy( &gh_params.domain_states[ MAX_DIM * v_id ], 
	    var->domain.get_state(), MAX_DIM * sizeof(unsigned int) );
  
    if ( i > level ) 
    {
      gh_params.domain_bounds[ 2*v_id ]     = var->get_lower_bound();
      gh_params.domain_bounds[ 2*v_id + 1 ] = var->get_upper_bound();
      // check further singletons
      if ( gh_params.domain_bounds[ 2*v_id ] == 
	   gh_params.domain_bounds[ 2*v_id + 1 ] )
        dom_events[ gh_params.num_vars + v_id + 1] = 
	  gh_params.domain_bounds[ 2*v_id ];
      else
        dom_events[ gh_params.num_vars + v_id + 1] = -1;
    }
  }
}//copy_state_to_gpu

void
ISolve::copy_state_from_gpu(int level, bool trail) {
  /*
   * @note: copy
   * 1) new bounds (and set singlets)
   * 2) new states
   */
  int v_id;
  var_int* var;
  // HACK! Handle not-consecutive labelings
  for (int i = level; i < gh_params.num_vars; i++) 
  {
    var = (var_int*)g_cp_variables[i];
    v_id = var->get_id();
    
    if( trail ) g_trailstack->trail_variable ((Variable*)var);
    
    var->domain.set_state( &gh_params.domain_states[ MAX_DIM * v_id ] );
    var->set_bounds( gh_params.domain_bounds[ 2 * v_id ], 
		     gh_params.domain_bounds[ 2 * v_id + 1 ], (i>level) );
  }//i

}//copy_state_from_gpu

void
ISolve::dump_domains() {
  copy_state_from_gpu( 0 );
  
  for (int i = 0; i < gh_params.num_vars; i++) {
    ((var_int*)g_cp_variables[i])->dump();
    ((var_int*)g_cp_variables[i])->domain.dump();
  }
}

void
ISolve::init_states_on_gpu() {
  copy_state_to_gpu(0);
}//init_states_on_gpu

