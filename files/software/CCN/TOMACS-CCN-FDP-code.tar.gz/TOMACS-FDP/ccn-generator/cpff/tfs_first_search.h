/*********************************************************************
 * Search Engine Object
 * This search engine implements a Monte Carlo Search with variable 
 * selection based on a principle similar to feature selection used
 * in GENIE3 or TIGRESS, where TFs are selected before TGs.
 *********************************************************************/
#ifndef TFS_FIRST_SEARCH_ENGINE_H
#define TFS_FIRST_SEARCH_ENGINE_H

#include "cpff_globals.h"
#include "search_engine.h"

class TFsFirstSearch : public SearchEngine 
{
 private:
  int _height;
  int _curr_level;
  int _mc_limit;
  int _curr_trial;

  std::default_random_engine _generator;
  size_t _seed;

protected:
  Variable* variable_selection ();
  void initialize();
  bool labeling( Variable *v );
  void process_solution();
  int step();

 public:
  TFsFirstSearch (int argc, char* argv[]);
  ~TFsFirstSearch();
  
  void reset ();
  void search ();
  void dump_statistics (std::ostream &os = std::cout);
};

#endif
