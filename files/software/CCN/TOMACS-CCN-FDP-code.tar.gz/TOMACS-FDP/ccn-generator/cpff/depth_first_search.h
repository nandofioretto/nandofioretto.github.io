/*********************************************************************
 * Search Engine Object
 * This search engine implements a simple DFS to explore a 
 * prop-labelling tree.
 *********************************************************************/
#ifndef DEPTH_FIRST_SEARCH_ENGINE_H
#define DEPTH_FIRST_SEARCH_ENGINE_H

#include "cpff_globals.h"
#include "search_engine.h"

class DepthFirstSearchEngine : public SearchEngine {
 private:
  int _height;
  int _curr_level;

protected:
  Variable* variable_selection ();
  bool labeling ( Variable *v );
  void process_solution();
  void goto_next_level ();
  void goto_prev_level ();

 public:
  DepthFirstSearchEngine ();
  ~DepthFirstSearchEngine();
  
  void reset ();
  void search ();
  void dump_statistics (std::ostream &os = std::cout);
};

#endif
