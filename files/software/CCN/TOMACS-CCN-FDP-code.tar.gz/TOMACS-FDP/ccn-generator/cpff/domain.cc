#include "domain.h"
#include "variable.h"
#include <cassert> 

using namespace std;

Domain::Domain () 
  : _size ( 0 ), _min ( -1 ), _max ( 0 ), 
    _var_ptr ( NULL ) , _nactive( 0 ), _event( EMPTY_EVENT )
{ }

Domain::Domain ( vector< double > elements ) 
  : _size( elements.size() ),
    _var_ptr( NULL ),
    _min( 0 ),
    _max( _size - 1 ),
    _nactive( _size ),
    _event( EMPTY_EVENT )
{
  _values = elements;
  std::sort( _values.begin(), _values.end() );
  _state.resize( _size, true );
}

Domain::Domain ( const Domain& other ) 
{
  _size = other._size;
  _min = other._min;
  _max = other._max;
  _var_ptr = other._var_ptr;
  _nactive = other._nactive;
  _event = other._event;
  _values = other._values;
  _state = other._state;
}

Domain& Domain::operator= (const Domain& other) 
{
  if (this != &other) 
  {
    _size = other._size;
    _min = other._min;
    _max = other._max;
    _var_ptr = other._var_ptr;
    _nactive = other._nactive;
    _event = other._event;
    _values = other._values;
    _state = other._state;
  }
  return *this;
}

Domain::~Domain () 
{ }

double Domain::operator [] (int i) const 
{
  return _values[ i ];
}


void Domain::add( double elem )
{
  if( std::find( _values.begin(), _values.end(), elem ) != _values.end() )
    return;
  
  double _lb = lb(), _ub = ub();

  int i = 0;
  while( _values[ i ] < elem && i < _size ) {i++; }
  std::vector<double>::iterator dt = _values.begin();
  std::vector<bool>::iterator bt = _state.begin();
  
  std::advance( dt, i ); 
  std::advance( bt, i ); 
  _values.insert( dt, elem );
  _state.insert( bt, true );

  if( elem < _lb ) {_min = i; _max++; } 
  else if( elem > _ub ) { _max = i; }
  else if( elem > _lb && elem < _ub ) { _max++; }
  _size++;  _nactive++;
}

void Domain::set_vptr( Variable* v ) 
{
  _var_ptr = v;
}

Variable* Domain::var_ptr()
{
  return _var_ptr;
}

std::vector< bool > Domain::state () 
{
  return _state;
}

void Domain::set_state ( std::vector<bool> other_state ) 
{
  _state = other_state;
  _min = -1; _max = _size+1;
  _event = DC_EVENT;
  // update _min _max active elements
  int i = -1;
  while( i++ < _size ) { if ( _state[ i ] ){ _min = i; break; } }
  int j = _size;
  while( j-- > i ) { if ( _state[ j ] ) _max = i; }

  // update the number of active elements
  if ( _min == -1 || _max == _size+1 ) 
  {
    _nactive = 0;
    _event = FAILED_EVENT;
  }
  else 
  {
    _nactive=0;
    for( i = _min; i <= _max; i++ )
      _nactive += _state[ i ];
    // check sing event
    if( _nactive == 1 ) _event = SING_EVENT; 
  }
}

void Domain::set()
{
  // update domain changed event
  if( _nactive < _size ) _event = DC_EVENT;

  for( int i=0; i<_size; i++) 
    _state[ i ] = true;

  // update bounds changed event
  if( _min > 0 || _max < _size-1 ) _event = BC_EVENT;

  _min = 0; _max = _size-1;
  _nactive = _size;
}

void Domain::set( int pos ) 
{
  if( !_state[ pos ] ) 
  {
    _state[ pos ] = true;
    _nactive++;
    // update domain changend event
    _event = DC_EVENT;
    // update bounds and events
    if( pos < _min ) { _min = pos; _event = BC_EVENT; }
    else if( pos > _max ) { _max = pos; _event = BC_EVENT; }
    // check sing event
    if( _nactive == 1 ) _event = SING_EVENT;
  }
}

void Domain::set_singleton( int pos ) 
{
  for( int i=0; i<_size; i++)
    _state[ i ] = false;

  _state[ pos ] = true;
  _min = _max = pos;
  _nactive = 1;
  _event = SING_EVENT;
}

void Domain::unset () 
{
  for( int i=0; i<_size; i++)
    _state[ i ] = false;  
  _nactive = 0;
  _event = FAILED_EVENT;
}

void Domain::unset ( int pos ) 
{
  if( _state[ pos ] )
  {
    _state[ pos ] = false;
    _nactive--;
    _event = DC_EVENT;		// domain changed
    if( pos == _min ) 
    {
      while( pos++ <= std::max((short)0, _max) )
	{ if( _state[ pos ] ) {_min = pos; _event = BC_EVENT; break;} }
    }
    else if( pos == _max )
    {
      while( pos-- >= std::min(_min, _size) ) 
	{ if( _state[ pos ] ) {_max = pos; _event = BC_EVENT; break;} }
    }
    if( _nactive == 1 ) _event = SING_EVENT;
  }
}

void Domain::set_lb( int pos ) 
{
  if( pos > _max ) { unset(); return; }
  if( pos == _min ) return;
  //if( pos == _max ) set_singleton( pos );
  if( pos < _min )
  {
    for( int i = pos+1; i < _min; i++ ) 
      set( i );
  }
  else if ( pos > _min ) 
  {
    for( int i = _min; i < pos; i++ )
      unset( i );
  }
  set( pos );
}

void Domain::set_ub( int pos ) 
{
  if( pos < _min ) { unset(); return; }
  if( pos == _max ) return;
  //if( pos == _min ) set_singleton( pos );
  if( pos < _max )
  {
    for( int i = pos+1; i <= _max; i++ )
      unset( i );
  }
  else if ( pos > _max ) 
  {
    for( int i = _max+1; i < pos; i++ )
      set( i );
  }
  set( pos );
}

bool Domain::is_valid () const 
{
  return ( _nactive > 0 ); 
}

bool Domain::is_failed () const 
{
  return ( !is_valid() );
}

bool Domain::is_valid (int pos) const 
{
  return ( _state[ pos ] );
}

bool Domain::is_singleton( ) const
{
  return ( _nactive == 1 );
}

int
Domain::size()
{
  return _size;
}

int Domain::n_active() const
{
  return _nactive;
}

double Domain::lb() const
{
  return _values[ _min ];
}

double Domain::ub() const
{
  return _values[ _max ];
}

int Domain::lb_pos() const
{
  return _min;
}

int Domain::ub_pos() const
{
  return _max;
}

double Domain::min() const
{
  return _values[ 0 ];
}

double Domain::max() const
{
  return _values[ _size ];
}

void Domain::copy_state( std::vector<bool> other_state )
{
  _state = other_state;
}

void Domain::copy_bounds( short l, short u )
{
  _min = l; _max = u;
}

void Domain::copy_n_active( short n )
{
  _nactive = n;
}

void Domain::set_event( int event )
{
  _event = event;
}

int Domain::event() const
{
  return _event;
}

void Domain::dump() 
{
  assert( _var_ptr );
  int i=0;
  int l = _var_ptr->label();
  cout << "{";
  for (; i < _size; i++) 
  {
    if ( i == _min ) printf("<");
    if (_values[ i ]==l) printf("[%.6f] ", _values[i]);
    else if ( _state[ i ] ) printf( "%.6f ", _values[i]);
    if ( i == _max ) printf(">");
  }
  cout << "}  lb: " << _min << " ub: " << _max; 
  cout << "  event: " << _event << endl; 
  
}
