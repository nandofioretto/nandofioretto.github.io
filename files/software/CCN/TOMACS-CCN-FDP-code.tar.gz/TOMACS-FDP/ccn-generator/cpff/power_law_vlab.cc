#include "power_law_vlab.h"
#include "variable.h"
#include "constraint.h"
#include "constraint_store.h"
#include "main_utils.h"

// Borrowed from CRNIff
#include "solution.h"
#include "statistics.h"

using namespace std;

//#define SEARCH_DBG
//#define VERBOSE

PowerLaw_vlab::PowerLaw_vlab( int argc, char* argv[] )
  : _xmin_cdf( 0 ), _mc_limit( 0 ), _curr_trial( 0 )
{
  for (int narg=0; narg < argc; narg++)
  {
    if (!strcmp ("--max-numof-solutions",argv[narg])) {
      SearchEngine::_max_numof_solutions = atoi(argv[narg + 1]);
    }
    if (!strcmp ("--mc-limit", argv[ narg ])) {
      _mc_limit = atoi( argv[ narg + 1 ] );
      g_stats.set_nMC_trials( _mc_limit );
    }
  init();
  }
}

PowerLaw_vlab::~PowerLaw_vlab ()
{ }

void PowerLaw_vlab::init()
{
  _g_CP_SOLUTIONS_COUNTER = 0;
  _numof_vars = g_var_set.size();
  _xmax_cdf   =  g_InfKB.nnodes/2;
  _x_cdf      = _xmax_cdf;
  seed = 0;//chrono::system_clock::now().time_since_epoch().count();
  generator.seed( seed );
  for ( int i = 0; i < g_InfKB.nnodes; i++ )
  {
    selected_nodes[ i ] = false;
  }
}

void PowerLaw_vlab::reset()
{
  _x_cdf = _xmax_cdf;
  g_curr_var_labeled = -1;
  g_constraint_store->reset();

  // restore var states
  std::map<int,Variable*>::iterator it = g_var_set.begin();
  for( ; it != g_var_set.end(); ++it )
    {
      Utilities::restore_var_state( g_var_set[ it->first ] );
    }
  // ~swap closed node list with open node list  
  while( !_closed_nodes.empty() )
    {
      _open_nodes.push( _closed_nodes.front() );
      _closed_nodes.pop();
    }
}

// Assigns all the singleton variables and propagate the 
// constraints involving them.
void PowerLaw_vlab::initialize()
{
  cout << "  Initialize\n";
  g_curr_var_labeled = -1;

  int count = 0;
  std::map<int,Variable*>::iterator it = g_var_set.begin();
  for( ; it != g_var_set.end(); ++it )
    {
      Variable *v = it->second;
      //_remaining_vars.push( v->id() );
      // v->reset_label();
      Utilities::save_var_state( v );
    }

  // popolate nodes queue
  for( int i = 0; i < g_TFs.size(); i++ )
    _open_nodes.push( g_TFs[ i ] );
  for( int i = 0; i < g_TGs.size(); i++ )
    _open_nodes.push( g_TGs[ i ] );
}

void PowerLaw_vlab::search()
{
  cout << "Starting MC-PowerLaw SEARCH\n";
  PowerLaw_vlab::initialize();

  while ( _g_CP_SOLUTIONS_COUNTER < SearchEngine::_max_numof_solutions 
	  && _curr_trial++ < _mc_limit )
  {
    //cout << "  curr trial: " << _curr_trial << " / " << _mc_limit << endl;
    while( step() == IN_PROGRESS ) ; 
    // step();
    PowerLaw_vlab::reset();
  }
}

// Syntactic sugar for step()
double P_cdf( int x, double alpha )
{
  return pow( (double)x, -alpha); 
}//-


int PowerLaw_vlab::step()
{
  string dbg = "PowerLaw_vlab::depth_first_search() - ";
  
  if( _x_cdf == _xmin_cdf ) { process_solution(); return SUCCESS; }

  /*. chose the number of variables to be selected at this stage
   *  based on P( X = _x_cdf )  */
  uniform_real_distribution< double > uni_distr( 0.0, 1.0 );
  double rnd = uni_distr( generator );
  double p_cdf = P_cdf( _x_cdf, 1.5 );
  // HACK! select to be the nlg(n)-th value in the ordered list
  double THS = 0.5;

#ifdef DBG
  cout << dbg << "x_cdf: " << _x_cdf << " rnd number: " << rnd << " P cdf: " 
       << p_cdf << endl;
  cout << "open list size: " << _open_nodes.size() << " closed list size: "
       << _closed_nodes.size() << endl;
#endif
  if( rnd <= p_cdf)
  { 
    //. Select P_cdf(_x_cdf) % of NODES among those not yet -labelled-
    //// HACK: need a queue of nodes not yet selected.
    int n_arcs_to_activate = _x_cdf;
    int n_target_nodes = std::ceil(p_cdf * g_InfKB.nnodes) - _closed_nodes.size();
    
    // HACK!! put randomness in selection here!
#ifdef DBG
    cout << dbg << "Num of TARGET nodes: " << n_target_nodes 
	 << " N arcs to activate: " << n_arcs_to_activate << endl;
#endif
    while( n_target_nodes > 0 || _open_nodes.empty() )
      {
	int g = _open_nodes.front();
	_open_nodes.pop();
	_closed_nodes.push( g );
	
	std::vector<int> rnd_Nodes( g_InfKB.nnodes );
	std::iota( rnd_Nodes.begin(), rnd_Nodes.end(), 0 );
	std::random_shuffle( rnd_Nodes.begin(), rnd_Nodes.end() );
	for( int i = 0; i < g_InfKB.nnodes; i++ )
        {
	  int node = rnd_Nodes[ i ];
	  int vid = g_edge_var[ make_pair(g, node) ];
	  Variable* v = g_var_set[ vid ];
	  // cout << "activating v: " << v->id() << endl;
	  if( !v->is_assigned() ) 
	  {
	    if( v->dom.ub() >= THS && n_arcs_to_activate > 0) 
	    {
	      v->set_label( v->dom.ub_pos() );
#ifdef DBG
	      cout << "activated - remaining: " << n_arcs_to_activate << "\n";
#endif
	      n_arcs_to_activate--;
	    }
	    else {
	      v->set_label( v->dom.lb_pos() );
	    }
	  }
	  v->dom.set_singleton( v->label() );
	  g_constraint_store->add( v->id() );
	  g_curr_var_labeled = v->id();

	  if ( !g_constraint_store->ISOLVPAR( ) ) { 
	    cout << "Fail\n";
	    getchar();
	    g_stats.incr_MC_fails(); 
	    return FAILURE; 
	  }
	}
	n_target_nodes--;
      }
    // cout << "Propagate";
  }
#ifdef DBG
  getchar();
#endif
  _x_cdf--; 
  return IN_PROGRESS; 
}

void PowerLaw_vlab::process_solution() 
{
  _g_CP_SOLUTIONS_COUNTER++;  
  g_solutions.push_back( new Solution );
  //g_solutions.back()->dump();
}

void PowerLaw_vlab::dump_statistics (ostream &os) 
{
  if (SearchEngine::aborted())
    os << "Search aborted, timeout of numof solutions limit reached.";
  else 
    os << "Compleately explored the search space. ";
  os << "[Num. of Solutions Found: " 
     << _g_CP_SOLUTIONS_COUNTER << "]" << endl;
    //<< " Best Fscore " << max_fscore << endl;

  //    << g_statistics->get_solutions_found()
  //    << " | Seach time: "
  //    << g_statistics->get_total_timer (t_search)
  //    << " s.| Best Rmsd: " << g_statistics->get_rmsd (protein) << "A]\n";
}//-
