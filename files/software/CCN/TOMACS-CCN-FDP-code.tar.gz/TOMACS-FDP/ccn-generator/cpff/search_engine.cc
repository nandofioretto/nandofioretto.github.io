#include "search_engine.h"

SearchEngine::SearchEngine() 
  : _abort_search(false), _assigned_on_start(0) {
}//-

SearchEngine::~SearchEngine () {
}//-

void
SearchEngine::reset () {
  _abort_search = false;
}//-

void 
SearchEngine::abort () {
  _abort_search = true;
}//-

bool 
SearchEngine::aborted () const {
  return _abort_search; 
}//-

void
SearchEngine::dump_statistics (std::ostream &os) const {
}//-
