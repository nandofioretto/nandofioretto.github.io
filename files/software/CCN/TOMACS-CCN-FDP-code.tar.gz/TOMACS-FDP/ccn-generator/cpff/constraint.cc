#include "constraint.h"
#include "var_int.h"
// #include "trailstack.h"
#include "constraint_store.h"

using namespace std;

bool constraint_cmp ( const Constraint* ci, const Constraint* cj ) 
{
  return ( (int)ci->type() < (int)cj->type() || 
	   ((int)ci->type() == (int)cj->type() && ci->id() < cj->id())); 
}

bool _constr_exists( constr_type c_type, vector<int> vars )
{
  // check if constraint already exists -- inefficient linear scan
  for( int i=0; i<vars.size(); i++)
  {
    std::vector<Constraint*> vc = g_constr_of_var[ vars[i] ];
    for(int c=0; c<vc.size(); c++)
    {
      if( vc[ c ]->type() != c_type ) continue;
      if( vc[ c ]->scope_size() != vars.size() ) continue;
      for( int v=0; v<vars.size(); v++ )
	if( vc[ c ]->scope( v )->id() != vars[ v ] ) continue;
      return true;
    }
  }
  return false;
}

 bool _constr_exists( constr_type c_type, vector<int> vars, 
		     vector<int> i_as, vector<double> r_as )
{
  // check if constraint already exists -- inefficient linear scan
  for( int i=0; i<vars.size(); i++)
  {
    std::vector<Constraint*> vc = g_constr_of_var[ vars[i] ];
    for(int c=0; c<vc.size(); c++)
    {
      if( vc[ c ]->type() != c_type ) continue;
      if( vc[ c ]->scope_size() != vars.size() ) continue;
      for( int v=0; v<vars.size(); v++ )
	if( vc[ c ]->scope( v )->id() != vars[ v ] ) continue;
      if( vc[ c ]->int_coef_size() != i_as.size() ) continue;
      for( int j=0; j<i_as.size(); j++ )
	if( vc[ c ]->int_coef( j ) != i_as[ j ] ) continue;
      if( vc[ c ]->real_coef_size() != r_as.size() ) continue;
      for( int j=0; j<r_as.size(); j++ )
	if( vc[ c ]->real_coef( j ) != r_as[ j ] ) continue;

      return true;
    }
  }
  return false;
}

Constraint::Constraint ( constr_type c_type, vector<int> vars ) 
{
  // if( _constr_exists( c_type, vars ) ) return;

  static size_t _g_CP_CONSTR_COUNTER = 0;
  _id = _g_CP_CONSTR_COUNTER++;
  g_constr_set[ _id ] = this;
  _type = c_type;

  for (int i = 0; i < vars.size(); i++) 
  {
    _scope.push_back( vars[i] );
    g_constr_of_var[ vars[i] ].push_back( this );
  }

}

Constraint::Constraint ( constr_type c_type, vector<int> vars, 
			 vector<int> i_as, vector<double> r_as ) 
{
  // if( _constr_exists( c_type, vars, i_as, r_as ) ) return;
  static size_t _g_CP_CONSTR_COUNTER = 0;
  _id = _g_CP_CONSTR_COUNTER++;
  g_constr_set[ _id ] = this;
  _int_coeffs = i_as;
  _real_coeffs = r_as;
  _type = c_type;

  for (int i = 0; i < vars.size(); i++) 
  {
    _scope.push_back( vars[i] );
    g_constr_of_var[ vars[i] ].push_back( this );
  }
}

Constraint::~Constraint () { }

Constraint::Constraint ( const Constraint& other ) 
{
  _id     = other._id;
  _type   = other._type;
  _scope  = other._scope;
  _int_coeffs = other._int_coeffs; 
  _real_coeffs = other._real_coeffs; 
}

Constraint& Constraint::operator= ( const Constraint& other ) 
{
  if (this != &other) 
  {
    _id     = other._id;
    _type   = other._type;
    _scope  = other._scope;
    _int_coeffs = other._int_coeffs; 
    _real_coeffs = other._real_coeffs; 
  }
  return *this;  
}

bool Constraint::operator== ( const Constraint& other ) 
{
  return (_id == other._id);
}

bool 
Constraint::operator() ( Constraint& ci, Constraint& cj ) 
{
  return (ci.scope( 0 ) < cj.scope( 0 ));
}

size_t Constraint::id () const {
  return _id;
}

constr_type Constraint::type() const 
{
  return _type;
}

bool Constraint::is_binary() const 
{
  return (_scope.size() == 2);
}

size_t Constraint::scope_size() const 
{
  return _scope.size();
}

Variable*  Constraint::scope ( int idx ) 
{
  assert( idx < _scope.size());
  return g_var_set[ _scope[ idx ] ];
}

int Constraint::int_coef( int idx )
{
  return _int_coeffs[ idx ];
}

size_t Constraint::int_coef_size() const 
{
  return _int_coeffs.size();
}

double Constraint::real_coef( int idx )
{
  return _real_coeffs[ idx ];
}

size_t Constraint::real_coef_size() const 
{
  return _real_coeffs.size();
}

bool Constraint::is_fixpt() const
{
  return _is_fixpt;
}

void Constraint::set_fixpt()
{
  _is_fixpt = true;
}

void Constraint::unset_fixpt()
{
  _is_fixpt = false;
}


void Constraint::dump() 
{
  cout << "C_" << _id << " Type " << _type << " " << endl;
  cout << "Scope: ";
  for (int i = 0; i < _scope.size(); i++)
    cout << "v_" << _scope[ i ] << " ";
  cout << endl;
  if (_int_coeffs.size() > 0) 
  {
    cout << "INT_coefs: ";
    for (int i = 0; i < _int_coeffs.size(); i++) {
      cout << _int_coeffs[i] << " ";
    }
    cout << endl;
  }
  if (_real_coeffs.size() > 0) 
  {
    cout << "REAL_coefs: ";
    for (int i = 0; i < _real_coeffs.size(); i++) {
      cout << _real_coeffs[i] << " ";
    }
    cout << endl;
  }
}
