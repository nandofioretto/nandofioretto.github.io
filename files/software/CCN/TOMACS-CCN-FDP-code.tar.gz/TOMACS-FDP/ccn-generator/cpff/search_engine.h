/*********************************************************************
 * Search Engine Object
 * Abstract search engine class.
 *********************************************************************/
#ifndef SEARCH_ENGINE_H
#define SEARCH_ENGINE_H

#include "cpff_globals.h"

class Variable;

#define SUCCESS 1
#define IN_PROGRESS 0
#define FAILURE -1

class SearchEngine {
 private:
  bool _abort_search;
 
 protected:
  size_t _max_numof_solutions;
  size_t _g_CP_SOLUTIONS_COUNTER;
  
  std::stack<int> _assigned_vars;
  std::stack<int> _remaining_vars;
  size_t _assigned_on_start;

  SearchEngine();
  virtual ~SearchEngine ();
  
  virtual void search () = 0;
  virtual void reset ();
  
  void dump_statistics (std::ostream &os = std::cout) const;

  void abort ();
  bool aborted () const;
};

#endif
