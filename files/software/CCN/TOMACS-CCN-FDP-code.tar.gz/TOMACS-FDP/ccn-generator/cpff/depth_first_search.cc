#include "depth_first_search.h"
#include "variable.h"
#include "var_int.h"
#include "constraint.h"

#include "constraint_store.h"
#include "trailstack.h"

using namespace std;

//#define SEARCH_DBG
//#define VERBOSE

DepthFirstSearchEngine::DepthFirstSearchEngine() :
 _curr_level( 0 ) {
   _height = g_cp_variables.size();
   _g_CP_SOLUTIONS_COUNTER = 0;
}//-


void
DepthFirstSearchEngine::reset() {
  _curr_level = 0;
}//-


DepthFirstSearchEngine::~DepthFirstSearchEngine () {
}//-


Variable* 
DepthFirstSearchEngine::variable_selection() {
  return g_cp_variables[_curr_level];
}//variable_selection

/* 
 * Check if every element of the domain for current variable
 * has been explored
 */
bool
DepthFirstSearchEngine::labeling ( Variable *v ) { 
  string dbg = "DepthFirstSearchEngine::labeling() - ";
  
#ifdef SEARCH_DBG
  cout << dbg << "Labeling V_" << v->get_id() << endl;
#endif
  
  if (((var_int*)v)->is_already_assigned()) {
    if ( v->labeling() ) {
      g_trailstack->trail_variable ( v );
      //v->set_bounds( v->get_label(), v->get_label());
      return true;
    }
    return false;
  }
  
  if ( v->labeling() ) {
    g_trailstack->trail_variable ( v );
    //v->set_bounds( v->get_label(), v->get_label());
    return true;
  }
  
#ifdef SEARCH_DBG
  cout << " Cannot label - ret FALSE\n";
#endif
  
  return false;
}//labeling

void 
DepthFirstSearchEngine::goto_next_level () {
  _curr_level ++;
}//-

void 
DepthFirstSearchEngine::goto_prev_level () {
  _curr_level --;
}//-


void
DepthFirstSearchEngine::search () {
  string dbg = "DepthFirstSearchEngine::depth_first_search() - ";

  if(_curr_level == 0) std::cout << dbg << "CPFF Depth First Search Engine started\n";
  if(_curr_level >= _height) {
    process_solution();
    return;
  }
  
  size_t continuation = g_trailstack->size();
  var_int *v = (var_int*)variable_selection ();
  
  int v_idx = v->get_id();
  g_constraint_store->curr_labeled_var = v_idx;
  
  while( labeling ( v ) ) 
  {
    
#ifdef SEARCH_DBG
    std::cout << dbg << " lev: " << _curr_level << std::endl;
    for (int i = 0; i < g_cp_variables.size(); i++)
      g_cp_variables[ i ]->dump();
    getchar();
#endif

    g_constraint_store->set_singlet_event( v_idx, v->get_label() );
    
    if ( v->is_already_assigned() ) {
      goto_next_level ();
      search ();
      goto_prev_level ();
    }
    else if ( g_constraint_store->ISOLVPAR( v ) ) {
      goto_next_level ();
      search ();
      goto_prev_level ();
    }
    
    if ( SearchEngine::aborted() ) return;
    
    // Backtrack all modifications (except for the variable choice)
    g_trailstack->backtrack ( continuation );
    g_constraint_store->curr_labeled_var = v_idx;
    g_constraint_store->backtrack_action = _curr_level;
    
#ifdef SEARCH_DBG
      std::cout << dbg << "Backtrack!\n";
#endif
    
  }//-end-labeling-step
  
  // Restore previous Domain values (after all tries)
  v->reset_label ();
  v->domain.unset ();
  v->reset_bounds ();
  g_constraint_store->curr_labeled_var = v_idx;
  
  return;
}//-

void
DepthFirstSearchEngine::process_solution() {
  string dbg = "DepthFirstSearchEngine::process_leaf() - ";
  _g_CP_SOLUTIONS_COUNTER++;
  
  cout << /* dbg << */ "Solution: ";
  var_int* var_selected = NULL;
  for (int i = 0; i < _height; i++) {
    var_selected = (var_int*) g_cp_variables[i];
    var_selected->print_value();
    cout << " ";
  }
  cout << endl;
  
  if ( _g_CP_SOLUTIONS_COUNTER == gh_params.max_num_of_solutions ) {
    SearchEngine::abort();
  }
}//process_solution


void
DepthFirstSearchEngine::dump_statistics (std::ostream &os) {
  if (SearchEngine::aborted())
    os << "Search aborted, timeout of numof solutions limit reached.";
  else 
    os << "Compleately explored the search space. ";

  os << "[Num. of Solutions Found: " 
     << _g_CP_SOLUTIONS_COUNTER << "]" << endl;
}//-
