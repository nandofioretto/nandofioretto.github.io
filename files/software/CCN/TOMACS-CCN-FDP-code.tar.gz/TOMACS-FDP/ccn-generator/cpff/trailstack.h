/*********************************************************************
 * Trail Stack implementation
 *********************************************************************/
#ifndef CP_TRAILSTACK_
#define CP_TRAILSTACK_

#include "cpff_globals.h"
#include "cpff_globals.h"

class TrailVariable;
class Variable;

struct TrailVariable {
  TrailVariable (Variable* v, size_t _continuation);
  
  TrailVariable (const TrailVariable& other);
  TrailVariable& operator= (const TrailVariable& other);
  ~TrailVariable();
  
  size_t continuation;
  Variable* link_to_var;
  
  unsigned int dom_state[MAX_DIM];
  int lower_bound;
  int upper_bound;
};

class TrailStack {
 private:
  std::stack < TrailVariable > trailstack;

 public:
  TrailStack() { };
  ~TrailStack() { };
  
  void backtrack (size_t continuation);
  bool is_empty() const;
  size_t size() const;
  void reset ();
  
  void trail_variable (Variable* v);
  void trail_constraint_fixpoint( int c_id );
};

#endif
