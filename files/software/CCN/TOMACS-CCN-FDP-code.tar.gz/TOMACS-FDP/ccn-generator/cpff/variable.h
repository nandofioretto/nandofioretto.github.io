#ifndef CP_VARIABLE_H
#define CP_VARIABLE_H

#include "cpff_globals.h"
#include "domain.h"

/* class TrailVariable; */

class Variable 
{
 private:
  size_t _id;
  int _label;
  bool _assigned;

 public:
  Domain dom;

  Variable ();
  Variable( std::vector<double> d_vals);
  Variable (const Variable& other);
  Variable& operator= (const Variable& other);
  bool operator== (const Variable& other);  // used by search functions

  size_t id () const;
  void assign ();
  void unassign ();
  bool is_assigned () const;
  void set_label (int l);
  void set_label_ith_active( int ith );
  int  label () const;
  void reset_label ();
  double value() const;

  bool labeling (); // used?
  
  /* void trail_back ( TrailVariable& tv ); */
  void dump ();
};

#endif
