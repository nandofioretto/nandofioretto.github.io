#include "var_bool.h"
#include "trailstack.h"

using namespace std;

var_bool::var_bool () {
  vector<int> dom;
  dom.push_back(0);
  dom.push_back(1);
  domain = dom;
  domain_offset = 0;
  domain.v_ptr = this;
  already_assigned = false;
  size_t _size = domain.size();
  labelings = new bool[_size];
  memset (labelings, true, _size*sizeof(bool));
  min_label = 0;
  max_label = domain.size()-1;
  lower_bound = domain[min_label];
  upper_bound = domain[max_label];
}//-

var_bool::var_bool (Domain< int > dom) {
  domain = dom;
  domain_offset = 0;
  domain.v_ptr = this;
  already_assigned = false;
  size_t _size = domain.size();
  labelings = new bool[_size];
  memset (labelings, true, _size*sizeof(bool));
  min_label = 0;
  max_label = domain.size()-1;
  lower_bound = domain[min_label];
  upper_bound = domain[max_label];
}//-

var_bool::var_bool (int new_id) {
  id = new_id;
  vector<int> dom;
  dom.push_back(0);
  dom.push_back(1);
  domain = dom;
  domain_offset = 0;
  domain.v_ptr = this;
  already_assigned = false;
  size_t _size = domain.size();
  labelings = new bool[_size];
  memset (labelings, true, _size*sizeof(bool));
  min_label = 0;
  max_label = domain.size()-1;
  lower_bound = domain[min_label];
  upper_bound = domain[max_label];
}//-

var_bool::var_bool (int new_id, Domain< int > dom) {
  id = new_id;
  domain = dom;
  domain_offset = 0;
  domain.v_ptr = this;
  already_assigned = false;
  size_t _size = domain.size();
  labelings = new bool[_size];
  memset (labelings, true, _size*sizeof(bool));
  min_label = 0;
  max_label = domain.size()-1;
  lower_bound = domain[min_label];
  upper_bound = domain[max_label];
}//-

var_bool::var_bool (const var_bool& other) {
  domain_offset = other.domain_offset;
  domain = other.domain;
  size_t _size = domain.size();
  labelings = new bool[_size];
  already_assigned = false;
  memcpy (labelings, other.labelings, _size*sizeof(bool));
  domain.v_ptr = this;
  min_label = other.min_label;
  max_label = other.max_label;
  lower_bound = other.lower_bound;
  upper_bound = other.upper_bound;
}//-

var_bool::~var_bool (){
}//-

var_bool& 
var_bool::operator= (const var_bool& other) {
  if (this != &other) {
    id       = other.id;
    label    = other.label;
    assigned = other.assigned;
    changed  = other.changed;
    constraint_dependencies  = 
      other.constraint_dependencies;
    domain = other.domain;
    min_label = other.min_label;
    max_label = other.max_label;
    lower_bound = other.lower_bound;
    upper_bound = other.upper_bound;
  }
  return *this;
}//-

/* Bounds management */
int
var_bool::get_min_label() {
  return min_label;
}//get_min_label

int
var_bool::get_max_label() {
  return max_label;
}//get_max_label

int
var_bool::get_lower_bound() {
  return lower_bound;
}//get_lower_bound

int
var_bool::get_upper_bound() {
  return upper_bound;
}//get_upper_bound


void
var_bool::set_min_label(int l) {
  min_label = l;
  lower_bound = domain[min_label];
}//get_min_label

void
var_bool::set_max_label(int l) {
  max_label = l;
  upper_bound = domain[max_label];
}//get_max_label

void
var_bool::set_lower_bound(int v) {
  lower_bound = v;
}//get_lower_bound

void
var_bool::set_upper_bound(int v) {
  upper_bound = v;
}//get_upper_bound

/* The FD Variable is failed if its domain has no more choices.
 * Efficiency note: since the domain is changed either by labeling
 * or by propagation, this check could be done there directly -->
 * using a failed flag.
 */
bool 
var_bool::is_failed() {
  if (!domain.is_empty())
    return false;

  int d_last = domain.size()-1;
  if (!domain.is_valid (d_last) && get_label() != d_last)
    return true;
  else
    return false;
}//-

bool
var_bool::is_already_assigned() {
  return already_assigned;
}

void
var_bool::set_already_assigned() {
  already_assigned = true;
}

void 
var_bool::set_singleton (size_t idx) {
  domain.unset();
  domain.set(idx);
}//-

bool
var_bool::is_singleton () {
  int n_active = 0;
  for (int i=0; i<domain.size(); i++)
    n_active += domain.is_valid(i);
  return (n_active == 1);
}//-

void 
var_bool::reset () {
  label  = -1;
  assigned = false;
  changed  = false;
  domain.set();
}//-


int
var_bool::get_dom_offset() {
  return domain_offset;
}//get_dom_offset


void
var_bool::set_unique_singleton() {
  set_already_assigned();
}//set_unique_singleton

bool 
var_bool::labeling () {
  string dbg = "CPVariable<DomElement>::labeling() - ";
  if (label == -1) label = 0;
  if (label < min_label) label = min_label;
  
//  while ( (label <= max_label) &&
//          (!domain.is_valid(++label)) ) {
//    ;
//  }
  
  while ((label <= max_label) &&
         (!domain.is_valid(label))) {
    label++;
  }
  
  if ((label >= domain.size()) || (label > max_label))
    return false;

  domain.set ((size_t)label, false); // set current domain as choosen
  return true; 
}//-

void 
var_bool::skip_label (size_t l) {
  domain.set (l, false);
}//-

int 
var_bool::get_next_label () {
  int next = label;
        
  while (next <= domain.size()-1
	 && !domain.is_valid(++next) ) {
    ;
  }
  if (next >= domain.size()) 
    return -1;

  return next;
}//-

bool
var_bool::is_bottom_label () {
  return domain.is_bottom (label);
}//-

size_t 
var_bool::get_dom_size() {
  return domain.size();
}//-

bool* 
var_bool::get_dom_state() {
  return domain.get_state();
}//-

void 
var_bool::set_dom_state(bool* other_state) {
  domain.set_state (other_state);
}//-

bool*
var_bool::get_labels_state() {
  return labelings;
}//-

void
var_bool::set_labels_state(bool* states) {
  memcpy (labelings, states, domain.size()*sizeof(bool));
}//-

void
var_bool::trail_back (TrailVariable& tv) {
  already_assigned = false;
  min_label = tv.min_label;
  max_label = tv.max_label;
  lower_bound = domain[min_label];
  upper_bound = domain[max_label];
  domain.set_state (tv.dom_state);
}//-

void
var_bool::print_value() {
  if (domain[0]) cout << "T";
  else cout << "F";
}//print_value

void 
var_bool::dump () {
  cout << "var_bool_" << id << " ";
  cout << "Label: " << label << "\t";
  if (is_assigned()) cout << " ASSIGNED ";
  if (is_failed()) cout << " FAILED ";
  if (is_changed()) cout << " CHANGED ";
  cout << "Dom: {F, T}" << endl;
}//-
