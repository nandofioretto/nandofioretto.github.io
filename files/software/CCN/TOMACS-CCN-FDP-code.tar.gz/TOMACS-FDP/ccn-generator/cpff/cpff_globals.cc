#include "cpff_globals.h"

using namespace std;

ConstraintStore* g_constraint_store;
// TrailStack*      g_trailstack;
//-------Dec13-----------//
std::map< int, std::vector< Constraint* > > g_constr_of_var; // <vid, **con>
std::map< int, Constraint* > g_constr_set; // < id, *con >
std::map< int, Variable* > g_var_set;	  // < id, *var>
std::map< int, var_state > g_var_states;


//------Dec9------//
int g_curr_var_labeled;
