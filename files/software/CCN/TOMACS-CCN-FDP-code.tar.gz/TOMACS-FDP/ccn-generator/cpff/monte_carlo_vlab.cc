#include "monte_carlo_vlab.h"
#include "variable.h"
#include "constraint.h"
#include "constraint_store.h"
#include "main_utils.h"
// #include "trailstack.h"

// Borrowed from CRNIff
#include "solution.h"
#include "statistics.h"

using namespace std;

//#define DBG
//#define VERBOSE

MonteCarlo_vlab::MonteCarlo_vlab( int argc, char* argv[] )
  : _curr_level( 0 ), _mc_limit( 0 ), _curr_trial( 0 )
{
  for (int narg=0; narg < argc; narg++)
  {
    if (!strcmp ("--max-numof-solutions",argv[narg])) {
      SearchEngine::_max_numof_solutions = atoi(argv[narg + 1]);
    }
    if (!strcmp ("--mc-limit", argv[ narg ])) {
      _mc_limit = atoi( argv[ narg + 1 ] );
      g_stats.set_nMC_trials( _mc_limit );
    }
  }
  
  _g_CP_SOLUTIONS_COUNTER = 0;
  _height = g_var_set.size();
  _seed = 0;//chrono::system_clock::now().time_since_epoch().count();
  _generator.seed( _seed );
}

MonteCarlo_vlab::~MonteCarlo_vlab () { }

// inefficient now -- later: create a vector of vars and 
// only move index to select next var -- then reset by setting
// back the index...
// Hack! check if to set bounds!
void MonteCarlo_vlab::reset()
{
  _curr_level = 0;
  g_curr_var_labeled = -1;

  g_constraint_store->reset();
  while( _assigned_vars.size() > _assigned_on_start ) {
    _remaining_vars.push( _assigned_vars.top() );
    Utilities::restore_var_state( g_var_set[ _assigned_vars.top() ] );
    _assigned_vars.pop();
  }

}

Variable* MonteCarlo_vlab::variable_selection()
{ 
  Variable* v = g_var_set[ _remaining_vars.top() ];
  _assigned_vars.push( _remaining_vars.top() );
  _remaining_vars.pop();
  return( v );
}

// Hack! check singlet event to set!
// note that here we choose to select from 1 to size, and not 
// from 0 to size-1 as we are going to select an ordinal 
// number 
bool MonteCarlo_vlab::labeling (Variable *v) 
{
  int size = v->dom.n_active();  /* random select among active elements: */
  if ( size == 0 ) { return false; }
  
  uniform_int_distribution<int> uni_distr( 1, size );
  int i_th =  uni_distr( _generator );
  v->set_label_ith_active( i_th ); 
  v->dom.set_singleton( v->label() );
  g_constraint_store->add( v->id() );
  g_curr_var_labeled = v->id();

  return true;
}


// Assigns all the singleton variables and propagate the 
// constraints involving them.
void MonteCarlo_vlab::initialize()
{
#ifdef VERBOSE
  cout << "  Initialize\n";
#endif
  g_curr_var_labeled = -1;

  std::map<int,Variable*>::iterator it = g_var_set.begin();  
  for( ; it != g_var_set.end(); ++it )
  {
    Variable *v = it->second;
    if( v->is_assigned() )
    {
      _assigned_vars.push( v->id() );
      v->dom.set_singleton( v->label() );
      g_constraint_store->add( v->id() );
    }
    else 
    {
      _remaining_vars.push( v->id() );
      v->reset_label();
      Utilities::save_var_state( v );
    }
  }
  _assigned_on_start = _assigned_vars.size();

  if( _assigned_vars.size() > 0 )  // if there is any assigned variable already
  {
#ifdef VERBOSE
    cout << "  N. variables already assigned: " << _assigned_vars.size() << endl;
#endif
    if ( !g_constraint_store->ISOLVPAR( ) ) // propagate over all constraints
    {
      cout << "  Error: The CSP is not satisfiable\n";
      exit(-1);
    }
  }
}

void MonteCarlo_vlab::search()
{
#ifdef VERBOSE
  cout << "Starting MONTE CARLO SEARCH\n";
#endif
  initialize();

  while ( _g_CP_SOLUTIONS_COUNTER < SearchEngine::_max_numof_solutions 
	  && _curr_trial++ < _mc_limit )
  {
    //cout << "  curr trial: " << _curr_trial << " / " << _mc_limit << endl;
    while( step() == IN_PROGRESS ) ; 
    //getchar();
    MonteCarlo_vlab::reset();
  }
}


int MonteCarlo_vlab::step ()
{
  if(  _remaining_vars.empty() ) { process_solution(); return SUCCESS; }
  Variable *v = variable_selection ();

  if ( labeling( v ) )
  {
    if ( g_constraint_store->ISOLVPAR( ) ) return IN_PROGRESS;
    else{ g_stats.incr_MC_fails(); return FAILURE; }
  }
  return FAILURE;
}

void MonteCarlo_vlab::process_solution() 
{
  _g_CP_SOLUTIONS_COUNTER++;  
  g_solutions.push_back( new Solution );
}


void MonteCarlo_vlab::dump_statistics (ostream &os) {
  if (SearchEngine::aborted())
    os << "Search aborted, timeout of numof solutions limit reached.";
  else 
    os << "Compleately explored the search space. ";
  os << "[Num. of Solutions Found: " 
     << _g_CP_SOLUTIONS_COUNTER << "]" << endl;
  //<< " Best Fscore " << max_fscore << endl;

  //    << g_statistics->get_solutions_found()
  //    << " | Seach time: "
  //    << g_statistics->get_total_timer (t_search)
  //    << " s.| Best Rmsd: " << g_statistics->get_rmsd (protein) << "A]\n";
}//-
