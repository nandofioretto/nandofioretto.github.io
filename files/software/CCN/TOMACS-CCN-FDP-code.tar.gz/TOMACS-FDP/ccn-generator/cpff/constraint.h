/*********************************************************************
 * Constraint
 * Constraint base class implementation.
 *********************************************************************/
#ifndef CP_CONSTRAINT_
#define CP_CONSTRAINT_

#include "cpff_globals.h"
#include "variable.h"

class Variable;

enum constr_type {
  ATLEAST_K_GE, ATMOST_K_GE, ATMOST_K_GE_FAST, RED_EDGE, DIR_SEL, ONE_DIR, COTF, NET_MODULE, 
  numof_constr 
};

class Constraint 
{
 protected:
  size_t _id;
  constr_type _type;
  
  std::vector <int> _scope;
  std::vector <int> _int_coeffs;
  std::vector <double> _real_coeffs;
    
  bool _is_fixpt;

public:
  Constraint();
  Constraint (constr_type c_type, std::vector<int> vars);
  Constraint ( constr_type c_type, std::vector<int> vars, 
	       std::vector<int> i_as, std::vector<double> r_as );
  
  virtual ~Constraint();
  Constraint (const Constraint& other);
  Constraint& operator= (const Constraint& other);
  
  bool operator== (const Constraint& other);  // used by search functions
  bool operator() (Constraint& ci, Constraint& cj);

  size_t id() const;
  bool is_binary() const;
  constr_type type() const;
  int num_of_events() const;
  int event( int i );
  size_t scope_size () const;
  Variable* scope (int idx);
 
  int int_coef( int idx );
  size_t int_coef_size() const;
  double real_coef( int idx );
  size_t real_coef_size() const;

  bool is_fixpt() const;
  void set_fixpt();
  void unset_fixpt();

  std::vector<int>::iterator
    int_coef_begin() {return _int_coeffs.begin(); }
  std::vector<int>::iterator
    int_coef_end() {return _int_coeffs.end(); }

  void dump ();
};//-

#endif
