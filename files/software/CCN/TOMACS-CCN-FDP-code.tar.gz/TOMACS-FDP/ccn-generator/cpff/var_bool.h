/*********************************************************************
 * var_bool 
 *********************************************************************/
#ifndef CP_VAR_BOOL_H
#define CP_VAR_BOOL_H

#include "cpff_globals.h"
#include "variable.h"
#include "domain.h"

class TrailVariable;

class var_bool : public Variable {
private:
  bool already_assigned;
  
 public:
  Domain <int> domain;

  var_bool ();
  var_bool (Domain<int> dom);
  var_bool (int new_id);
  var_bool (int new_id, Domain<int> dom);
  var_bool (const var_bool& other);
  var_bool& operator= (const var_bool& other);
  ~var_bool ();

  int get_next_label ();
  bool is_bottom_label ();

  bool is_already_assigned();
  void set_already_assigned();
  int get_offset();

  void print_value();
  
  virtual bool is_failed();
  virtual void set_unique_singleton();
  virtual void set_singleton (size_t idx);
  virtual bool is_singleton();
  virtual void reset ();
  virtual bool labeling ();
  virtual void skip_label (size_t l);
  
  /* Bounds management */
  virtual int get_min_label();
  virtual int get_max_label();
  virtual int get_lower_bound();
  virtual int get_upper_bound();
  
  virtual void set_min_label(int l);
  virtual void set_max_label(int l);
  virtual void set_lower_bound(int v);
  virtual void set_upper_bound(int v);
  
  virtual size_t get_dom_size();
  virtual int get_dom_offset();
  virtual bool* get_dom_state();
  virtual void  set_dom_state(bool* other_state);
  virtual bool* get_labels_state();
  virtual void set_labels_state(bool* states);
  virtual void trail_back (TrailVariable& tv);

  virtual void dump ();  
};//-

#endif
