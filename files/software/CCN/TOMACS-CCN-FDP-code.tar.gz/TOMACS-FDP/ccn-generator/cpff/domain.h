#ifndef CP_DOMAIN_H
#define CP_DOMAIN_H

#include "cpff_globals.h"

class Variable;

class Domain 
{ 
 private:
  std::vector< double > _values;
  std::vector< bool > _state;
  short _size;
  short _min; // min active state
  short _max; // max active state
  short _nactive; // num of active elements
  int _event; // 
  Variable* _var_ptr;
  
 public:
  
  Domain ();
  Domain ( std::vector<double> elements );
  Domain ( const Domain& other );
  Domain& operator= ( const Domain& other );
  ~Domain ();

  // Domain Operations
  double operator [] ( int pos ) const;
  void set_vptr( Variable* v );
  Variable* var_ptr();
  void add( double elem );

  std::vector<bool> state ();
  void set_state ( std::vector<bool> other_state );
  void copy_state( std::vector<bool> other_state ); // quick, no checks, no updates
  void set_singleton ( int pos );
  void set ();
  void set ( int pos );
  void unset ();
  void unset ( int pos );
  void set_lb( int pos );
  void set_ub( int pos );

  bool is_valid () const;
  bool is_failed () const;
  bool is_valid ( int pos ) const;
  bool is_singleton( ) const;

  double min() const; // min val in domain 
  double max() const; // max val in domain
  double lb() const;  // min active val in domain
  double ub() const;  // max active val in domain
  int lb_pos() const; // index of lb
  int ub_pos() const; // index of ub
  void copy_bounds( short l, short u );  // used to restore var state
  int n_active() const;
  void copy_n_active( short n ); // used to restore var state
  
  void set_event( int event );
  int  event() const;
  
  int size();
  void dump ();
};

#endif
