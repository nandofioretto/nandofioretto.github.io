#ifndef CPFF_HEADERS_H
#define CPFF_HEADERS_H

#include "cpff_globals.h"

// CP Core headers
#include "constraint_store.h"
/* #include "trailstack.h" */
/* #include "depth_first_search.h" */
#include "monte_carlo_vlab.h"
#include "tfs_first_search.h"
#include "power_law_vlab.h"
#include "main_utils.h"

// CP Variables
#include "domain.h"
#include "variable.h"
#include "var_int.h"

// CP Constraints 
#include "constraint.h"

#endif
