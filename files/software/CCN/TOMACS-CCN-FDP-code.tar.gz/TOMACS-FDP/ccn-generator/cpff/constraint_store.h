#ifndef CP_CONSTRAINT_STORE_
#define CP_CONSTRAINT_STORE_

#include "cpff_globals.h"
#include "var_int.h"

class Variable;
class Constraint;

typedef struct
{
  int* store;
  bool* in_store;
  int size;
  int capacity;
} queue;

class ConstraintStore 
{
 private:
  queue _con_queue; // constraint queue
  queue _var_queue; // var changed by constr propagation
  
public:
  ConstraintStore();
  ~ConstraintStore();

  void add( int vid );
  void flush();
  void reset();
  bool ISOLVPAR ();
};//-

#endif
