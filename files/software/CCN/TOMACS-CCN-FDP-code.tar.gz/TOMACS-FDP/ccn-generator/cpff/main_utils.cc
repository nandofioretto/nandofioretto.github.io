#include "main_utils.h"
#include "variable.h"
//#define UTILS_DBG

using namespace Utilities;
using namespace std;

void Utilities::save_vars_state()
{
  std::map<int, Variable*>::iterator it;
  for (it = g_var_set.begin(); it != g_var_set.end(); ++it) 
  {
    Variable* var = it->second;
    var_state s;
    s.label = var->label();
    s.assigned = var->is_assigned();
    s.states = var->dom.state();
    s.lb = var->dom.lb_pos();
    s.ub = var->dom.ub_pos();
    s.nactive = var->dom.n_active();
    s.event   = var->dom.event();
    g_var_states[ var->id() ] = s;
  }
}

void Utilities::save_var_state( Variable* var )
{
  var_state s;
  s.label = var->label();
  s.assigned = var->is_assigned();
  s.states = var->dom.state();
  s.lb = var->dom.lb_pos();
  s.ub = var->dom.ub_pos();
  s.nactive = var->dom.n_active();
  s.event   = var->dom.event();
  g_var_states[ var->id() ] = s;
}


void Utilities::restore_vars_state()
{
  std::map<int, Variable*>::iterator it;
  for (it = g_var_set.begin(); it != g_var_set.end(); ++it) 
    {
      Variable* var = it->second;
      var_state* s = &g_var_states[ var->id() ];
      var->set_label( s->label);
      if( s->assigned ) var->assign();
      else var->unassign();
      var->dom.copy_state( s->states );
      var->dom.copy_bounds( s->lb, s->ub );
      var->dom.copy_n_active( s->nactive );
      var->dom.set_event( s->event );
    }
}


void Utilities::restore_var_state( Variable* var)
{
  var_state* s = &g_var_states[ var->id() ];
  var->set_label( s->label);
  if( s->assigned ) var->assign();
  else var->unassign();
  var->dom.copy_state( s->states );
  var->dom.copy_bounds( s->lb, s->ub );
  var->dom.copy_n_active( s->nactive );
  var->dom.set_event( s->event );
}

void Utilities::dump_vars()
{
  std::map<int, Variable*>::iterator it;
  for (it = g_var_set.begin(); it != g_var_set.end(); ++it) 
  {
    it->second->dump();
  }
}
