#include "benchmark.h"

#include<cstdlib>
#include<ctime>
#include<vector>

using namespace std;

//parser
constr_type Benchmark::string2constr (string constrType, int l)
{
  //if (constrType=="array_bool_and"){ return array_bool_and;}
  if (constrType=="int_lin_ne"){ return int_lin_ne;}
  /*else if (constrType=="array_bool_element"){ return array_bool_element;}
  else if (constrType=="array_bool_or"){ return array_bool_or;}*/
  /*else if (constrType=="array_bool_xor"){ return array_bool_xor;}
   else if (constrType=="array_int_element"){ return array_int_element;}
   else if (constrType=="array_var_bool_element"){ return array_var_bool_element;}
   else if (constrType=="array_var_int_element"){ return array_var_int_element;}
   else if (constrType=="bool2int"){ return bool2int;}
   else if (constrType=="bool_and"){ return bool_and;}
   else if (constrType=="bool_clause"){ return bool_clause;}
   else if (constrType=="bool_eq"){ return bool_eq;}
   else if (constrType=="bool_eq_reif"){ return bool_eq_reif;}
   else if (constrType=="bool_le"){ return bool_le;}
   else if (constrType=="bool_le_reif"){ return bool_le_reif;}
   else if (constrType=="bool_lt"){ return bool_lt;}
   else if (constrType=="bool_lt_reif"){ return bool_lt_reif;}
   else if (constrType=="bool_not"){ return bool_not;}
   else if (constrType=="bool_or"){ return bool_or;}
   else if (constrType=="bool_xor"){ return bool_xor;}*/
  /*else if (constrType=="int_abs"){ return int_abs;}
   else if (constrType=="int_div"){ return int_div;}*/
  /*else if (constrType=="int_eq"){ return int_eq;}
  else if (constrType=="int_eq_reif"){ return int_eq_reif;}
  else if (constrType=="int_le"){ return int_le;}
  else if (constrType=="int_le_reif"){ return int_le_reif;}
  else if (constrType=="int_lin_eq"){ return int_lin_eq;}
  else if (constrType=="int_lin_eq_reif"){ return int_lin_eq_reif;} */
  else if (constrType=="int_lin_le"){ return int_lin_le;}
  /*else if (constrType=="int_lin_le_reif"){ return int_lin_le_reif;}
  else if (constrType=="int_lin_ne"){ return int_lin_ne;}*/
  //else if (constrType=="int_lin_ne_reif"){ return int_lin_ne_reif;}
  //else if (constrType=="int_lt"){ return int_lt;}
  /*else if (constrType=="int_lt_reif"){ return int_lt_reif;}
   else if (constrType=="int_max"){ return int_max;}
   else if (constrType=="int_min"){ return int_min;}
   else if (constrType=="int_mod"){ return int_mod;}*/
  else if (constrType=="int_ne"){ return int_ne;}
  //else if (constrType=="int_ne_reif"){ return int_ne_reif;}
  /*else if (constrType=="int_plus"){ return int_plus;}
   else if (constrType=="int_times"){ return int_times;}*/
  
  else {//Error, constraint not recognised
    cout << "Parse Error in constraint declaration at line " << l << ": undeclared constraint identifier \"" << constrType <<"\"" << endl;
    
    //vars.clear();
    //coeff.clear();
    //vars_list.clear();
    //domain.clear();
    //support_vars.clear();
    //free(str);
    //outfile.close();
    
    exit(1);
  }
}

void Benchmark::parseInput(string filename) {
  ifstream is(filename.c_str());
  //string outname;
  //create output file name
  //outname=filename.substr(0, filename.size()-3) + "cu";
  
  bool flag=false;
  
  vector<int> vars;
  vector<int> coeff;
  
  //per tokenizzazione con strtok
  char * str;
  char * pch;
  //
  //per associare le variabli al relativo id
  int globalID=0;
  vector< pair<string,int> > vars_list;
  //
  //per ciclare con vars_list
  bool found, endArray;
  int k;
  //
  //per accumulare variabili di supporto da dichiarare in coda
  vector< pair<string,int> > support_vars;
  //
  string buf;
  int line=0;
  bool firstVar = true;
  bool firstConstr = true;
  //ofstream outfile;
  size_t p0 = 0, p1 = 0, pv0=0, pv1=0;
  stringstream conv; //for string_to_int conversion
  string varValue, varId;
  string arrDim, arrValue, arrId;
  string constrType, constrExpr, outExpr;
  //outfile.open (outname.c_str());
  
  int domainDim=0;
  
  
  vector<int> domain; //!!!
  //outfile << "vector<int> domain;\n";
  
  while (is.good()) {
    //parse file and fill data structure;
    std::getline (is, buf);
    line=line+1;
    p0=0;
    p1=0;
    pv0=0;
    pv1=0;
    //do {
    p0=buf.find_first_not_of(" ", p0); //skip whitespaces
    
    if (p0==string::npos){ ; }//no characters in this line/part of line
    
    else if (buf.substr(p0, 1)=="%") { //comment line/part of line
      //outfile << "//" + buf.substr(p0+1) + "\n";
      p0=string::npos;
    }
    
    
    else if (buf.substr(p0, 4)=="var ") { //VAR DECLARATION in this line/part of line -> (var int_const..int_const) or (var bool)
      p0=buf.find_first_not_of(" ", p0+3); //skip whitespaces
      p1=buf.find_first_of(":", p0);
      varValue=buf.substr(p0, p1-p0);
      pv1=varValue.find_first_of(" ", 0);
      varValue=varValue.substr(0, pv1); //delete whitespaces from varValue
      p0=buf.find_first_not_of(" ", p1+1); //skip whitespaces
      p1=buf.find_first_of(";", p0);
      if (p1==string::npos) { //if no semicolons the expression ends at the end of the line (like in Flatzinc)
        p1=buf.find_first_of(" ", p0);
        if (p1==string::npos){//no semicolons and id ends at the end of the line
          varId=buf.substr(p0);
        } else {//no semicolons, but id does not end at the end of the line (whitespaces or other characters)
          varId=buf.substr(p0, p1-p0);
          p1=buf.find_first_not_of(" ", p1);
          if (p1!=string::npos){//other characters after white spaces, warning (they won't be considered)
            cout << "Parse Warning in var declaration at line " << line << ": characters after var declaration's id \""<< varId <<"\" will not be considered" << endl;
          }
        }
      } else { //there is a semicolon
        p1=buf.find_first_of(" ;", p0);
        if (p1==buf.find_first_of(";", p0)){ //semicolons and id ends at a semicolon
          p1=buf.find_first_of(";", p0);
          varId=buf.substr(p0, p1-p0);
        } else { //semicolons, but id does not end at a semicolon (whitespaces or other characters)
          varId=buf.substr(p0, p1-p0);
          if (buf.find_first_of(";", p1)!=buf.find_first_not_of(" ", p1)){//other characters after white spaces, warning (they won't be considered)
            cout << "Parse Warning in var declaration at line " << line << ": characters after var declaration's id \""<< varId <<"\" will not be considered" << endl;
          }
        }
      }
      p1=buf.find_first_of(";", p0);
      
      if (buf.find(":: var_is_introduced",p0)!=string::npos){ //support var
        support_vars.push_back(make_pair("var "+varValue+" "+varId,line));
      } else { //regular var
        if (varValue=="bool") { //boolean var
          new var_int(); //!!!
          vars_list.push_back(make_pair(varId,globalID++));
          //outfile << "new var_int();\n\n";
          
        } else if (varValue.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos) { //int_const var
          pv1=varValue.find_first_of(".", 0);
          pv0=varValue.find_first_not_of(".", pv1);
          
          if (firstVar){ //if declaration of the first variable
            firstVar=false;
          } else {
            domain.clear(); //!!!
            //outfile << "domain.clear();\n";
          }
          
          if ((atoi(varValue.substr(pv0).c_str())-atoi(varValue.substr(0, pv1).c_str())+1)>domainDim) domainDim=atoi(varValue.substr(pv0).c_str())-atoi(varValue.substr(0, pv1).c_str())+1;
          
          for( int i = atoi(varValue.substr(0, pv1).c_str()); i <= atoi(varValue.substr(pv0).c_str()); i++) domain.push_back(i); //!!!
          new var_int(domain); //!!!
          vars_list.push_back(make_pair(varId,globalID++));
          //outfile << "for( int i = " + varValue.substr(0, pv1) + "; i <= " + varValue.substr(pv0) + "; i++) domain.push_back(i);\n";
          //outfile << "new var_int(domain);\n\n";
        } else {
          cout << "Parse Error in variable declaration at line " << line << ": incorrect var type \""<< varValue << "\"" << endl;
          vars.clear();
          coeff.clear();
          vars_list.clear();
          domain.clear();
          support_vars.clear();
          free(str);
          //outfile.close();
          exit(1);
        }
      }
      if (p1!=string::npos) { //character after last semicolon, if existent
        p0=p1+1;
      } else {
        p0=p1;
      }
    } //END VAR
    
    
    else if (buf.substr(p0, 6)=="array ") { //ARRAY DECLARATION in this line/part of line ->(array [1..int_const] of var int_const..int_const) or (array [1..int_const] of var bool)
      p0=buf.find_first_of(".", p0+5); //first . in array declaration (es. [1..int_const])
      p1=buf.find_first_of("]", p0);
      arrDim=buf.substr(p0+2, p1-(p0+2));
      p0=buf.find_first_not_of(" ", p1+1)+2; //skip whitespaces and of
      p0=buf.find_first_not_of(" ", p0)+3; //skip whitespaces and var
      p0=buf.find_first_not_of(" ", p0); //skip whitespaces
      p1=buf.find_first_of(":", p0);
      arrValue=buf.substr(p0, p1-p0);
      pv1=arrValue.find_first_of(" ", 0);
      arrValue=arrValue.substr(0, pv1); //delete whitespaces from arrValue
      p0=buf.find_first_not_of(" ", p1+1); //skip whitespaces
      p1=buf.find_first_of(";", p0);
      if (p1==string::npos) { //if no semicolons the expression ends at the end of the line (like in Flatzinc)
        p1=buf.find_first_of(" ", p0);
        if (p1==string::npos){//no semicolons and id ends at the end of the line
          arrId=buf.substr(p0);
        } else {//no semicolons, but id does not end at the end of the line (whitespaces or other characters)
          arrId=buf.substr(p0, p1-p0);
          p1=buf.find_first_not_of(" ", p1);
          if (p1!=string::npos){//other characters after white spaces, warning (they won't be considered)
            cout << "Parse Warning in array declaration at line " << line << ": characters after array declaration's id \""<< arrId <<"\" will not be considered" << endl;
          }
        }
      } else { //there is a semicolon
        p1=buf.find_first_of(" ;", p0);
        if (p1==buf.find_first_of(";", p0)){ //semicolons and id ends at a semicolon
          p1=buf.find_first_of(";", p0);
          arrId=buf.substr(p0, p1-p0);
        } else { //semicolons, but id does not end at a semicolon (whitespaces or other characters)
          arrId=buf.substr(p0, p1-p0);
          p1=buf.find_first_not_of(" ", p1);
          if (buf.find_first_of(";", p1)!=buf.find_first_not_of(" ", p1)){//other characters after white spaces, warning (they won't be considered)
            cout << "Parse Warning in array declaration at line " << line << ": characters after array declaration's id \""<< arrId <<"\" will not be considered" << endl;
          }
        }
      }
      p1=buf.find_first_of(";", p0);
      
      if (buf.find(":: output_array",p0)!=string::npos){ //output array, not translated
        pv0=buf.find_first_of("=",p0)+1;
        if (pv0!=string::npos){
          pv0=buf.find_first_of("[",pv0)+1;
          pv1=buf.find_last_of("]");
          outExpr =buf.substr(pv0, pv1-pv0);
          pv0=0;
          pv1=outExpr.find_first_of(",", 0);
          while (pv1!=string::npos)
          {
            pv0=outExpr.find_first_not_of(" ", pv0); //skip whitespaces
            varId=outExpr.substr(pv0, pv1-pv0);
            if (varId.substr(0,1).find_first_of("+-0123456789", 0)!= string::npos){ //if const value, save output value, false
              output_array_ids.push_back(make_pair(varId,false));
            } else { //if var id, save output var id, true
              output_array_ids.push_back(make_pair(varId,true));
            }
            pv0=pv1+1;
            pv1=outExpr.find_first_of(",", pv0);
          }
          pv0=outExpr.find_first_not_of(" ", pv0); //skip whitespaces
          varId=outExpr.substr(pv0);
          if (varId.substr(0,1).find_first_of("+-0123456789", 0)!= string::npos){ //if const value, save output value, false
            output_array_ids.push_back(make_pair(varId,false));
          } else { //if var id, save output var id, true
            output_array_ids.push_back(make_pair(varId,true));
          }
        }
      }
      else if (buf.find(":: var_is_introduced",p0)!=string::npos){ //support array
        support_vars.push_back(make_pair("array "+arrValue+" "+arrId+" "+arrDim,line));
      } else { //regular array
        if (arrValue=="bool") { //boolean array
          for( int i = 0; i < atoi(arrDim.c_str()); i++){
            conv << (i+1);
            new var_int(); //!!!
            vars_list.push_back(make_pair(arrId+"["+ conv.str() +"]",globalID++));
            //outfile << "new var_int();\n";
            conv.str("");
          }
        } else if (arrValue.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos) { //int_const array
          pv1=arrValue.find_first_of(".", 0);
          pv0=arrValue.find_first_not_of(".", pv1);
          if (firstVar){ //if declaration of the first variable
            firstVar=false;
          } else {
            domain.clear(); //!!!
            //outfile << "domain.clear();\n";
          }
          
          if ((atoi(arrValue.substr(pv0).c_str())-atoi(arrValue.substr(0, pv1).c_str())+1)>domainDim) domainDim=atoi(arrValue.substr(pv0).c_str())-atoi(arrValue.substr(0, pv1).c_str())+1;
          
          for( int i = atoi(arrValue.substr(0, pv1).c_str()); i <= atoi(arrValue.substr(pv0).c_str()); i++) domain.push_back(i); //!!!
          //outfile << "for( int i = " + arrValue.substr(0, pv1) + "; i <= " + arrValue.substr(pv0) + "; i++) domain.push_back(i);\n";
          
          for( int i = 0; i < atoi(arrDim.c_str()); i++){
            conv << (i+1);
            new var_int(domain); //!!!
            vars_list.push_back(make_pair(arrId+"["+ conv.str() +"]",globalID++));
            //outfile << "new var_int(domain);\n";
            conv.str("");
          }
        } else {
          cout << "Parse Error in array declaration at line " << line << ": incorrect array type \""<< arrValue << "\"" << endl;
          vars.clear();
          coeff.clear();
          vars_list.clear();
          domain.clear();
          support_vars.clear();
          free(str);
          //outfile.close();
          exit(1);
        }
      }
      //outfile << "\n";
      if (p1!=string::npos) { //character after last semicolon, if existent
        p0=p1+1;
      } else {
        p0=p1;
      }
    } //END ARRAY
    
    
    else if (buf.substr(p0, 11)=="constraint ") { //CONSTRAINT DECLARATION in this line/part of line ->(constraint constr_type(scope|int_const,…))
      if (support_vars.size()!=0) {//declaration of support vars
        for (int z=0; z<support_vars.size(); z++){
          if (support_vars[z].first.substr(0, 4)=="var ") {
            p1=support_vars[z].first.find_first_of(" ", 4);
            varValue=support_vars[z].first.substr(4, p1-4);
            varId=support_vars[z].first.substr(p1+1);
            
            if (varValue=="bool") { //boolean var
              new var_int(); //!!!
              vars_list.push_back(make_pair(varId,globalID++));
              //outfile << "new var_int();\n\n";
              
            } else if (varValue.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos) { //int_const var
              pv1=varValue.find_first_of(".", 0);
              pv0=varValue.find_first_not_of(".", pv1);
              
              if (firstVar){ //if declaration of the first variable
                firstVar=false;
              } else {
                domain.clear(); //!!!
                //outfile << "domain.clear();\n";
              }
              
              if ((atoi(varValue.substr(pv0).c_str())-atoi(varValue.substr(0, pv1).c_str())+1)>domainDim) domainDim=atoi(varValue.substr(pv0).c_str())-atoi(varValue.substr(0, pv1).c_str())+1;
              
              for( int i = atoi(varValue.substr(0, pv1).c_str()); i <= atoi(varValue.substr(pv0).c_str()); i++) domain.push_back(i); //!!!
              new var_int(domain); //!!!
              vars_list.push_back(make_pair(varId,globalID++));
              //outfile << "for( int i = " + varValue.substr(0, pv1) + "; i <= " + varValue.substr(pv0) + "; i++) domain.push_back(i);\n";
              //outfile << "new var_int(domain);\n\n";
            } else {
              cout << "Parse Error in variable declaration at line " << support_vars[z].second << ": incorrect var type \""<< varValue << "\"" << endl;
              vars.clear();
              coeff.clear();
              vars_list.clear();
              domain.clear();
              support_vars.clear();
              free(str);
              //outfile.close();
              exit(1);
            }
          }
          
          if (support_vars[z].first.substr(0, 6)=="array ") {
            p1=support_vars[z].first.find_first_of(" ", 6);
            arrValue=support_vars[z].first.substr(6, p1-6);
            p0=p1+1;
            p1=support_vars[z].first.find_first_of(" ", p0);
            arrId=support_vars[z].first.substr(p0,p1-p0);
            arrDim=support_vars[z].first.substr(p1+1);
            
            if (arrValue=="bool") { //boolean array
              for( int i = 0; i < atoi(arrDim.c_str()); i++){
                conv << (i+1);
                new var_int(); //!!!
                vars_list.push_back(make_pair(arrId+"["+ conv.str() +"]",globalID++));
                //outfile << "new var_int();\n";
                conv.str("");
              }
            } else if (arrValue.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos) { //int_const array
              pv1=arrValue.find_first_of(".", 0);
              pv0=arrValue.find_first_not_of(".", pv1);
              if (firstVar){ //if declaration of the first variable
                firstVar=false;
              } else {
                domain.clear(); //!!!
                //outfile << "domain.clear();\n";
              }
              
              if ((atoi(arrValue.substr(pv0).c_str())-atoi(arrValue.substr(0, pv1).c_str())+1)>domainDim) domainDim=atoi(arrValue.substr(pv0).c_str())-atoi(arrValue.substr(0, pv1).c_str())+1;
              
              for( int i = atoi(arrValue.substr(0, pv1).c_str()); i <= atoi(arrValue.substr(pv0).c_str()); i++) domain.push_back(i); //!!!
              //outfile << "for( int i = " + arrValue.substr(0, pv1) + "; i <= " + arrValue.substr(pv0) + "; i++) domain.push_back(i);\n";
              
              for( int i = 0; i < atoi(arrDim.c_str()); i++){
                conv << (i+1);
                new var_int(domain); //!!!
                vars_list.push_back(make_pair(arrId+"["+ conv.str() +"]",globalID++));
                //outfile << "new var_int(domain);\n";
                conv.str("");
              }
            } else {
              cout << "Parse Error in array declaration at line " << support_vars[z].second << ": incorrect array type \""<< arrValue << "\"" << endl;
              vars.clear();
              coeff.clear();
              vars_list.clear();
              domain.clear();
              support_vars.clear();
              free(str);
              //outfile.close();
              exit(1);
            }
          }
        }
        support_vars.clear();
      } //end support vars
      
      if (firstConstr){
        //g_num_vars=vars_list.size();//!!!
        //outfile << "g_num_vars=" << vars_list.size() << ";\n";
        //g_dimension_domains=domainDim;//!!!
        //outfile << "g_dimension_domains=" << domainDim << ";\n\n";
        firstConstr=false;
      }
      
      outExpr="";
      p0=buf.find_first_not_of(" ", p0+10); //skip whitespaces
      p1=buf.find_first_of("( ", p0); //find first "(" or whitespace
      constrType=buf.substr(p0, p1-p0);
      p0=buf.find_first_of("(", p1); //find first "("
      p0=buf.find_first_not_of(" ", p0+1); //skip whitespaces
      p1=buf.find_first_of(")", p0); //find first ")"
      constrExpr=buf.substr(p0, p1-p0);
      p0=buf.find_first_not_of(" ", p1+1); //skip whitespaces
      p1=buf.find_first_of(";", p0);
      str =(char*)constrExpr.c_str();
      pch = strtok (str," ,"); //separators
      while (pch != NULL)
      {
        flag=false;
        outExpr=pch;
        if (outExpr.substr(0, 1)=="["){//if array expression
          endArray=false;
          while (pch != NULL and endArray==false) {
            outExpr=pch;
            if (outExpr.substr(0, 1)=="["){ //if first array element, remove the "[" (ex. "[q[i]")
              outExpr=outExpr.substr(1);
            }
            if (outExpr.find_first_of("[", 0)!=string::npos){ // array element (ex. "p[i]" or "p[i]]")
              pv0=outExpr.find_first_of("]", 0);
              if (pv0!=outExpr.find_last_of("]")){ //ex. "p[i]]"
                outExpr=outExpr.substr(0, pv0+1);
                endArray=true;
              }
            } else if(outExpr.find_last_of("]")!=string::npos){ // var or int (ex. "a]" or "5]")
              outExpr=outExpr.substr(0, outExpr.find_last_of("]"));
              endArray=true;
            }
            
            if (outExpr.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos){ //if coeff
              coeff.push_back(atoi(outExpr.c_str())); //!!!   //ex. "123" -> 123
              //outfile << "coeff.push_back(" + outExpr + ");\n";
            } else if (outExpr.find_first_of("[", 0) != string::npos){ //if array element
              found=false;
              k=0;
              while(k<vars_list.size() and found==false){
                if (vars_list[k].first==outExpr){
                  vars.push_back(vars_list[k].second); //!!!
                  //outfile << "vars.push_back(" << vars_list[k].second << ");\n";
                  found=true;
                }
                k=k+1;
              }
              if (found==false){
                cout << "Error in constraint declaration at line " << line << ": undeclared variable \""<< outExpr << "\"" << endl;
                vars.clear();
                coeff.clear();
                vars_list.clear();
                domain.clear();
                support_vars.clear();
                free(str);
                //outfile.close();
                exit(1);
              }
            } else if (outExpr=="true"){ //if boolean "true"
              coeff.push_back(1);//!!!   //ex. "true" -> 1
              //outfile << "coeff.push_back(1);\n";
            } else if (outExpr=="false"){ //if boolean "false"
              coeff.push_back(0);//!!!   //ex. "false" -> 0
              //outfile << "coeff.push_back(0);\n";
            } else { //var id
              found=false;
              k=0;
              while(k<vars_list.size() and found==false){
                if (vars_list[k].first==outExpr){
                  vars.push_back(vars_list[k].second); //!!!
                  //coeff.push_back(-1); //!!!
                  //outfile << "vars.push_back(" << vars_list[k].second << ");\n";
                  found=true;
                }
                k=k+1;
              }
              if (found==false){
                cout << "Error in constraint declaration at line " << line << ": undeclared variable \""<< outExpr << "\"" << endl;
                vars.clear();
                coeff.clear();
                vars_list.clear();
                domain.clear();
                support_vars.clear();
                free(str);
                //outfile.close();
                exit(1);
              }
            }
            pch = strtok (NULL, " ,");
          }
          flag=true;
        }
        else if (outExpr.substr(0, 1).find_first_of("+-0123456789", 0) != string::npos){ //if coeff
          coeff.push_back(atoi(outExpr.c_str())); //!!!   //ex. "123" -> 123
          //outfile << "coeff.push_back(" + outExpr + ");\n";
        } else if (outExpr.find_first_of("[", 0) != string::npos){ //if array element
          found=false;
          k=0;
          while(k<vars_list.size() and found==false){
            if (vars_list[k].first==outExpr){
              vars.push_back(vars_list[k].second); //!!!
              coeff.push_back(-1); //!!!
              //outfile << "vars.push_back(" << vars_list[k].second << ");\n";
              //outfile << "coeff.push_back(-1);\n";
              found=true;
            }
            k=k+1;
          }
          if (found==false){
            cout << "Error in constraint declaration at line " << line << ": undeclared variable \""<< outExpr << "\"" << endl;
            vars.clear();
            coeff.clear();
            vars_list.clear();
            domain.clear();
            support_vars.clear();
            free(str);
            //outfile.close();
            exit(1);
          }
        } else if (outExpr=="true"){ //if boolean "true"
          coeff.push_back(1);//!!!   //ex. "true" -> 1
          //outfile << "coeff.push_back(1);\n";
        } else if (outExpr=="false"){ //if boolean "false"
          coeff.push_back(0);//!!!   //ex. "false" -> 0
          //outfile << "coeff.push_back(0);\n";
        } else { //var id
          found=false;
          k=0;
          while(k<vars_list.size() and found==false){
            pv0=vars_list[k].first.find_first_of("[",0);
            if (pv0!=string::npos){ //array id
              if (vars_list[k].first.substr(0,pv0)==outExpr){
                while (k<vars_list.size() and vars_list[k].first.substr(0,pv0)==outExpr){
                  vars.push_back(vars_list[k].second); //!!!
                  coeff.push_back(-1); //!!!
                  //outfile << "vars.push_back(" << vars_list[k].second << ");\n";
                  //outfile << "coeff.push_back(-1);\n";
                  k=k+1;
                }
                found=true;
              }
            } else { //var id
              if (vars_list[k].first==outExpr){
                vars.push_back(vars_list[k].second); //!!!
                coeff.push_back(-1); //!!!
                //outfile << "vars.push_back(" << vars_list[k].second << ");\n";
                //outfile << "coeff.push_back(-1);\n";
                found=true;
              }
            }
            k=k+1;
          }
          if (found==false){
            cout << "Error in constraint declaration at line " << line << ": undeclared variable \""<< outExpr << "\"" << endl;
            vars.clear();
            coeff.clear();
            vars_list.clear();
            domain.clear();
            support_vars.clear();
            free(str);
            //outfile.close();
            exit(1);
          }
        }
        if (flag==false){
          pch = strtok (NULL, " ,");
        }
      }
      if (coeff.size()==0){
        new Constraint(string2constr(constrType, line), vars); //!!!
        //outfile << "new Constraint(" + constrType + ", vars);\n";
      } else {
        new Constraint(string2constr(constrType, line), vars, coeff); //!!!
        coeff.clear(); //!!!
        //outfile << "new Constraint(" + constrType + ", vars, coeff);\n";
        //outfile << "coeff.clear();\n";
      }
      vars.clear(); //!!!
      //outfile << "vars.clear();\n\n";
      
      if (p1!=string::npos) { //character after last semicolon, if existent
        p0=p1+1;
      } else {
        p0=p1;
      }
    } //END CONSTRAINT
    
    
    else if (buf.substr(p0, 6)=="solve ") { //SOLVE GOAL in this line/part of line -> solve satisfy
      p0=buf.find_first_not_of(" ", p0+6); //skip whitespaces
      
      if (buf.substr(p0, 2)=="::") { //if annotation
        cout << "Parse Warning in solve goal at line " << line << ": annotations will not be considered" << endl;
        p0=buf.find_last_of(")")+1;
        p0=buf.find_first_not_of(" ", p0); //skip whitespaces
      }
      p1=buf.find_first_of(" ", p0);
      if (p1==string::npos or p1>buf.find_first_of(";", p0)) { //no whitespaces
        p1=buf.find_first_of(";", p0);
        if (p1==string::npos){ //no whitespaces and the expression ends at the end of the line
          outExpr=buf.substr(p0);
        } else { //no whitespaces and the expression ends at a semicolon
          outExpr=buf.substr(p0, p1-p0);
        }
      } else { //whitespaces
        outExpr=buf.substr(p0, p1-p0);
      }
      
      if (outExpr!="satisfy") { //wrong solve goal
        cout << "Parse Error in solve goal at line " << line << ": solve goal \""<< outExpr <<"\" not supported" << endl;
        vars.clear();
        coeff.clear();
        vars_list.clear();
        domain.clear();
        support_vars.clear();
        free(str);
        //outfile.close();
        exit(1);
      }
      p1=buf.find_first_of(";", p0);
      
      if (p1!=string::npos) { //character after last semicolon, if existent
        p0=p1+1;
      } else {
        p0=p1;
      }
    } //END SOLVE
    else{ 
      //if identifier matches with none of the previous patterns
      cout << "Parse Error in Flatzinc model declaration at line " << line << ": undeclared identifier" << endl;
      vars.clear();
      coeff.clear();
      vars_list.clear();
      domain.clear();
      support_vars.clear();
      free(str);
      //outfile.close();
      exit(1);
    }
    //} while (p0 != string::npos);
    
  }//while
  
  //g_num_cons = g_constraints.size(); //!!!
  
  //cout << "********************" << endl;
  //cout << "**** Host Alloc ****" << endl;
  Utilities::alloc_variables();
  Utilities::alloc_constraints();
  //cout << "********************" << endl;
  
  //outfile << "g_num_cons = g_constraints.size();\n";
  //outfile << "cuda_alloc_variables();\n";
  //outfile << "cuda_alloc_constraints();";
  
  
  //outfile.close();
  return ;
}//end parser



void
Benchmark::BaseTest(int nn) {
  vector<int> vars;
  vector<int> coeff;
  vector<int> domain;
  
  for (int i = 0; i < 10; i++) domain.push_back(i);
  new var_int (domain);
  domain.clear();
  
  for (int i = 0; i < 10; i++) domain.push_back(i);
  new var_int (domain);
  domain.clear();
  
  vars.push_back(0);
  coeff.push_back(-1);
  coeff.push_back(-1);
  new Constraint( int_lin_le, vars, coeff );
  vars.clear();
  coeff.clear();
  
  vars.push_back(0);
  vars.push_back(1);
  coeff.push_back(3);
  coeff.push_back(2);
  coeff.push_back(6);
  new Constraint( int_lin_le, vars, coeff );
  vars.clear();
  coeff.clear();
  
  vars.push_back(0);
  vars.push_back(1);
  coeff.push_back(3);
  coeff.push_back(-1);
  coeff.push_back(6);
  new Constraint( int_lin_le, vars, coeff );
  vars.clear();
  coeff.clear();
  
  //cout << "********************" << endl;
  //cout << "**** Host Alloc ****" << endl;
  Utilities::alloc_variables();
  Utilities::alloc_constraints();
  //cout << "********************" << endl;
 
}//BaseTest



void
Benchmark::NQueens(int n) {
}//print_NQueens

void
Benchmark::print_BaseTest() {
  var_int* var_selected;
  cout << "Solution: " << endl;
  for (int i = 0; i < g_cp_variables.size(); i++) {
    var_selected = (var_int*) g_cp_variables[i];
    var_selected->print_value( );
    cout << " ";
  }
  cout << endl;
}//print_BaseTest
