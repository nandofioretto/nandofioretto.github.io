#ifndef CPFF_GLOBALS_H
#define CPFF_GLOBALS_H

/* Common dependencies */
#include <stdlib.h> 
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <math.h>

/* Input/Output */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>

/* Arithmetic and Assertions */
#include <cassert>
#include <cmath>
#include <limits>

/* STL dependencies */
#include <algorithm>
#include <iterator>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <string>
#include <vector>
#include <utility>

// C++11
#include <random>

class ConstraintStore;
class Constraint;
/* class TrailStack; */
class Variable;

extern ConstraintStore* g_constraint_store;
/* extern TrailStack*      g_trailstack; */
//-------Dec13-----------//
extern std::map< int, std::vector< Constraint* > > g_constr_of_var; // <vid, **con>
extern std::map< int, Constraint* > g_constr_set; // < id, *con >
extern std::map< int, Variable* > g_var_set;	  // < id, *var>
//------Dec9------//
extern int g_curr_var_labeled;


typedef struct 
{
  std::vector<bool> states; 
  short lb, ub, nactive; 
  int event,label;
  bool assigned;
} var_state;

extern std::map< int, var_state > g_var_states;

/* Event Reasoning */
#define FIX_EVENT    -3
#define FAILED_EVENT -2
#define EMPTY_EVENT  -1
#define SING_EVENT    0
#define BC_EVENT      1
#define DC_EVENT      2
#define ALL_EVENTS    3
#define N_OF_EVENTS   4
//-------end-----------//

#endif
