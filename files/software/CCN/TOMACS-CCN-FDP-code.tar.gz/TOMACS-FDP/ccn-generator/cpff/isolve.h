#ifndef CP_CONSTRAINT_STORE_
#define CP_CONSTRAINT_STORE_

#include "cpff_globals.h"
#include "var_int.h"

class Variable;
class Constraint;

class ISolve {
private:
  int constraint_queue_size;
  int n_threads;
  int * dom_events;
  int * constraint_queue;
  int * already_set_cons;
  
  void copy_state_to_gpu(int level=0);
  void copy_state_from_gpu(int level=0, bool trail=true);
  
public:
  int backtrack_action;
  int curr_labeled_var;

  ISolve();
  ~ISolve();

  void init();
  void reset();
  void set_singlet_event ( int v_idx, int label );
  bool ISOLVPAR (std::vector< var_int> *V, bool trail=true);

  // Preprocessing
  void init_states_on_gpu();

  void dump_domains();
};//-

#endif
