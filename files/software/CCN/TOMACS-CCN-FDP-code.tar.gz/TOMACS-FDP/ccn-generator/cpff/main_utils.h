#ifndef CP_UTILITIES_
#define CP_UTILITIES_

#include "cpff_globals.h"

class Variable;

namespace Utilities
{
  void save_vars_state();
  void restore_vars_state( ); 
  void save_var_state( Variable* var );
  void restore_var_state( Variable* var ); 
  void dump_vars();
}

#endif
