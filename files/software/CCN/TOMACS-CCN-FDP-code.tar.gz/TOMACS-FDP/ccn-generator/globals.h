#ifndef CRNIFF_GLOBALS_H
#define CRNIFF_GLOBALS_H

/* Common dependencies */
#include <stdlib.h> // for atoi
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

/* Input/Output */
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>

/* Arithmetic and Assertions */
#include <cassert>
#include <cmath>
#include <limits>
/* #include <random> */

/* STL dependencies */
#include <algorithm>
#include <iterator>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <string>
#include <vector>
#include <utility>
#include <bitset>

/* C++11 libraries */
/* #include <ctime> */
/* #include <chrono> */

class Variable;
class Graph;
class Statistics;
class Solution;

/* Global Variables */
extern std::map<std::string,int> g_gene_ids;
extern std::map<int,std::string> g_gene_names;

extern std::map<std::pair<int,int>,int> g_edge_var;
extern std::map<int,std::pair<int,int> > g_var_edge;

extern std::vector<int> g_TFs;
extern std::vector<int> g_TGs;

// not of use
extern std::map< int, std::vector< Variable* > > g_outgoing_edges_of_node;
extern std::map< int, std::vector< int > > g_neighbours;

struct s_InfKB{ int nnodes; int nedges; bool causal; Graph *goldStd; };

struct s_Consts{ double minTPconfidence; int confidenceRange; };
// minTPconfidence initialized as the average of the edges in the last quartile
// from training set --> 

extern s_Consts g_Consts; 
extern s_InfKB g_InfKB;
extern Statistics g_stats;
extern std::vector< Solution* > g_solutions;

///struct s_Options{ bool discrepancy; bool }


/* ***********************************************************
 * Compare Methods and Global Functions
 * ***********************************************************/ 
template <typename T>
bool cmp_leq ( const T& lhs, const T& rhs ) 
{
  return lhs < rhs; 
}//-

template <typename T>
bool cmp_geq ( const T& lhs, const T& rhs ) 
{
  return rhs < lhs; 
}//-

template <typename T> 
bool cmp_second_leq (const T& lhs, const T& rhs) 
{
  return lhs.second < rhs.second;
}//-

template <typename T>
bool cmp_second_geq (const T& lhs, const T& rhs) 
{
  return rhs.second < lhs.second;
}//-

#endif
