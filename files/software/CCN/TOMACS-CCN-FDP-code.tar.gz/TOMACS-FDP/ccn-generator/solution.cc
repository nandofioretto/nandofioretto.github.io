#include "solution.h"
#include "cpff_headers.h"
#include "solopt_utils.h"

using namespace std;

bool cmp_sols (Solution lhs, Solution rhs) 
{ 
  return (lhs.get_AUROC() < rhs.get_AUROC() ); 
}//-


Solution::Solution()
{
  _states.resize( g_var_set.size() );
  std::map<int,Variable*>::iterator it;
  it = g_var_set.begin(); int i = 0;
  
  for (; it != g_var_set.end(); ++it)
  {
    _states[ i++ ] = it->second->value();
  }

  std::pair<double,double> M = SolOpt::get_measures( _states  );
  _AUROC = M.first;
  _AUPR  = M.second;
}//-


Solution::Solution( std::vector<double> state )
{
  _states = state;
  std::pair<double,double> M = SolOpt::get_measures( _states  );
  _AUROC = M.first;
  _AUPR  = M.second;
}//-


Solution::Solution( const Solution& other )
{
  _states = other._states;
  _AUROC  = other._AUROC;
  _AUROC2  = other._AUROC2;
  _AUPR   = other._AUPR;
  _Fscore = other._Fscore;
}//-

double& Solution::operator[]( size_t pos ) 
{ 
  return _states[ pos ]; 
}//-

double Solution::operator[]( size_t pos ) const
{ 
  return _states[ pos ]; 
}//-

bool Solution::operator() ( const Solution& lhs, const Solution& rhs ) const
{
  return ( rhs._AUROC < lhs._AUROC );
}//-

bool Solution::operator< ( const Solution& other ) const
{
  return (_AUROC < other._AUROC);
}//-

bool Solution::operator<= ( const Solution& other ) const
{
  return (_AUROC <= other._AUROC);
}//-

std::vector<double> Solution::get_states()
{
  return _states;
}//-

double Solution::get_AUROC()
{
  return _AUROC;
}//-

double Solution::get_AUROC2()
{
  return _AUROC2;
}//-

double Solution::get_AUPR()
{
  return _AUPR;
}//-

double Solution::get_Fscore()
{
  return _Fscore;
}//-


size_t Solution::size()
{
  return _states.size();
}//-

void Solution::dump()
{
  cout << "AUROC: " << _AUROC << " AUPR: " << _AUPR << endl;
}//-
