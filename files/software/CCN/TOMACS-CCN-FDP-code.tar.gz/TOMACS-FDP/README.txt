TOMACS FDP-code associated with the paper: Constrained Community-based Gene Regulatory Network Inference.
==================================

This folder is organised as follow:

/data/
contains the Network topologies and the datasets used in the experimental results.

/ensemble-generator/
contains the R scripts to generate the individual method prediction for each of the methods listed in Sect. 2.3 of the paper.

/preprocess-data/
C++ script to transform original datasets in a type recognisable by 

/ccn-generator/ 
The Constraint Solver used to generate the CCNs.


===================================
All tests are run by performing the following steps:

1. generate individual predictions by executing the function 'main()' in R, after loading the file '/ensemble-generator/main.R'

2. The results of this phase must be saved in the appropriate /prediction/XXX/individual-methods/ folder, where XXX is one of FDP, DREAM3 or DREAM4.

3. Execute the CCN script files (in ccn-generator/tests/test-TOMACS.sh) to generate the CCN predictions associated to all the network and benchmark datasets described in Sect. 4 of the paper.
