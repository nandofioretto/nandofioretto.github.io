#setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/scripts")
source("func_analysis.R")
source("func_datasets.R")

require(infotheo)
require(minet) # For ARACNE, CLR, MRNET and validation


c_anova <- function (gene_network, size, network_no, dataset, weight=1000, no.tf,
 	exec.preproc="preprocess",
	path.preproc="preprocess",
	exec.anova="anova",
	path.anova="anova")
{
	path.exec.preproc <- file.path(path.preproc, exec.preproc)
	path.exec.anova   <- file.path(path.anova, exec.anova)
	path.file.out     <- file.path(path.preproc, "tmp")
	path.dataset <- get_data.path(gene_network, size, network_no)
	path.mf = paste(path.dataset, file.mf, sep ="/")
	path.ko = paste(path.dataset, file.ko, sep ="/")
	file.out = paste( gene_network, size, network_no, sep="_" )	
	 
	# Call Preprocess with correct input data from .c file
    command = path.exec.preproc
    if(dataset == "mf" | dataset == "all")
    	command = paste( command, "--microarray-mf", path.mf )
  	if(dataset == "ko" | dataset == "all")
    	command  = paste( command, "--microarray-ko", path.ko )
	command = paste( command, " --path-out", path.file.out, 
				"> /dev/null")
	system(command)   

	# Call Anova
	command = paste( path.exec.anova, path.file.out, weight, no.tf, 
	"> /dev/null")
	system(command)
	
	# Import Results
	path.file.genes <- paste(path.file.out, "_gene_names.tsv", sep="")
	genes <- read.delim(path.file.genes, sep="")
	genes <- names(genes)
	prob <- read.table( paste(path.file.out,"pair",sep="."), header=FALSE)

	# Clean tmp files
	command = paste( "rm ", path.preproc, "/", "*.{tsv,pair}", sep="") 
	system (command)

	# Post-process Results	
	ngenes = length(genes)
	pred = matrix(0, nrow=ngenes, ncol=ngenes, dimnames=list(genes, genes))
	N <- length(rownames(prob))
	for( i in 1:N)
	{
		x <- prob[i, 1]
		y <- prob[i, 2]
		pred[as.character(x), as.character(y)] <- prob[i, 3]
	}
	return (pred)
}



###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_Anova <- function ( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5), 
dataset=c("mf", "ko", "all"), sym=F, path_out=NULL, exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	pred <- c_anova(gene_network, size, network_no, dataset, no.tf=size)
	gold <- get_goldstd( path.dataset, rownames(pred) )
	if( !is.null(path_out) ) save_prediction(pred, path_out)
	tbl = ccn_validate(pred, gold, sym)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}#-