###
  # Get the gene names, the pairwise edge confidence values,
  # and the Gold Standard, and build the table summarizing 
  # these information and ordered by edge confidence strenght
###
build_prediction_table <- function ( Genes, Prob, Gold )
{
	N   <- length(Genes); 
	G1  <- rep("a", N*N-N);  G2  <- rep("b", N*N-N)
	Values <- rep(0, N*N-N); 
	if( ! is.null(Gold) ) Labels  <- rep(0, N*N-N)

	i = 1
	for( x in Genes) {
		for( y in Genes) {
			if( x != y)  { 
				G1[i] = x; G2[i] = y
				Values[i]= abs(Prob[ x, y ])
				if( !is.null(Gold) ) Labels[i] = Gold[x, y]
				i = i + 1
			}
		}
	}
	if( !is.null(Gold) ) D <- data.frame( G1, G2, Values, Labels )
	else D <- data.frame( G1, G2, Values )

	D <- D[ order(D$Val, decreasing=TRUE), ] 
	return(D)
}

###
  # Validate Predictions against Gold Std and return a table interpretable 
  # by package auc.roc and auc.pr from minet (R)
###
ccn_validate <- function (Pred, Gold, use_sym=FALSE) 
{	
    if (any(Gold != 0 & Gold != 1)) 
        stop("argument 'Gold' must contain values 0 or 1")
    if (!all(dim(Pred) == dim(Gold))) 
        stop("networks must have the same size")
    if (!all(names(as.data.frame(Pred)) == names(as.data.frame(Gold)))) 
        warning("networks have not the same node names")
    if (!is.matrix(Pred)) 
        stop("infered network should be a matrix")
    if (!is.matrix(Gold)) 
        stop("true network should be a matrix")
    if (use_sym && !isSymmetric(Pred) && isSymmetric(Gold)) {
 	  	 #warning("infered network arcs will be consider as undirected edges")
         Pred <- pmax(Pred, t(Pred))
         #dim(Pred) <- c(ncol(Gold), ncol(Gold))
    } else if (use_sym && isSymmetric(Pred) && !isSymmetric(Gold)) {
        #warning("true network arcs will be considerd as undirected edges")
        Gold <- pmax(Gold, t(Gold))
        #dim(Gold) <- c(ncol(Pred), ncol(Pred))
    }

  	Genes <- colnames(Pred)
	tbl <- build_prediction_table(Genes, Pred, Gold )
	TN = length(which(tbl$Labels==0))
	FN = length(which(tbl$Labels==1))	
   	N   <- length(Genes); thresh <- rep(0, N*N-N);
	tp <- rep(0, N*N-N);  fp  <- rep(0, N*N-N)
	tn  <- rep(0, N*N-N); fn  <- rep(0, N*N-N)
	i = 1
	tp[1] = 0; fp[1] = 0; fn[1] = FN; tn[1] = TN;
	thresh[1] = tbl$Values[1]
	for( i in 2:(N*N-N) )
	{
		thresh[i] = tbl$Values[i]
		if( tbl$Labels[i] == 1 ) 
		{
			tp[i] = tp[i-1] + 1;
			fp[i] = fp[i-1];
			fn[i] = fn[i-1] - 1;
			tn[i] = tn[i-1];
		}
		else
		{
			tp[i] = tp[i-1];
			fp[i] = fp[i-1] + 1;
			fn[i] = fn[i-1];
			tn[i] = tn[i-1] - 1;	
		}
	}
   
    res <- data.frame(thresh, tp, fp, fn, tn)
    names(res) <- c("thrsh", "tp", "fp", "fn", "tn")
    return( res )
}


ccn_validate.table <- function (tbl, N) 
{	
	TN = length(which(tbl$Labels==0))
	FN = length(which(tbl$Labels==1))	
	thresh <- rep(0, N*N-N);
	tp <- rep(0, N*N-N);  fp  <- rep(0, N*N-N)
	tn  <- rep(0, N*N-N); fn  <- rep(0, N*N-N)
	i = 1
	tp[1] = 0; fp[1] = 0; fn[1] = FN; tn[1] = TN;
	thresh[1] = tbl$Values[1]
	for( i in 2:(N*N-N) )
	{
		thresh[i] = tbl$Values[i]
		if( tbl$Labels[i] == 1 ) 
		{
			tp[i] = tp[i-1] + 1;
			fp[i] = fp[i-1];
			fn[i] = fn[i-1] - 1;
			tn[i] = tn[i-1];
		}
		else
		{
			tp[i] = tp[i-1];
			fp[i] = fp[i-1] + 1;
			fn[i] = fn[i-1];
			tn[i] = tn[i-1] - 1;	
		}
	}
   
    res <- data.frame(thresh, tp, fp, fn, tn)
    names(res) <- c("thrsh", "tp", "fp", "fn", "tn")
    return( res )
}



###
  # Compute AUROC, given the edge confidences and the True positives
### 
 getROC_AUC = function(probs, true_Y)
 { 
    probsSort = sort(probs, decreasing = TRUE, index.return = TRUE)
    val = unlist(probsSort$x)
    idx = unlist(probsSort$ix)  

    roc_y = true_Y[idx];
    stack_x = cumsum(roc_y == 0)/sum(roc_y == 0)
    stack_y = cumsum(roc_y == 1)/sum(roc_y == 1)    

    auc = sum((stack_x[2:length(roc_y)]-stack_x[1:length(roc_y)-1])*stack_y[2:length(roc_y)])
    return(list(stack_x=stack_x, stack_y=stack_y, auc=auc))
}



# Example code for graph
#aList = getROC_AUC(T.ecoli1.pearson.out$Values, T.ecoli1.pearson.out$Labels) 
#stack_x = unlist(aList$stack_x)
#stack_y = unlist(aList$stack_y)
#auc = unlist(aList$auc)
#plot(stack_x, stack_y, type = "l", col = "blue", xlab = "False Positive Rate", ylab = "True Positive Rate", main = "ROC")
#axis(1, seq(0.0,1.0,0.1))
#axis(2, seq(0.0,1.0,0.1))
#abline(h=seq(0.0,1.0,0.1), v=seq(0.0,1.0,0.1), col="gray", lty=3)
#legend(0.7, 0.3, sprintf("%3.3f",auc), lty=c(1,1), lwd=c(2.5,2.5), col="blue", title = "AUC")
###