Platform: Mac OS

To run, open R and source main.R.