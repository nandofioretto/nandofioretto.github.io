### d5c4-sort-edges.R
###
### Joe Song
### September 15, 2010

## Network predictions

## Submitted networks must be directed and unsigned. Self-interactions
## (auto-regulatory loops) are ignored in the evaluation (they will be removed
## from the gold standard networks).

## For each network, submit a ranked list of no more than 100,000 regulatory
## link predictions ordered according to the confidence you assign to the
## predictions, from the most reliable (first row) to the least reliable
## (last row) prediction. You can submit less than 100,000 edges. Links (pairs
## of nodes) that are not part of the submitted list are considered to appear
## randomly ordered at the end of the list.
## In your submission, use a tab-separated column format as in the example below:
## A \tab B \tab X

## where A and B are two different genes (no self-interactions). Use the labels
## given in the header of the file Networki_expression_data.tsv to identify
## genes (G1, G2, etc). Links are directed: the gene in the first column
## regulates the gene in the second column. (If both A regulates B and B
## regulates A, then both lines should be included.) Gene A must be a TF listed
## in the file Networki_transcription_factors.tsv of that network (gene B may
## be any gene of the network, TF or non-TF). X is a score between 0 and 1 that
## indicates the confidence level you assign to the prediction. (E.g., X = 1 if
## gene A is deemed to regulate gene B with highest confidence and X = 0 if A
## is deemed not to directly regulate B). Save the file as text, and name it:

## DREAM5_NetworkInference_TeamName_Networki.txt

## where TeamName is the name of the team with which you registered for the
## challenge, and i is 1, 2, 3, or 4.

#Sort.Edges <- function(file.intx, file.sorted.edges, max.n.edges)
Sort.Edges <- function(file.intx, file.sorted.edges, max.n.edges, file.sorted.intx, n.genes)
{
  # load the interaction file
  intx <- read.table(file.intx, header=TRUE, comment.char="N", nrows = n.genes, sep="\t")
  
  #colnames(intx) <- c("C.ID", "C.Name", "Type", "N.Parents", "Parents",
  #                   "p.val", "chisq", "df")
  
  ## intx.sorted <- sort(intx, by = ~ p.val + df - chisq)
  
  intx.sorted <- intx[order(intx$p.val), ]
  write.table(intx.sorted, file=file.sorted.edges)
  
  #browser()
  
  edges <- c()
  n.edges <- 0
  
  buffer <- ""
  
  for( i in 1:nrow(intx.sorted) ) {
    
    if(i %% 100 == 0) cat(i, ";")
    if(i %% 1000 == 0) cat("\n")
    
    ## child node must be a gene node
    child.name <- as.character(intx.sorted[i, 2])
    if(substr(child.name, 1, 1) == "P") next
    
    k <- intx.sorted[i, "num.parents"]
    
    if( k == 0 ) {
      next
    } else {
      parents.list <- unlist(strsplit(as.character(intx.sorted[i, 5]), ","))
    }
    
    for( j in 1:k ) {
      
      # id.name <- unlist(strsplit(parents.list[j], ":"))
      # parent.name <- id.name[2]
      
      parent.name <- parents.list[j]
      
      ## parent node must be a gene node
      if(substr(parent.name, 1, 1) == "P") next
      
      ## skip edge if already exists on the list
      parent.name <- paste("G",parent.name,sep="")
      edge <- paste(parent.name, child.name, sep="->")
      if(edge %in% edges) next
      
      #one.line <- paste(parent.name, child.name,
      #  (1-intx.sorted[i, "p.val"]/alpha), "\n", sep="\t")
      
      #1e-323 is the minimum number R holds
      minimumPvalue <- intx.sorted[1, "p.value"]
      if(intx.sorted[1, "p.value"]<1e-323)
      {
        minimumPvalue <- 1e-323
      }
      
      if(intx.sorted[i, "p.value"] < minimumPvalue)
      {
        one.line <- paste(parent.name, child.name,1,"\n", sep="\t")
      }else
      {
        one.line <- paste(parent.name, child.name,
                          (log10(intx.sorted[i, "p.value"]))/log10(minimumPvalue), "\n", sep="\t")
        
      }
      if(nchar(buffer) == 0) {
        buffer <- one.line
      } else {
        buffer <- paste(buffer, one.line, sep="")
      }
      
      edges <- c(edges, edge)
      n.edges <- n.edges + 1
      
      if(n.edges >= max.n.edges) break
      
    }
    
    if(n.edges >= max.n.edges) break
    
  }
  
  cat(buffer, file=file.sorted.edges)
}

###########################################################################################
Sort.Edges.Fast2 <- function(file.intx, file.sorted.edges, max.n.edges, file.sorted.intx)
{
  # load the interaction file
  intx <- read.table(file.intx, header=FALSE)
  
  colnames(intx) <- c("C.ID", "C.Name", "Type", "N.Parents", "Parents",
                      "p.val", "chisq", "df")
  
  ## intx.sorted <- sort(intx, by = ~ p.val + df - chisq)
  
  intx.sorted <- intx[order(intx$p.val), ]
  
  system(paste("touch ", file.sorted.intx, sep=""))
  
  write.table(intx.sorted, file=file.sorted.intx)
  
  E <- sum(intx.sorted$N.Parents)
  
  cat("There are", nrow(intx.sorted), "interactions, including", E, "edges (with duplicates).\n")
  ## edges <- vector(mode="character", length=E)
  
  minimumPvalue <- intx.sorted[1, "p.val"]
  
  if(intx.sorted[1, "p.val"] < 1e-323)
  {
    minimumPvalue <- 1e-323
  }  
  
  ##################extract.edges function def###############################
  extract.edges <- function(i)  {
    
    ## browser()
    
    if(i %% 100 == 0) cat(i, ";")
    if(i %% 1000 == 0) cat("\n")
    
    intx <- intx.sorted[i,]
    
    child.name <- as.character(intx$C.Name)
    if(substr(child.name, 1, 1) == "P") return(list())
    
    k <- intx$N.Parents
    
    if( k == 0 ) {
      return(list())
    } else {
      parents.list <- unlist(strsplit(as.character(intx$Parents), ","))
    }
    
    edges.intx <- vector()
    
    for( j in 1:k ) {
      
      id.name <- unlist(strsplit(parents.list[j], ":"))
      parent.name <- id.name[2]
      
      ## parent node must be a gene node
      if(substr(parent.name, 1, 1) == "P") return(list())
      
      ## skip edge if already exists on the list
      edge <- paste(parent.name, child.name, sep="\t")
      edges.intx <- c(edges.intx, edge)
      
    }
    
    p.val <- intx$p.val	
    
    if( p.val < minimumPvalue )
    {
      confidence <- 1
      
    } else {
      
      confidence <- log10((p.val)) / log10(minimumPvalue)
      
    }
    
    names(edges.intx) <- rep( confidence, length(edges.intx) )
    
    return( as.list( edges.intx ) )
  }
  ###########################################################33
  cat("extracting edges")
  edges <- (lapply(1:nrow(intx.sorted), extract.edges))
  cat("extracting confidences")
  confidences <- unlist(lapply(edges, names))
  
  edges <- unlist(edges)
  
  adjustConfidence <- function(rowindex)  {
    
    confidences[rowindex] <- as.numeric(confidences[rowindex]) * log10(minimumPvalue)
    confidences[rowindex] <- 10^as.numeric(confidences[rowindex])
    confidences[rowindex] <- as.numeric(confidences[rowindex])/length(edges[edges==edges[rowindex]])
    confidences[rowindex] <- log10(as.numeric(confidences[rowindex])) / log10(minimumPvalue)
    if(as.numeric(confidences[rowindex])>1)
    {
      confidences[rowindex] <- 1
    }
    return( as.list (confidences[rowindex]) )
    
  }
  
  confidences <- lapply(1:length(confidences),adjustConfidence)
  
  confidences <-  unlist(confidences)
  
  #if(FALSE)
  #{
  #changed to lapply
  #		  for(rowindex in 1:length(edges))
  #		  {
  #		  	confidences[rowindex] <- as.numeric(confidences[rowindex]) * log10(minimumPvalue)
  #		  	confidences[rowindex] <- 10^as.numeric(confidences[rowindex])
  #		  	confidences[rowindex] <- as.numeric(confidences[rowindex])/length(edges[edges==edges[rowindex]])
  #		  	confidences[rowindex] <- log10(as.numeric(confidences[rowindex])) / log10(minimumPvalue)
  #		  	if(confidences[rowindex]>1)
  #		  	{
  #		  		confidences[rowindex] <- 1
  #		  	}
  #		  }
  #}
  confidences <- confidences[ !duplicated(edges) ]
  edges <- edges[ !duplicated(edges) ]
  
  edges <- edges[ order(confidences,decreasing=TRUE) ]
  confidences <- sort(confidences,decreasing=TRUE)
  
  #n.edges <- min(nrow(edges), max.n.edges)
  n.edges <- min(length(edges), max.n.edges)
  
  #browser()
  
  write.table(data.frame(edges[1:n.edges], confidences[1:n.edges]), 
              col.names=FALSE, row.names=FALSE, sep="\t", quote=FALSE, file=file.sorted.edges)
  
  return(list(edges, confidences))
}




###########################################################################################
Sort.Edges.Fast <- function(file.intx, file.sorted.edges, max.n.edges, file.sorted.intx)
{
  # load the interaction file
  intx <- read.table(file.intx, header=FALSE)
  
  colnames(intx) <- c("C.ID", "C.Name", "Type", "N.Parents", "Parents",
                      "p.val", "chisq", "df")
  
  #cat("\nthe v.val vector: ", is.numeric(intx$p.val),"\n");
  ## intx.sorted <- sort(intx, by = ~ p.val + df - chisq)
  
  intx.sorted <- intx[order(intx$p.val), ]
  
  #system(paste("touch ", file.sorted.intx, sep=""))
  
  write.table(intx.sorted, file=file.sorted.intx)
  
  E <- sum(intx.sorted$N.Parents)
  
  cat("There are", nrow(intx.sorted), "interactions, including", E, "edges (with duplicates).\n")
  ## edges <- vector(mode="character", length=E)
  
  useStat = FALSE
  # thunt: changed to handle large chisqare with many df's
  if(TRUE){#if(max(intx$df) > 50){
    useStat = TRUE
    #normalize chisq
    
    intx.sorted$chisq = (intx.sorted$chisq - intx.sorted$df) / sqrt(2 * intx.sorted$df)
    intx.sorted <- intx.sorted[order(intx.sorted$chisq, decreasing=TRUE), ]
  }
  
  else{
    minimumPvalue <- intx.sorted[1, "p.val"]
    if(intx.sorted[1, "p.val"] < 1e-323)
    {
      minimumPvalue <- 1e-323
    }
  }  
  
  ##################extract.edges function def###############################
  extract.edges <- function(i)  {
    
    ## browser()
    
    if(i %% 10000 == 0) cat(i, ";")
    if(i %% 100000 == 0) cat("\n")
    
    ## get the current line to be worked on
    intx <- intx.sorted[i,]
    
    #extract the name
    child.name <- as.character(intx$C.Name)
    
    # if the node is not a gene dump it (return nothing)
    if(substr(child.name, 1, 1) == "P") return(list())
    
    #make k the value for the number of parent
    k <- intx$N.Parents
    
    #if k is 0 this node has no parents
    if( k == 0 ) {
      # stop here return nothing
      return(list())
    } else {
      #extract the parents for this node
      parents.list <- unlist(strsplit(as.character(intx$Parents), ","))
    }
    #create a vector to store the edges
    edges.intx <- vector()
    # look at the list of parents
    for( j in 1:k ) {
      
      ##extract the parent name
      id.name <- unlist(strsplit(parents.list[j], ":"))
      parent.name <- id.name[2]
      
      ## parent node must be a gene node
      if(substr(parent.name, 1, 1) == "P") return(list())
      
      ## skip edge if already exists on the list
      edge <- paste(parent.name, child.name, sep="\t")
      edges.intx <- c(edges.intx, edge)
      
    }
    if( ! useStat ){
      p.val <- intx$p.val	
      
      if( p.val < minimumPvalue )
      {
        confidence <- 1
        
      } else {
        
        # confidence <- log10((p.val)) / log10(minimumPvalue)
        confidence = 1 - p.val	
      }
    }
    else{
      confidence <-  intx$chisq
    }
    names(edges.intx) <- rep( confidence, length(edges.intx) )
    
    return( as.list( edges.intx ) )
  }
  ###########################################################33
  cat("extracting edges")
  edges <- (lapply(1:nrow(intx.sorted), extract.edges))
  cat("extracting confidences")
  confidences <- unlist(lapply(edges, names))
  
  edges <- unlist(edges)
  
  adjustConfidence <- function(rowindex)  {
    
    confidences[rowindex] <- as.numeric(confidences[rowindex]) * log10(minimumPvalue)
    confidences[rowindex] <- 10^as.numeric(confidences[rowindex])
    confidences[rowindex] <- as.numeric(confidences[rowindex])/length(edges[edges==edges[rowindex]])
    confidences[rowindex] <- log10(as.numeric(confidences[rowindex])) / log10(minimumPvalue)
    if(as.numeric(confidences[rowindex])>1)
    {
      confidences[rowindex] <- 1
    }
    return( as.list (confidences[rowindex]) )
    
  }
  
  #confidences <- lapply(1:length(confidences),adjustConfidence)
  
  confidences <-  unlist(confidences)
  
  #if(FALSE)
  #{
  #changed to lapply
  #		  for(rowindex in 1:length(edges))
  #		  {
  #		  	confidences[rowindex] <- as.numeric(confidences[rowindex]) * log10(minimumPvalue)
  #		  	confidences[rowindex] <- 10^as.numeric(confidences[rowindex])
  #		  	confidences[rowindex] <- as.numeric(confidences[rowindex])/length(edges[edges==edges[rowindex]])
  #		  	confidences[rowindex] <- log10(as.numeric(confidences[rowindex])) / log10(minimumPvalue)
  #		  	if(confidences[rowindex]>1)
  #		  	{
  #		  		confidences[rowindex] <- 1
  #		  	}
  #		  }
  #}
  confidences <- confidences[ !duplicated(edges) ]
  edges <- edges[ !duplicated(edges) ]
  
  #edges <- edges[ order(confidences,decreasing=TRUE) ]
  
  #confidences <- sort(confidences,decreasing=TRUE)
  
  #n.edges <- min(nrow(edges), max.n.edges)
  n.edges <- min(length(edges), max.n.edges)
  
  #browser()
  write.table(data.frame(edges[1:n.edges], confidences[1:n.edges]), 
              col.names=FALSE, row.names=FALSE, sep="\t", quote=FALSE, file=file.sorted.edges)
  
  return(list(edges, confidences))
}
