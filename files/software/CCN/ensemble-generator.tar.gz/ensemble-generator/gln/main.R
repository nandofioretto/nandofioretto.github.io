#DREAM 8 main script
#created by Yang Zhang 2013.9

GLNProgram <- "./glnsp"
dataFile <- "./insilico.csv"
rawDataMatrix <- read.csv(dataFile)[,-c(1:4)]
nodenum <- ncol(rawDataMatrix)
qDataMatrix <- matrix(,nrow(rawDataMatrix), nodenum)
geneNames <- colnames(rawDataMatrix)
TCF <- "./insilico.TCF"
RedoFlag <- FALSE
FuncResult <- "P5SummarizedResults.txt"

source("./Decide_Quantization_Level.R")
source("./d5c4-sort-edges.R")

#step1: quantize data and save into TCF

  qlevels <- findClusterLevel(rawDataMatrix, "mclustresult.txt")
  
  for(index in 1:nodenum)
  {
    qDataMatrix[,index] <-  Ckmeans.1d.dp(rawDataMatrix[,index], qlevels[index])$cluster - 1
  }
  
  write.table("TRAJECTORY_VER2", TCF, col.names=F, row.names=F, quote=F)
  write.table(paste(1,nodenum,0), TCF, col.names=F, row.names=F, quote=F, append=T)
  write.table(t(qlevels), TCF, col.names=F, row.names=F, quote=F, append=T)
  write.table(t(geneNames), TCF, col.names=F, row.names=F, quote=F, append=T)
  write.table(nrow(qDataMatrix), TCF, col.names=F, row.names=F, quote=F, append=T)
  write.table(qDataMatrix, TCF, col.names=F, row.names=F, quote=F, append=T)

#step2: run functional GLN and save result

if(file.exists(FuncResult))
{
  unlink(FuncResult)
}

cmd <- paste(GLNProgram, " -M estimation -R ",  TCF,  " -A 1 -K 0 -J 0 -P 5 -p 1 -X ./P5",sep="")
system(cmd)

#step3: sort edges and generate final result
Sort.Edges.Fast(FuncResult, "insilicosorted.txt" ,10000, "")
sortedFinal <- read.table("insilicosorted.txt")
sortedFinal[,3] <- (sortedFinal[,3] - min(sortedFinal[,3])) / (max(sortedFinal[,3])-min(sortedFinal[,3]))

#step4: generate SIF file
SIFmatrix <- sortedFinal
SIFmatrix[,3] <- SIFmatrix[,2]
SIFmatrix[,2] <- 1
write.table(SIFmatrix, "NMSUSongLab-Network-Insilico.sif", col.names=F, row.names=F, quote=F)

#step5: generate EDA file
EDAmatrix <- SIFmatrix
EDAmatrix[,2] <- paste("(",EDAmatrix[,2],")", sep="")
EDAmatrix[,4] <- "="
EDAmatrix[,5] <- sortedFinal[,3]
write.table("EdgeScore", "NMSUSongLab-Network-Insilico.eda", col.names=F, row.names=F, quote=F)
write.table(EDAmatrix, "NMSUSongLab-Network-Insilico.eda", col.names=F, row.names=F, quote=F, append=T)



