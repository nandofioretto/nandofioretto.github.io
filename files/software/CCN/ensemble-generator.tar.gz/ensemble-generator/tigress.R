#setwd(dir="~/Dropbox/Research/System Biology/GRN inference/Software/ensemble-generator")
source("func_analysis.R")
source("func_datasets.R")
require(infotheo)
require(minet) # For ARACNE, CLR, MRNET and validation

###
  # For all algorithms above the inputs are:
  # - gene_network in {"ecoli", "yeast"}
  # - size in {50, 100, 500}
  # - network_no in {1,2,3,4,5}
  # - dataset in {"ko", "mf", "all"}
###
ccn_Tigress <- 
function ( gene_network=c("ecoli","yeast"), size=100, network_no=c(1,2,3,4,5),  dataset=c("mf", "ko", "all"), 
	sym=F, path_out=NULL , exp='Training')
{
	path.dataset <- get_data.path(gene_network, size, network_no, exp)
	data <- get_data( path.dataset, dataset )
	gold <- get_goldstd( path.dataset, names(data) )
	pairs <- tigress(expdata=data , tflist=NULL , outfile=path_out , K=-1 , alpha=0.2 , nstepsLARS=5 , nbootstrap=100, normalizeexp=TRUE, scoring="area", allsteps=FALSE, verb=FALSE, usemulticore=TRUE)
	pred <- prediction.as_matrix( pairs, names(data) )
	if( !is.null(path_out) ) save_prediction(pred, path_out)
	tbl = ccn_validate(pred, gold, sym)
	return( data.frame(auc.roc( tbl ), auc.pr( tbl ) ) )
}#-

###########################################################
# Below the original tigress.r file
# Should be replaced by require(tigress) once we publish the package
###########################################################



# All needed for TIGRESS in a single file
# JP Vert, Feb 9, 2012

require(lars,quietly=TRUE)

stabilityselection <- 
function(x,y,nbootstrap=100,nstepsLARS=20,alpha=0.2,scoring="area")
{
	# Stability selection in the spirit of Meinshausen&Buhlman
	# JP Vert, 14/9/2010
	
	# INPUT
	# x : the n*p design matrix
	# y : the n*1 variable to predict
	# nbootstrap: number of splits of samples in two sets (i.e., we will average over 2*boostrap realizations)
	# nstepsLARS: number of LARS steps
	# alpha : the alpha parameter for weight randomization in stability selection. Should be between 0 and 1.
	# scoring: how to score a feature. If "area" we compute the area under the stability curve, as proposed by Haury et al. If "max" we just compute the stability curve, as propose by Meinshausen and Buhlmann.
	
	# OUTPUT
	# The stability selection scoring curves, in a matrix where each row is a step (from 1 to nstepsLARS) and each column is a column. 
		
	n <- nrow(x)
	p <- ncol(x)
	halfsize <- as.integer(n/2)
	freq <- matrix(0,nstepsLARS,p)
	
	for (i in seq(nbootstrap)) {
		# Randomly reweight each variable
		xs <- t(t(x)*runif(p,alpha,1))
	
		# Ramdomly split the sample in two sets
		perm <- sample(n)
		i1 <- perm[1:halfsize]
		i2 <- perm[(halfsize+1):n]
	
		# run LARS on each randomized, sample and check which variables are selected
		r <- lars(xs[i1,],y[i1],max.steps=nstepsLARS,normalize=FALSE,trace=FALSE)	
		freq<-freq + abs(sign(r$beta[2:(nstepsLARS+1),]))		
		r <- lars(xs[i2,],y[i2],max.steps=nstepsLARS,normalize=FALSE,trace=FALSE)
		freq<-freq + abs(sign(r$beta[2:(nstepsLARS+1),]))		
	}
		
	# normalize frequence in [0,1] to get the stability curves
	freq <- freq/(2*nbootstrap)

	# Compute normalized area under the stability curve
	if (scoring=="area")
		score <- apply(freq,2,cumsum)/seq(nstepsLARS)
	else
		score <- apply(freq, 2, cummax)
		
	invisible(score)
}



tigress <- 
function(expdata , tflist=NULL , outfile=NULL , K=-1 , alpha=0.2 , nstepsLARS=5 , nbootstrap=100 , normalizeexp=TRUE , scoring="area" , allsteps=FALSE , verb=FALSE , usemulticore=TRUE)
{
	# INPUT
	# expdata : either a matrix of expression, or the name of a file containing it. Each row is an experiment, each column a gene. The gene names are the column names (or are in the first row of the file)
	# tflist : the list of TF, or the name of a file containing them. The TF name should match the names in the gene list of the expression data file. If NULL, then all genes are considered TF.
	# output_filename : where we write prediction. If empty, do not write anything.
	# K : number of edges to return. K=0 means that all edges are returned. 
	# alpha : the alpha parameter for randomization in stability selection. Should be between 0 and 1.
	# nstepsLARS : number of LARS steps to perform in stability selection
	# nbootstrap : number of randomization to perform in stability selection
	# normalizeexp : a boolean indicating whether we should mean center and scale to unit variance the expression data for each gene.
	# scoring : method for scoring a feature in stability selection. If "area", the score is the area under the stability curve up to nstepsLARS steps, as proposed by Haury et al. If "max", the score is the maximum value of the stability curve, as proposed by Meinshausen and Bühlmann in the original paper.
	# allsteps: a boolean indicating whether we should output the solutions for all values of LARS steps up to nstepsLARS, or only for nstepsLARS. It does not cost more computation to compute all solutions.
	# verb : verbose mode. If TRUE, print messages about what we are doing, otherwise remain silent.
	#
	# OUTPUT
	# A dataframe (or list of dataframes if allsteps=TRUE) with the top K predicted edges. First column is the TF, second column the target gene, third column the score. If outfile is provided, the result is also written to the file OUTFILE (if allsteps=FALSE) or to several files OUTFILE1, OUTFILE1, ... (if allsteps=TRUE)
	
	# Check if we can run multicore
	if (usemulticore) {
		require(multicore)
	}
	
	# If needed, load expression data
	if (is.character(expdata))
		expdata <- read.table(expdata, header=1)
	
	# Gene names
	genenames <- colnames(expdata)
	ngenes <- length(genenames)	
	
	# Normalize expression data for each gene
	if (normalizeexp)
		expdata <- scale(expdata)
	
	# If needed, load TF list
	if (is.null(tflist)) {
		# No TF list or file provided, we take all genes as TF
		tflist <- genenames
	} else if (length(tflist)==1 && is.na(match(tflist,genenames))) {
		# If this is a single string which is not a gene name, then it should be a file name
		tflist <- read.table(tflist , header=0)
		tflist <- as.matrix(tflist)[,1]
	}
	
	# Make sure there are no more steps than variables
	if (nstepsLARS>length(tflist)-1){
		nstepsLARS<-length(tflist)-1
		if (nstepsLARS==0){cat('Too few transcription factors! \n',stderr())}
		if (verb){
			cat(paste('Variable nstepsLARS was changed to: ',nstepsLARS,'\n')) 
		}
	}

	# Locate TF in gene list by matching their names
	ntf <- length(tflist)
	tfindices <- match(tflist,genenames)
	if (max(is.na(tfindices))) {
		stop('Error: could not find all TF in the gene list!')
	}
	
	# Number of predictions to return
	Kmax <- ntf*ngenes
	if (K==-1) K<-Kmax
	K <- min(K,Kmax)
	
	# Prepare scoring matrix
	if (allsteps) {
		scorestokeep <- nstepsLARS
	} else {
		scorestokeep <- 1	
	}
	score <- list()
	
	# A small function to score the regulators of a single gene
	stabselonegene <- function(itarget) {
		if (verb) {
			cat('.')
			}

		# Name of the target gene
		targetname <- genenames[itarget]		
		# Find the TF to be used for prediction (all TF except the target if the target is itself a TF)
		predTF <- tfindices[!match(tflist,targetname,nomatch=0)]
		r <- stabilityselection(as.matrix(expdata[,predTF]), as.matrix(expdata[,itarget]), nbootstrap=nbootstrap, nsteps=nstepsLARS, alpha=alpha)
		sc <- array(0,dim=c(ntf,scorestokeep),dimnames = list(tflist,seq(scorestokeep)))
		if (allsteps) {
			sc[predTF,] <- t(r)
		} else {
			sc[predTF,] <- t(r[nstepsLARS,])
		}
		invisible(sc)
	}
	
	# Treat target genes one by one
	if (usemulticore) {
		score <- mclapply(seq(ngenes),stabselonegene,mc.cores=2)
	} else {
		score <- lapply(seq(ngenes),stabselonegene)	
	}
	# Rank scores
	edgepred <- list()
	for (i in seq(scorestokeep)) {
		# Combine all scores in a single vectors
		myscore <- unlist(lapply(score,function(x) x[,1,drop=FALSE]))
		ranki <- order(myscore,decreasing=TRUE)[1:K]
		edgepred[[i]] <- data.frame(list(tf=tflist[(ranki-1)%%ntf+1] , target=genenames[(ranki-1)%/%ntf+1] , score=myscore[ranki]))
	}
	
	# Print and return the result
#	if (allsteps) {
#		if (!is.null(outfile)) {
#			for (i in seq(length(edgepred))) {
#				write.table( edgepred[[i]], file=paste(outfile,i,sep=''), quote=FALSE, row.names=FALSE, col.names=FALSE, sep='\t')
#			}
#		}
#		return(edgepred)
#	} else {
#		if (!is.null(outfile)) {
#			write.table( edgepred[[1]], file=outfile, quote=FALSE, row.names=FALSE, col.names=FALSE, sep='\t')
#		}
		return(edgepred[[1]])
#	}
}
