/*
	Copyright 2011 Robert Küffner Licensed under the
	Educational Community License, Version 2.0 (the "License"); you may
	not use this file except in compliance with the License. You may
	obtain a copy of the License at
	
	http://www.osedu.org/licenses/ECL-2.0

	Unless required by applicable law or agreed to in writing,
	software distributed under the License is distributed on an "AS IS"
	BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
	or implied. See the License for the specific language governing
	permissions and limitations under the License.
*/

#include <iostream>
#include <math.h>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <typeinfo>
#include <stdlib.h>
using namespace std;

#pragma mark CLASS DEFINITIONS

class sparse {
public:
  double val;
  long idx;
  sparse(double v=0, long p=0) : val(v), idx(p) {} 
};

struct chip 
{
  long exp; 
  sparse *pert;
  long	treat;
  long	*del, *over;
  double time;
  long cmembers, crepls, fmembers;
  long *ctrl;
  bool first, useextra;
  double *vals, *fchg, *mean;
  double *extra;
  long	cextra;
  char	*name;
};

struct gene {
  long	 over, del;
  string name;
};

#include "anova_global.cpp"

///////////////////////////////////////////////////////////////////////////////////////

class netcorr {
public:
  long cgenes, cchips;	// Number of genes, measured chips
  long cgroups, crepls; // Number of experimental conditions, replicate groups
  long fchips, fgroups, frepls; // Same for fold changes
  long tfact;	// Number of transcription factors
  chip *chips;	// Information on chips
  gene *genes;	// Information on genes
  char *name;	// Rootname of input files
  double wko;	// TF perturbation weights
	

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// read data and features
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark READ
	
  // check if TF is perturbed in a fold change comparing experiment i with experiment j
  bool perturbed(long g, long i, long j) 
  {
    return (chips[i].useextra) ? pert(g, i) : (pert(g, i) && !pert(g, j));
  }//-
  
  bool pert(long g, long j) 
  {
    chip *c = &chips[j];
    if (c->del && genes[g].del)
      for (long *i=c->del; *i>=0; ++i)
	if (*i == g)
	  return true;
    if (c->over && genes[g].over)
      for (long *i=c->over; *i>=0; ++i)
	if (*i == g)
	  return true;
    return false;
  }
  
  // copy perturbation information to genes
  void addgenes(void) 
  {	
    for (long j=0; j<cchips; j+=chips[j].crepls) {
      chip *c = &chips[j];
      if (c->del)
	for (long *i=c->del; *i>=0; ++i)
	  genes[*i].del++;
      if (c->over)
	for (long *i=c->over; *i>=0; ++i)
	  genes[*i].over++;
    }
  }
  
  // read chip features
  void rdfeat(char *name, const char *ext) 
  {
    long *ctrls  = new long[cchips];
		
    FILE *f = OpenInFile("%s%s", name, ext);
    char line[BUFSIZE], *n; 
    fgets(line, BUFSIZE, f);
    chip *c = chips, *l=0;
    long grpmembers=1, expmembers=0, *ctr=ctrls;
    cgroups=crepls=0;
    fgroups=frepls=fchips=0;
    while (fgets(line, BUFSIZE, f)) {
      // Experiment, Perturbation + Level, Treatment, Deleted genes, Overexpressed genes, Time, Replicates
      n = rdval (c->exp,   line);
      n = rdslst(c->pert,  n);
      n = rdval (c->treat, n);
      n = rdlist(c->del,   n);
      n = rdlist(c->over,  n);
      n = rdval (c->time,  n);
      n = rdval (c->crepls,n);
      n = rdval (c->cextra, n);
      c->name = stralloc(n);
      
      if (c->crepls==1) {
	++crepls;
	c->first = true;
      } else {
	c->first = false;
      }
      update(&c->crepls);
      
      // Chip ist Kontrolle
      if (!c->pert && !c->del &&! c->over)
	*ctr++ = c-chips;
      c->ctrl = 0;
      
      if (l && c->exp==l->exp && cmpslst(c->pert,l->pert) && c->treat==l->treat && cmplist(c->del, l->del) && cmplist(c->over, l->over)) {
	// Gleiche Condition wie letzter Chip
	c->cmembers = ++grpmembers;
	update(&c->cmembers);
      } else {
	// Neue Condition
	c->cmembers = 1;
	grpmembers = 1;
	++cgroups;
      }
      if (l && c->exp!=l->exp) {
	mapctrl(c-expmembers, expmembers);
	expmembers = 0;
      }
      ++expmembers;
      
      l=c++;
    }	
    mapctrl(c-expmembers, expmembers);
    *ctr = -1;
  }
  
  // read expression data
  void rddata(const char *name, const char *ext) 
  {
    cchips = rowcnt(name, ext) - 1; 
    chips  = new chip[cchips];
    FILE *f = OpenInFile("%s%s", name, ext);
    char line[BUFSIZE];
    fgets(line, BUFSIZE, f);
    cgenes = strcnt(line, '\t')+1;

    string genes_names = line;
    size_t found = 0;
    genes = new gene[cgenes];
    for (long i=0; i<cgenes; ++i) {
      genes[i].del = 0;
      genes[i].over = 0;
      size_t start = found;
      found = genes_names.find_first_of("\t",found+1);
      if (found == string::npos) found = genes_names.size() - 1;
      if ( start > 0 ) start++;
      genes[i].name = genes_names.substr (start, found - start);
    }

    // Daten einlesen
    chip *c = chips;
    int kk = 0;
    while (fgets(line, BUFSIZE, f)) {
      char *n = line;
      c->vals = new double[cgenes];
      c->mean = new double[cgenes];
      c->fchg = new double[cgenes];
      c->extra = 0;
      long g=0;
      
      do {
	c->vals[g++] = atof(n);
	//c->vals[g++] = log(pow(2, atof(n))+50)/log(2);
      } while ((n = rdcol(n)));
      ++c;
    }
  }
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Berechnung von ranks, fchg, mean, Kontrollen
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark BASIC CALCULATIONS

	// compute replicate means and fold changes
	void fchgmean(void) {
		long j, k;
		for (chip *c=chips; c<chips+cchips; c+=c->crepls) {
			for (j=0; j<cgenes; ++j) {
				c->mean[j]=0;
				for (k=0; k<c->crepls; ++k)
					c->mean[j] += (c+k)->vals[j];
				c->mean[j] /= c->crepls;
			}
			if (c->cextra>0) {
				c->extra = new double[cgenes];
				for (j=0; j<cgenes; ++j) {
					c->extra[j]=0;
					for (k=0; k<c->cextra; ++k)
						c->extra[j] += (c+k)->vals[j];
					c->extra[j] /= c->cextra;
				}
			}
		}

		for (chip *c = chips; c<chips+cchips; ++c)
			if (c->ctrl) {
				for (j=0; j<cgenes; ++j) 
					c->fchg[j] = c->vals[j] - ((c->useextra) ? chips[c->ctrl[0]].extra[j] : chips[c->ctrl[0]].mean[j]);
			}
	}

	// count perturbations contained in c1 but not in c2
	long extraslst(sparse *c1, sparse *c2) {
		if (!c1)
			return 0;
		long extra = 0;
		if (c2)
			while (c1->idx>=0 && c2->idx>=0) {
				if (c1->idx == c2->idx) {
					++c1;
					++c2;
				} else if (c1->idx < c2->idx) {
					++c1;
					++extra;
				} else {
					++c2;
				}
			}
		while (c1->idx>=0) {
			++c1;
			++extra;		
		}
		return extra;
	}
	
	long extralist(long *c1, long *c2) {
		if (!c1)
			return 0;
		long extra = 0;
		if (c2)
			while (*c1>=0 && *c2>=0) {
				if (*c1 == *c2) {
					++c1;
					++c2;
				} else if (*c1 < *c2) {
					++c1;
					++extra;
				} else {
					++c2;
				}
			}
		while (*c1>=0) {
			++c1;
			++extra;		
		}
		return extra;
	}
	
  long extracond(chip *c1, chip *c2) {
	  return extraslst(c1->pert, c2->pert) + extralist(c1->del, c2->del) + extralist(c1->over, c2->over) + (c1->treat>=0 && c2->treat<0);
	}

  // map controls for fold change computations
  void mapctrl(chip *cf, long cnt) {
    vector<long>::iterator it;
    long i;
    vector<long> ctrl;
    chip *cl = cf+cnt;
    // Find for c1 best control c2
    for (chip *c1=cf; c1<cl; c1+=c1->crepls) {		
      ctrl.clear();
      long cond = 0, best = -1, c, extra=-1;
      double time = 1e9, t1, t2;
      for (chip *c2 = cf; c2<cl; c2+=c2->crepls) {
	// control c2 must not contain additional perturbations
	if (c1 != c2 && !extracond(c2, c1)) {
	  // Best control c2, if c1 contains maximum number of extra perturbations
	  // Secondary critereon: find most similar time point
	  // If c1, c2 contain the same perturbations, select c2 at smallest time point
	  c = extracond(c1, c2);
	  t1 = (c) ? fabs(c1->time - c2->time) : c2->time;
	  if (c || c1->time > t1) {
	    for (it=ctrl.begin(); it!=ctrl.end(); ++it)
	      if (!extracond(c2, &chips[*it]) && !extracond(&chips[*it], c2)) {
		t2 = (c) ? fabs(c1->time - chips[*it].time) : chips[*it].time;
		if (t1<t2)
		  *it = c2-chips;
		break;
	      }
	    if (it==ctrl.end())
	      ctrl.push_back(c2-chips);
	    
	    if (c>cond || (c==cond && t1<time)) {
	      cond = c;
	      time = t1;
	      best = c2-chips;
	    }
	  }
	}
	if (c2->cextra>0)
	  extra = c2-chips;
      }
      c1->useextra = false;
      if (best<0 && extra>=0) {
	ctrl.push_back(extra);
	best = extra;
	c1->useextra = true;
      }
      if (best>=0) {
	chip *c = c1;
	c->ctrl = new long[ctrl.size()+1];
	c->ctrl[0] = best;
	i = 1;
	for (vector<long>::iterator j=ctrl.begin(); j!=ctrl.end(); ++j)
	  if (*j!=best)
	    c->ctrl[i++] = *j;
	c->ctrl[ctrl.size()] = -1;
	
	for (i=1; i<c1->crepls; ++i)
	  (++c)->ctrl = c1->ctrl;
      }
    }
    
    // count chips, replicate sets, and conditions
    long members = 0;
    for (chip *c=cf; c<cl; c += c->crepls)
      if (c->ctrl) {
	fchips += c->crepls;
	++frepls;
	if (c!=cf && (!cmpslst(c->pert,(c-1)->pert) || !c->treat==(c-1)->treat || !cmplist(c->del, (c-1)->del) || !cmplist(c->over, (c-1)->over))) {
	  ++fgroups;
	  for (i=0; i<members; ++i)
	    (c-i-1)->fmembers = members;
	  members = 0;
	}
	members += c->crepls;
      } else {
	for (i=0; i<members; ++i)
	  (c-i-1)->fmembers = members;
	members = 0;
      }
    
    for (i=0; i<members; ++i)
      (cl-i-1)->fmembers = members;
  }//-

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Berechnung von ANOVAs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark ANOVAS

/*	Four sums are computed via
	totsum2		=	x_...
	totcell2	=	x_ijk
	totcol2		=	x_.j.
	totweight	=	total weight of cells in data matrix
 
	"Sums of squares" (sums of squared deviations) are computed via 
	SS_A	=	totcol2  - totsum2
	SS_T	=	totcell2 - totsum2
 
	Finally, eta-squared is computed as
	etasq	=	SS_A / SS_T
*/
  double ano(long *gp, bool inv) 
  {
    double totsum=0, totcell2=0, totcol2=0, totweight=0;
    for (long c, msr=0; msr<cchips; msr+=c) {
      c = chips[msr].crepls;
      // For a given measurement condition msr, iterate valid control conditions ctr
      for (long ctr, *p = chips[msr].ctrl; p && (ctr=*p)>=0; ++p) {
	double colweight=0, colmean=0;
	for (long g, *j=gp; (g=*j)>=0; ++j) {
	  // Iterate replicated measurements
	  double w = (g==gp[1] && perturbed(gp[1], msr, ctr)) ? wko : 1;
	  for (long k=0; k<c; ++k) {
	    // compute fold change against specific control mean or ("useextra") experiment mean
	    double d = chips[k+msr].vals[g]-((chips[msr].useextra) ? chips[ctr].extra[g] : chips[ctr].mean[g]);
	    // check for correlation or ("inv") anti-correlation
	    if (g==gp[1] && inv)
	      d *= -1;
	    // compute mean and variance
	    colmean += w*d;
	    totcell2 += w*d*d;
	    colweight += w;
	  }
	}
	totsum  += colmean;
	totcol2 += colmean*colmean/colweight;
	totweight += colweight;
      }
    }
    double totsum2 = totsum*totsum/totweight;
    double SS_A    = totcol2  - totsum2;
    double SS_T    = totcell2 - totsum2;
    return SS_A / SS_T;
  }//-

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark WRITE RESULTS	

  // Analyze pairs of genes
  void pairofgenes(void) {
    
    FILE *f = OpenOutFile("%s.pair", name);
    long c = tfact*cgenes-tfact, s=0, g[3]={0,0,-1};
    for (long g1=0; g1<cgenes; ++g1) {
      g[0] = g1;
      fprintf(stderr, "\r pairs %ld  ", 100*s/c);
      for (long g2=0; g2<tfact; ++g2) 
      {
	g[1] = g2;
	
	if (g1 != g2) 
	{
	  double kpos = ano(g, false);
	  //				    double kinv = ano(g, true);
	  double kopt = kpos;
	  //					double kopt = (kpos>kinv)?kpos:kinv;
	  // fprintf(f, "G%ld\tG%ld\t%.6f\n", g2+1, g1+1, kopt);
	  fprintf(f, "%s\t%s\t%.6f\n", genes[ g2 ].name.c_str(), genes[ g1 ].name.c_str(), kopt);
	}
	++s;
      }
    }
    fprintf(stderr, "\n");
    fclose(f);		
  }
  
  netcorr(long argc, char * const argv[]) 
  {
    if (argc<=3) Error("netcorr not enough param");
    name = argv[ 1 ];
    wko  = atof( argv[ 2 ] );
    tfact = atoi( argv[ 3 ] );
    rddata( name, "_expression_data.tsv");
    rdfeat( name, "_chip_features.tsv");
    fchgmean();
    addgenes();

    fprintf(stderr, "genes=%ld, chips=%ld/%ld, groups=%ld/%ld, repls=%ld/%ld\n", cgenes, cchips, fchips, cgroups, fgroups, crepls, frepls); 
  }
};

///////////////////////////////////////////////////////////////////////////////////////

int  main (int argc, char * const argv[]) {
  netcorr net(argc, argv);
  net.pairofgenes();
  return 0;
}
