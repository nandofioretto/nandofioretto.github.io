
get.params.PARAMS <- function(data.path, tfs.path=NA, meta.path=NA, n_bootstraps=10)
{
	PARAMS              = list()
	PARAMS[["general"]] = list()
	PARAMS[["clr"]]     = list()
	PARAMS[["lars"]]    = list()
	PARAMS[["output"]]  = list()
	
	PARAMS[["general"]][["d.path"]] <- data.path
	PARAMS[["general"]][["tfs.path"]] <- tfs.path
	PARAMS[["general"]][["scripts.path"]] <- "GPDREAM_Inferelator"
	PARAMS[["general"]][["f.path"]] <- meta.path
	PARAMS[["general"]][["numBoots"]] <- n_bootstraps
	PARAMS[["general"]][["tau"]] <- 10
	PARAMS[["general"]][["num.inters.out"]] <- Inf
	PARAMS[["general"]][["processorsNumber"]] <- 1
  PARAMS[["general"]][["delT_max"]] = PARAMS[["general"]][["tau"]] * 3
  PARAMS[["general"]][["delT_min"]] = PARAMS[["general"]][["tau"]] / 3
  PARAMS[["lars"]][["nCv"]] = 10
  PARAMS[["clr"]][["n.bins"]] = 10
  PARAMS[["clr"]][["speedUp"]] = F
  PARAMS[["clr"]][["numGenes"]] = 1000
  PARAMS[["general"]][["z_score_co"]] = 2
  PARAMS[["general"]][["qtile_co"]] = 1

  PARAMS[["general"]][["MCZ_fltr_prcntile"]] = .5
  PARAMS[["general"]][["inf.version"]] = "nwInf.1.2"
  
  x = unlist(strsplit(date()," "))
  PARAMS[["general"]][["date"]] = paste(x[2],x[3],x[5],x[4],sep="_")
  PARAMS[["general"]][["use_t0_as_steady_state"]] = FALSE
  PARAMS[["general"]][["use_mixCLR"]] = TRUE #for DREAM4
  PARAMS[["general"]][["use_delt_bigger_than_delT_max_as_steady_state"]] = TRUE
  PARAMS[["general"]][["percentCoverage"]] = 100
	
	PARAMS[["lars"]][["max_single_preds"]] <- 25
  PARAMS[["lars"]][["lambda"]] = c(0, 1, 100)   
  PARAMS[["lars"]][["nCv"]] = 10
  PARAMS[["lars"]][["what_final_design_response_matrix"]] = 'all' 
  
  PARAMS[["clr"]][["what_final_design_response_matrix"]] = 'all' 
  PARAMS[["clr"]][["response_matrix"]]  = "inf_1_all_intervals"
  PARAMS[["lars"]][["response_matrix"]] = "inf_1_all_intervals"
  PARAMS[["clr"]][["design_matrix"]]  = "time_delayed"
  PARAMS[["lars"]][["design_matrix"]] = "time_delayed"

  return (PARAMS)
  
}


get.params.INPUT <- function(PARAMS)
{
	INPUT              = list()
	INPUT[["general"]] = list()
	INPUT[["clr"]]     = list()
	INPUT[["lars"]]    = list()
  
  data.path <- PARAMS$general$d.path
  meta.path <- PARAMS$general$f.path
  tfs.path  <- PARAMS$general$tfs.path
  
  x = makeDataGP(data.path, meta.path, tfs.path)
  INPUT[["general"]][["dataset"]]            = x[["ratios"]]
  INPUT[["general"]][["clusterStack"]]       = x[["cS"]]
  INPUT[["general"]][["colMap"]]             = x[["cM"]]
  INPUT[["general"]][["tf_names"]]           = x[["tfs"]]
  INPUT[["general"]][["knockOutFilterList"]] = x[["koFilt"]]
  INPUT[["general"]][["knockOutCombine"]]    = x[["koComb"]]
 
  params = 
  c(PARAMS[["general"]][["delT_min"]],
    PARAMS[["general"]][["delT_max"]],  
    PARAMS[["clr"]][["design_matrix"]], "all_intervals",
    PARAMS[["general"]][["use_t0_as_steady_state"]],   
    PARAMS[["general"]][["use_delt_bigger_than_delT_max_as_steady_state"]])

  # get clr design matrix: 1- steady_state, 2- time_series
  x = get_usr_chosen_design_matrix(
    INPUT[["general"]][["colMap"]],
    INPUT[["general"]][["dataset"]],
    params)
    
  INPUT[["clr"]][["design_matrix_steady_state"]] = x[[1]]
  INPUT[["clr"]][["design_matrix_time_series"]] = x[[2]]
 
 
  params = 
    c(PARAMS[["general"]][["delT_min"]],
      PARAMS[["general"]][["delT_max"]],
      PARAMS[["lars"]][["design_matrix"]], 
      'all_intervals',	
      PARAMS[["general"]][["use_t0_as_steady_state"]],
      PARAMS[["general"]][["use_delt_bigger_than_delT_max_as_steady_state"]])
      
  # get lars design matrix: 1- steady_state, 2- time_series
  x = get_usr_chosen_design_matrix(
    INPUT[["general"]][["colMap"]],  as.matrix(as.data.frame(INPUT[["general"]][["dataset"]])
    [INPUT[["general"]][["tf_names"]],]),
    params)
    
  INPUT[["lars"]][["design_matrix_steady_state"]] = x[[1]]
  INPUT[["lars"]][["design_matrix_time_series"]] = x[[2]]

  #get clr response matrix
  params =  
    c(PARAMS[["general"]][["delT_min"]],
      PARAMS[["general"]][["delT_max"]],
      PARAMS[["clr"]][["response_matrix"]], 
      PARAMS[["general"]][["tau"]], 			PARAMS[["general"]][["use_t0_as_steady_state"]],
      PARAMS[["general"]][["use_delt_bigger_than_delT_max_as_steady_state"]])
      
  if( is.null(INPUT[["general"]][["redExp"]]))
  {
  	x = get_usr_chosen_response(
      INPUT[["general"]][["colMap"]], 
      INPUT[["general"]][["dataset"]], 
      params)
  }
  else
  {
  	x = get_usr_chosen_response(INPUT[["general"]][["colMap"]],
      INPUT[["general"]][["redExp"]], params)
  }

  INPUT[["clr"]][["response_matrix_steady_state"]] = x[[1]]
  INPUT[["clr"]][["response_matrix_time_series"]] = x[[2]]

  #get lars response matrix
  params =  
    c(PARAMS[["general"]][["delT_min"]],
      PARAMS[["general"]][["delT_max"]],
      PARAMS[["lars"]][["response_matrix"]], 
      PARAMS[["general"]][["tau"]], 			PARAMS[["general"]][["use_t0_as_steady_state"]],
      PARAMS[["general"]][["use_delt_bigger_than_delT_max_as_steady_state"]])
      
  if( is.null(INPUT[["general"]][["redExp"]]))
  {
  	x = get_usr_chosen_response(
      INPUT[["general"]][["colMap"]], 
      INPUT[["general"]][["dataset"]], 
      params)
  }
  else
  {
  	x = get_usr_chosen_response(
      INPUT[["general"]][["colMap"]], 
      INPUT[["general"]][["redExp"]], 
      params)
  }
						 
  INPUT[["lars"]][["response_matrix_steady_state"]] = x[[1]]
  INPUT[["lars"]][["response_matrix_time_series"]] = x[[2]]

  # make final design/response matrices for clr
  if(any(is.na(INPUT[["clr"]][["response_matrix_steady_state"]]))){
  	PARAMS[["clr"]][["what_final_design_response_matrix"]] = "ts"
  }else if(any(is.na(INPUT[["clr"]][["response_matrix_time_series"]]))){
  	PARAMS[["clr"]][["what_final_design_response_matrix"]] = "ss"
  }

  x = make_final_design_and_response_matrix(
    INPUT[["clr"]][["design_matrix_steady_state"]] , 
  	INPUT[["clr"]][["design_matrix_time_series"]] , 
  	INPUT[["clr"]][["response_matrix_steady_state"]], 
  	INPUT[["clr"]][["response_matrix_time_series"]], 
  	PARAMS[["clr"]][["what_final_design_response_matrix"]])								  
  INPUT[["clr"]][["response_matrix"]] = x[[1]]
  INPUT[["clr"]][["design_matrix"]] = x[[2]]

  # make final design/response matrices for lars
  if(any(is.na(INPUT[["lars"]][["response_matrix_steady_state"]]))){
  	PARAMS[["lars"]][["what_final_design_response_matrix"]] = "ts"
  }else if(any(is.na(INPUT[["lars"]][["response_matrix_time_series"]]))){
  	PARAMS[["lars"]][["what_final_design_response_matrix"]] = "ss"
  }

  x = make_final_design_and_response_matrix(
    INPUT[["lars"]][["design_matrix_steady_state"]] ,
    INPUT[["lars"]][["design_matrix_time_series"]] , 
    INPUT[["lars"]][["response_matrix_steady_state"]], 
    INPUT[["lars"]][["response_matrix_time_series"]], 
    PARAMS[["lars"]][["what_final_design_response_matrix"]]) 
      
  INPUT[["lars"]][["response_matrix"]] = x[[1]]
  INPUT[["lars"]][["design_matrix"]] = x[[2]]

  # remove helper variable
  rm(x,params)
  
  return (INPUT)
}


inferelator_pipeline <- function ( INPUT, PARAMS )
{
  b = 1 # this follow current iteration/bootstrap number
  N_b = PARAMS$"general"$"numBoots" # number of bootstraps
  btch_size = 10
  percentCoverage <- PARAMS[["general"]][["percentCoverage"]] # (usually 100)
  lambda = PARAMS[["lars"]][["lambda"]]
  Y_clr = INPUT[["clr"]][["response_matrix"]]
  X_clr = INPUT[["clr"]][["design_matrix"]]
  Y_lars = INPUT[["lars"]][["response_matrix"]]
  X_lars = INPUT[["lars"]][["design_matrix"]]
  betaList = vector("list", N_b)
  modelErrorList = vector("list", N_b)
  allResults <- list()

  while (b <= N_b) 
  {
    Pi_s_clr = createPermMatrix(cS=INPUT[["general"]][["clusterStack"]], 
                 allConds = colnames(Y_clr), 
                 getOrigPerm = (b==1), 
                 percentCoverage = percentCoverage,
                 redExp=INPUT$general$redExp)
    Pi_s_lars = Pi_s_clr
    Y_clr_p = permuteCols(Y_clr, Pi_s_clr)
    X_clr_p = permuteCols(X_clr, Pi_s_clr)
  
    #----added by Alex----9/19-----------#
    #the code below speeds up the calculation of Ms and Ms_bg by
    #making a smaller design matrix
    if( PARAMS$clr$speedUp)
    {
  	  if( PARAMS$clr$numGenes < nrow(Y_clr) )
       {
  	    tfIx <- which(rownames(X_clr_p) %in% INPUT$general$tf_names)
  	    otherIx <- c(1:nrow(X_clr_p))[-tfIx]
  	    rIx1 <- c(tfIx,sample( otherIx, PARAMS$clr$numGenes - 
          length(tfIx),replace=F))
      }
      else {
  		rIx1 <- 1:nrow(Y_clr)
  	  }
    }

    # dynamic MI scores stored here
    if( PARAMS$clr$speedUp) x_clr_tmp <- X_clr[rIx1,]
    else x_clr_tmp <- X_clr

    Ms <- calc_MI_one_by_one_parallel( Y_clr, x_clr_tmp, Pi_s_clr,
        processorsNumber = PARAMS[["general"]][["processorsNumber"]], 
        n.bins=PARAMS[["clr"]][["n.bins"]])

      # static MI scores stored here
    Ms_bg <- calc_MI_one_by_one_parallel( X_clr, x_clr_tmp, Pi_s_clr,
         processorsNumber = PARAMS[["general"]][["processorsNumber"]],
         n.bins=PARAMS[["clr"]][["n.bins"]])

    if( PARAMS$clr$speedUp & 
      (PARAMS$clr$numGenes < nrow(Y_clr) ))
    {
      x <- cbind(rIx1, 1:PARAMS$clr$numGenes)
      for(i in 1:nrow(x))
      {
      	Ms[x[i,1],x[i,2]] <- 0
        Ms_bg[x[i,1],x[i,2]] <- 0
      }
    }
    else {
      diag(Ms) = 0
      diag(Ms_bg) = 0
    }

    if( PARAMS[["general"]][["use_mixCLR"]] )
    {
      Z_nt_fltrd = mixed_clr_parallel(Ms_bg,Ms,
        processorsNumber=PARAMS[["general"]][["processorsNumber"]])
    } else {
      Z_nt_fltrd = clr(Ms)
    }
  
    if( PARAMS$clr$speedUp ) {
      colnames(Z_nt_fltrd) <- rownames(X_clr)[rIx1]
    }else{
      colnames(Z_nt_fltrd) <- rownames(X_clr)
    }
    rownames(Z_nt_fltrd) <- rownames(X_clr)
  
    Z <- Z_nt_fltrd[,INPUT[["general"]][["tf_names"]]]

  ##  .-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.
  # 6- apply MCZ filter -- i.e. remove unlikely reg inters from further consideration by mixedCLR (and thus from Inf)
  ##  .-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.***.-.-.
  
    # filter cutoff
    # KOs first
    ct = PARAMS[["general"]][["MCZ_fltr_prcntile"]]
	
    if( !is.null(INPUT$general$knockOutFilterList)) 
    {
      x <- INPUT$general$knockOutFilterList
      tfs <- names( x )
      if( !is.null(tfs) )
        for(i in 1:length(x)) 
        {
          bad.trgts <- names(x[[ tfs[i] ]])[which(x[[ tfs[i] ]] < 
                       quantile(x[[ tfs[i] ]],ct))]
          Z[bad.trgts,tfs[i]] <- 0
        }
    }

    # make sure Z has at least two non-zero predictors for each target (without allowing self regulation)
  	n.pred.per.trgt <- apply(Z,1,function(i) length(which(i!=0)))
  	ix <- which(n.pred.per.trgt<2)
  	if(length(ix)>0)
    {
  		min.z <- min(Z[which(Z!=0)])
  		ix <- which(n.pred.per.trgt==1)
  		if(length(ix)>0) {
  			for(k in 1:length(ix)) {
  				ix.replacable <- which(Z[ix[k],]==0)
  				ix.bad <- which(names(ix.replacable) %in% names(ix[k]))
  				if(length(ix.bad)>0) {
  					ix.replacable <- ix.replacable[-ix.bad]					
  				}
  				Z[ix[k],which(Z[ix[k],]==0)[ix.replacable[1]]] <- min.z
  			}
  		}
  		ix <- which(n.pred.per.trgt==0)		
  		if(length(ix)>0){
  			for(k in 1:length(ix)){
  				ix.replacable <- which(Z[ix[k],]==0)
  				ix.bad <- which(names(ix.replacable) %in% names(ix[k]))
  				if(length(ix.bad)>0){
  					ix.replacable <- ix.replacable[-ix.bad]					
  				}
  				Z[ix[k],which(Z[ix[k],]==0)[ix.replacable[1:2]]] <- min.z
  			}
  		}
  	}

    nCv <- min(10,floor(ncol(Y_lars)/2))
    x = calc_ode_model_weights_parallel(Xs = X_lars,Y = Y_lars, Pi = Pi_s_lars,
         M1=Z, nS = PARAMS[["lars"]][["max_single_preds"]], nCv = nCv,
  	     lambda=lambda, 
         processorsNumber = PARAMS[["general"]][["processorsNumber"]], 
         plot.it = FALSE, plot.file.name = "",verbose = FALSE)
  
    betaList[[b]] = x[[1]]
    modelErrorList[[b]] = t(x[[2]])
  
    betaList[[b]] = add_weight_beta(bL=betaList[[b]],
                    model_errors=modelErrorList[[1]],
                    n=nrow(Y_lars),
                    pS=nrow(X_lars),pD=0,col=4,col_name = "prd_xpln_var" )
    betaList[[b]] = add_zscore(bL=betaList[[b]],M1=Z, M2=NULL,
                    col=5,col_name = "clr_zs")
    betaList[[b]]=  add_bias_term(bL=betaList[[b]],bT=t(x[[3]]),
                    col=6,col_name = "bias")
    rm(x)

    beta.mat = combine_l2_net_res(betaList[[b]],modelErrorList[[b]],col="beta")
    beta.mat = unsparse(beta.mat ,matrix(0,dim(Z)[1],dim(Z)[2]) )
    pred.mat.lnet =   combine_l2_net_res(betaList[[b]],
      modelErrorList[[b]],col="prd_xpln_var")
    pred.mat.lnet = unsparse(pred.mat.lnet,matrix(0,dim(Z)[1],dim(Z)[2]) )
    pred.mat.bias = combine_l2_net_res(betaList[[b]],
      modelErrorList[[b]],col="bias")
    base.vec <- sort(Z,decreasing=T)
    base.vec <- base.vec[which(base.vec>0)]
    pred.mat.lnet.mixCLR = combine_mtrcs_new(Z,pred.mat.lnet,base.vec=base.vec)
    if(!is.null(INPUT$general$knockOutCombine))
    {
   		z.annot.ko <- INPUT$general$knockOutCombine
   	 	z.annot.ko[which(z.annot.ko < PARAMS[["general"]][["z_score_co"]])] <- 0
    	pred.mat.mixCLR.ko <- combine_mtrcs_new(pred.mat.lnet.mixCLR, 
        z.annot.ko, base.vec=base.vec)
  	}else {
  		pred.mat.mixCLR.ko = NULL
  	}

    allResults[[b]] <- list()
    allResults[[b]][["MixCLR.Inf"]] <- pred.mat.lnet.mixCLR
    allResults[[b]][["MixCLR.Inf.ko"]] <- pred.mat.mixCLR.ko
    b = b + 1
  }

  if(is.null(allResults[[1]][["MixCLR.Inf.ko"]]))
  {
  	median.conf.scores <- getMedianNetworkFromBootstraps(allResults, "MixCLR.Inf")
  	dimnames(median.conf.scores) <- dimnames(allResults[[1]][["MixCLR.Inf"]])
  }else{
  	median.conf.scores <- getMedianNetworkFromBootstraps(allResults, "MixCLR.Inf.ko")
  	dimnames(median.conf.scores) <- dimnames(allResults[[1]][["MixCLR.Inf.ko"]])
  }
  
  return(median.conf.scores)
  
}