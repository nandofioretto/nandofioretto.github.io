/* File adapted from ARACNE v. 2.0 */
#ifndef GN_MARKER_H
#define GN_MARKER_H

#include "globals.h"
using namespace __gnu_cxx; // GCC 3.1 and later
using namespace std;

/***********************************************************
 * a marker describes a gene in a detailed way, including
 * attributes not useful in other places.
 */
class Marker
{
  int idnum;
  std::string accnum;
  std::string label;
  double var;
  double bandwidth;
  bool isActive;
  bool isControl;

public:
 Marker( int id = 0, const string & a = "", const string & l = "", double sigma = 0.0, double bw = 0.0,
	 bool active = true, bool control = false ) : idnum( id ), accnum( a ), label( l ), var( sigma ), bandwidth( bw ), isActive( active ),
    isControl( control ) { }

  int Get_ID() const {return idnum; }
  const std::string & Get_Accnum() const {return accnum; }
  const std::string & Get_Label() const {return label; }
  void Set_ID( int id ) {idnum = id; }
  void Set_Accnum( std::string & a ) {accnum = a; }
  void Set_Label( std::string & l ) {label = l; }
  void Set_Var ( double v ) {var = v; }
  double Get_Var() {return var; } 
  void Set_Bandwidth ( double bw ) {bandwidth = bw;}
  double Get_Bandwidth() {return bandwidth; }
  bool hasAccession( std::string & a ) {return ( accnum.compare(a)==0 ); }
  void Enable() {isActive = true; }
  void Disable() {isActive = false; }
  bool Enabled() const {return ( isActive ); }
  void set_Control() {isControl = true; }
  void set_No_Control() {isControl = false; }
  bool Is_Control() {return ( isControl ); }

  friend std::ostream & operator << ( std::ostream & out_file, const Marker & m ) {
    out_file << "(";
    out_file << m.label << "; " << m.accnum << "; ";
    out_file << m.idnum << "; ";
    if ( m.isActive )
      out_file << "Active; ";
    else
      out_file << "Not Active; ";
    if ( m.isControl )
      out_file << "Control)";
    else
      out_file << "Not Control)";
    return ( out_file );
  }

};

#endif
