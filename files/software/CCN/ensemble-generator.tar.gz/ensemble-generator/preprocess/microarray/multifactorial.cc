#include <cassert>
#include <sstream>
#include "multifactorial.h"
#include "microarray.h"
#include "probe.h"

using namespace std;

Multifactorial::Multifactorial()
{
  type = Microarray::EXP_MULTIFACTORIAL;
}

Multifactorial::Multifactorial (string path) { 
  type = Microarray::EXP_MULTIFACTORIAL;
  Multifactorial::init (path);
  Microarray::compute_variance();
  Microarray::compute_bandwidth();
}//-

Multifactorial::Multifactorial 
(int argc, char* argv[], int& parse_pos) 
{
  type = Microarray::EXP_MULTIFACTORIAL;
  string data_path;
  for (; parse_pos < argc; parse_pos++) 
  {
    if (!strcmp ("--microarray-mf", argv[parse_pos])) 
    {
      data_path = argv[++parse_pos];
      Multifactorial::init (data_path);
      Microarray::compute_variance();
      Microarray::compute_bandwidth();
      break;
    }
  }
}//-

void Multifactorial::load( string path )
{
  Multifactorial::init (path);
  Microarray::compute_variance();
  Microarray::compute_bandwidth(); 
}//-

// This function will load only the first experiment.
void
Multifactorial::init (string data_path, int model_no) {
  ifstream data_file;  
  data_file.open (data_path.c_str());
  assert (data_file.is_open()); 
  string line, token;
  
  { //- Read Header
    getline (data_file, line);
     stringstream sline (line);

    while (!sline.eof()) {
      sline >> token;
      size_t del_l = token.find_first_of("\"");
      size_t del_r = token.find_last_of("\"");
      if (del_l != string::npos && del_r != string::npos)
	token = token.substr (del_l+1, del_r-1);
      
      gene_labels.push_back(token);
    }
  } //-

  // Read the data set:
  size_t numof_genes = gene_labels.size();
  double probe_val, probe_pval;
  size_t control = 0;
  do {
    getline (data_file, line);
    stringstream sline (line);
    microarray single_measurement (numof_genes);
    
    for (int g = 0; g < numof_genes; g++) {
      sline >> token;
      probe_val = atof(token.c_str());
      Probe p(probe_val);
      single_measurement[g] = p;
    }
    microarray_vector.push_back (single_measurement);
    control++;

  } while (line.size() > 0);
}//-


void Multifactorial::dump() const 
{
  cout << "MultifactorialData:\n";
  for (int i = 0; i < gene_labels.size(); i++) 
    cout << gene_labels[i] << "\t";
  cout << endl;

  cout.precision(2);
  for (size_t kg = 0; kg < numof_genes(); kg++) {
    for (size_t tg = 0; tg < numof_genes(); tg++) {
      cout << microarray_vector[kg][tg];
      //cout << math::round_to_zero(data[kg][tg],2); 
      if (kg == tg) cout << "*\t"; 
      else cout << "\t";
    }
    cout << endl;
  }
  cout << endl;  
}//-

