/* Knockdowns Microarray data Class
 * The data is stored in form of a matrix N x N (N=#genes) as follows:
 * Column i holds the normalized RNA-level measurement for genes subjected to
 * to knocking down gene g_i (level reduced to a half of the original product

). 
 * The gene at position [i,i] of the Matrix "data" represents the knocked-down
 * gene.
 *
 * Load Syntax:
 * --microarray-knockdowns PATH_OF_DATA
*/

#ifndef GNOFF_KNOCKDOWNS_MICROARRAY_H
#define GNOFF_KNOCKDONWS_MICROARRAY_H

#include <iostream>
#include <string>
#include "microarray.h"

class Knockdowns : public Microarray {
 public:
  Knockdowns (std::string path);
  Knockdowns (int argc, char* argv[], int& parse_pos);
  void init (std::string data_path, int model_no=1); 
  virtual void dump() const; 
};

#endif
