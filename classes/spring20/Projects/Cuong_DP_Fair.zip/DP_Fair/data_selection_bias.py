from utils import *
from dp_classifier import  *
# WE PERFORMED brute-force search over all numertic features of each dataset
# to select which feature, in which if we can see negative impact of DP

pd00, feats = load_default_dataset()
stat_feats = {}
numeric_feats = [feat for feat in feats if len(pd00[feat].unique().tolist()) > 2]
for feat in numeric_feats:
    med_feat = np.median(pd00[feat])
    # take only a subset of female is smaller than median
    temp_pd00 = pd00[(pd00[feat] < med_feat) & (pd00['z'] == 0)]
    temp_pd01 = pd00[(pd00['z'] == 1)]
    pd01 = pd.concat([temp_pd00, temp_pd01])

    seed = 0
    x_train, y_train, x_control_train, x_test, y_test, x_control_test, train_df, test_df, X_train, X_val, Z_train, Z_val, Y_train, Y_val = get_data_v2(
        pd01, feats, seed=seed, bs=200)

    gen_params = {}
    gen_params['X_val'] = X_val
    gen_params['y_val'] = Y_val

    gen_params['z_val'] = Z_val
    gen_params['X_train'] = X_train
    gen_params['y_train'] = Y_train
    gen_params['z_train'] = Z_train
    gen_params['device'] = 'cpu'
    gen_params['epochs'] = 100
    gen_params['batch_size'] = 512
    gen_params['C'] = 1e-5
    gen_params['sigma'] = 1.0

    curr_options = {}
    curr_options['delta'] = 1e-5
    curr_options['clip_norm'] = False

    curr_options['model_params'] = {'i_dim': X_val.shape[1], 'h_dim': [int(X_val.shape[1] / 2)], 'o_dim': 1,
                                    'n_layers': 1}
    curr_options['dp'] = False
    curr_options['clip_norm'] = False
    try:

        non_private_model = IndBinClf(gen_params)
        non_private_model.fit(curr_options)
        acc_1, acc_0 = non_private_model.logs['acc_1'][-1], non_private_model.logs['acc_0'][-1]
        stat_feats[feat] = [abs(acc_1 - acc_0)]

        cn_model = IndBinClf(gen_params)
        curr_options['clip_norm'] = True
        cn_model.fit(curr_options)
        acc_1, acc_0 = cn_model.logs['acc_1'][-1], cn_model.logs['acc_0'][-1]

        stat_feats[feat].append(abs(acc_1 - acc_0))
        if stat_feats[feat][0] + 0.1 < stat_feats[feat][1]:
            break
        print(feat)
        print(stat_feats[feat])
    except:
        pass


