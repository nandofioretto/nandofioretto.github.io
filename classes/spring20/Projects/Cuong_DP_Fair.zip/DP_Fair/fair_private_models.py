
from dp_classifier import *

class AugmentedLagrangianSingleTask(IndBinClf):
    def __init__(self, params):
        super(AugmentedLagrangianSingleTask, self).__init__(params)
        self.logs['grad_delta_f1'] = []
        self.logs['grad_delta_f2'] = []


    def fit(self, options):
        torch.manual_seed(0)
        model = Net(options['model_params'])
        bce_criterion = nn.BCELoss(reduce='mean')
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-1)
        lambda_1 = options['lambda_1']
        lambda_2 = options['lambda_2']
        print(self.sigma, self.C)
        if options['dp']:
            privacy_engine = PrivacyEngine(
                model,
                batch_size=self.bs,
                sample_size=len(self.x_train),
                alphas=[1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64)),
                noise_multiplier=self.sigma,
                max_grad_norm=self.C
            )
            privacy_engine.attach(optimizer)
            # start training
        for epoch in range(self.epochs):
            model.train()
            avg_grad_norm_list_0 = []
            avg_grad_norm_list_1 = []
            avg_grad_norm_list_all = []
            avg_grad_norm_delta_f1_list = []
            avg_grad_norm_delta_f2_list = []
            for x_train, y_train in self.train_loader:
                try:
                    optimizer.zero_grad()
                    x_train = x_train.to(self.device)
                    z_train = x_train[:, self.input_size]
                    x_train = x_train[:, :self.input_size]
                    y_train = y_train.to(self.device)
                    # n_0, n_1 = float(len(y_train[z_train==0])), float(len(y_train[z_train==1]))
                    output_0, _ = model(x_train[z_train == 0, :])
                    loss_0 = bce_criterion(output_0, y_train[z_train == 0])
                    loss_0.backward(retain_graph=True)
                    avg_grad_norm_0 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_0 += torch.norm(p.grad.data, 2)

                    avg_grad_norm_list_0.append(avg_grad_norm_0.item())
                    clear_backprops(model)
                    optimizer.zero_grad()

                    output_1, _ = model(x_train[z_train == 1, :])
                    loss_1 = bce_criterion(output_1, y_train[z_train == 1])
                    loss_1.backward(retain_graph=True)
                    avg_grad_norm_1 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_1 += torch.norm(p.grad.data, 2)

                    avg_grad_norm_list_1.append(avg_grad_norm_1.item())
                    clear_backprops(model)
                    optimizer.zero_grad()
                    output, score_func = model(x_train)
                    clf_loss = bce_criterion(output, y_train)

                    clf_loss.backward(retain_graph = True)
                    avg_grad_norm_all = 0.0
                    for p in model.parameters():
                        avg_grad_norm_all += torch.norm(p.grad.data, 2)
                    avg_grad_norm_list_all.append(avg_grad_norm_all.item())

                    clear_backprops(model)
                    optimizer.zero_grad()


                    f11, f10 = torch.mean(score_func[z_train == 1]), torch.mean(score_func[z_train == 0])
                    f21, f20 = torch.mean(score_func[z_train == 1] ** 2), torch.mean(score_func[z_train == 0] ** 2)
                    violation_0, violation_1 = torch.abs(f11 - f10), torch.abs(f21 - f20)

                    violation_0.backward(retain_graph = True)
                    avg_grad_norm_delta_f1 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_delta_f1 += torch.norm(p.grad.data, 2)
                    avg_grad_norm_delta_f1_list.append(copy.deepcopy(avg_grad_norm_delta_f1.item()))
                    clear_backprops(model)
                    optimizer.zero_grad()

                    violation_1.backward(retain_graph=True)
                    avg_grad_norm_delta_f2 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_delta_f2 += torch.norm(p.grad.data, 2)
                    avg_grad_norm_delta_f2_list.append(copy.deepcopy(avg_grad_norm_delta_f2))
                    clear_backprops(model)
                    optimizer.zero_grad()

                    total_loss = clf_loss + lambda_1 * violation_0 + lambda_2  * violation_1
                    total_loss.backward()


                    if options['dp']:
                        epsilon, best_alpha = optimizer.privacy_engine.get_privacy_spent(options['delta'])
                        self.logs['eps'].append(epsilon)
                    optimizer.step()
                except:
                    print('Warning !!!')
                    pass
            self.logs['grad_0'].append(copy.deepcopy(np.mean(avg_grad_norm_list_0)))
            self.logs['grad_1'].append(copy.deepcopy(np.mean(avg_grad_norm_list_1)))
            self.logs['grad_clf_all'].append(copy.deepcopy(np.mean(avg_grad_norm_list_all)))
            self.logs['grad_delta_f1'].append(copy.deepcopy(np.mean(avg_grad_norm_delta_f1_list)))
            self.logs['grad_delta_f2'].append(copy.deepcopy(np.mean(avg_grad_norm_delta_f2_list)))
            self.write_logs(model)

        self.model = model

        return