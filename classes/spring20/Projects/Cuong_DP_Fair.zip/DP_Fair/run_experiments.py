from utils import *
import pickle, sys
file_path = '/home/cutran/Documents/privacy_with_fairness/res/' ## NEED TO MODIFY THis

#from dp_classifier import *
from fair_private_models import *

def test():

    dataset_list = ['bank', 'income']

    num_epochs = 50
    num_sigma = 4
    num_dataset = 2

    res = {}
    num_seed = 5

    sigma_list = [1, 2,  4,  6]
    #sigma_list = [0.1]
    for data in dataset_list[:num_dataset]:
        res[data] = {'clf':[], 'fair_clf': [], 'private_clf':{}, 'private_fair':{}}
        for key_ in res[data].keys():
            if 'private' in key_:
                for sigma in sigma_list[:num_sigma]:
                    res[data][key_][sigma] = []

        if data == 'bank':
            pd00, feats = load_bank_dataset()
        elif data =='income':
            pd00, feats = load_adult_dataset()
        else:
            pd00, feats = load_default_dataset()



        for seed in range( num_seed):
            x_train, y_train, x_control_train, x_test, y_test, x_control_test, train_df, test_df, X_train, X_val, Z_train, Z_val, Y_train, Y_val = get_data_v2(
                    pd00, feats, seed= seed, bs=200)

            gen_params = {}
            gen_params['X_val'] = X_val
            gen_params['y_val'] = Y_val
            gen_params['z_val'] = Z_val
            gen_params['X_train'] = X_train
            gen_params['y_train'] = Y_train
            gen_params['z_train'] = Z_train
            gen_params['device'] = 'cpu'
            gen_params['epochs'] = num_epochs
            gen_params['batch_size'] = 512
            gen_params['C'] = 1
            gen_params['sigma'] = None
            curr_options = {}
            curr_options['delta'] = 1e-5
            curr_options['model_params'] = {'i_dim': X_val.shape[1], 'h_dim': [int( X_val.shape[1]/2)], 'o_dim': 1, 'n_layers': 1}
            curr_options['dp'] = False

            non_private_model = IndBinClf(gen_params)
            non_private_model.fit(curr_options)
            res[data]['clf'].append(copy.deepcopy(non_private_model.logs))

            curr_options['lambda_1'] = 0.1
            curr_options['lambda_2'] = 0.05
            fair_model = AugmentedLagrangianSingleTask(gen_params)
            fair_model.fit(curr_options)
            res[data]['fair_clf'].append(copy.deepcopy(fair_model.logs))

            for sigma_ in sigma_list[:num_sigma]:
                gen_params['sigma'] = sigma_
                private_model = IndBinClf(gen_params)
                curr_options['dp'] = True
                private_model.fit(curr_options)
                res[data]['private_clf'][sigma_].append(copy.deepcopy(private_model.logs))

                private_fair_model = AugmentedLagrangianSingleTask(gen_params)

                private_fair_model.fit(curr_options)
                res[data]['private_fair'][sigma_].append(copy.deepcopy(private_fair_model.logs))

            file_handle = open(file_path + 'v2_temp_private_vs_non_private_models.pkl', 'wb')
            pickle.dump(res, file_handle)


    file_handle = open(file_path + 'v_2_final_private_vs_non_private_models.pkl', 'wb')
    pickle.dump(res, file_handle)

if __name__ == "__main__":
    test()