# plot with different values of C
# 4 choices of models : fair/ unfair vs private/ unprivate

##dict_keys(['clf', 'fair_clf', 'grad_bound_clf', 'grad_bound_fair', 'private_clf', 'private_fair_clf'])

pairs_list = [['clf', 'grad_bound_clf'], ['clf','private_clf'], ['fair_clf', 'grad_bound_fair'], ['fair_clf','private_fair_clf']]

import matplotlib.pyplot as plt

f, axes = plt.subplots(figsize=(12, 9), nrows=4, ncols=3, sharex=True, sharey='row')

group_metrics1 = [['acc_0', 'acc_1', 'all_acc'], ['loss_0', 'loss_1'], ['TPR_0', 'TPR_1'],
                  ['grad_0', 'grad_1', 'grad_clf_all']]
label_name = ['z=0', 'z=1', 'All']
y_axis_name = ['Accuracy', 'LogLoss', 'TPR', 'Avg Grad Norm', 'epsilon']
col_names = ['UnFair_No Privacy', 'UnFair_C=0.1_(sigma=0.0)', 'UnFair_C =10_(sigma=0.0)']
temp_sigma_list = [0.1, 10]
for i in range(12):
    r, c = int(i / 3), int(i % 3)

    curr_ax = axes[r][c]
    if c == 0:
        key_ = 'clf'
    else:
        key_ = 'grad_bound_clf'
    temp_metric = group_metrics1[r]
    if c == 0:
        for index, metric in enumerate(temp_metric):
            curr_ax.plot(range(len(res[data][key_][0][metric])), res[data][key_][0][metric], label=label_name[index])
    else:
        for index, metric in enumerate(temp_metric):
            curr_ax.plot(range(len(res[data][key_][temp_sigma_list[c - 1]][0][metric])),
                         res[data][key_][temp_sigma_list[c - 1]][0][metric], label=label_name[index])

    curr_ax.set_xlabel('Epochs')
    curr_ax.set_ylabel(y_axis_name[r])
    curr_ax.legend()
    curr_ax.set_title(col_names[c])
    curr_ax.legend()

plt.tight_layout()
# plt.subplots_adjust(hspace=0.4)
# plt.subplots_adjust(vspace=0.4)

f.suptitle(data)
plt.show()


