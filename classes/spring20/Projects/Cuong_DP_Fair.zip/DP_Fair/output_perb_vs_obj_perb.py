from utils import *
import pickle
from dp_lr import *
from sklearn.metrics import *

def sigmoid(x):
  z = 1/(1 + np.exp(-x))
  return z

file_path = '/home/cutran/Documents/privacy_with_fairness/res/'

def test():

    dataset_list = ['income']

    num_eps = 4
    num_dataset = 4

    res = {}
    num_seed = 5

    eps_list = [0.1, 1,  10,  100][:num_eps]
    #sigma_list = [0.1]
    for data in dataset_list[:num_dataset]:
        res[data] = {}
        for eps in eps_list:
            res[data][eps] = {'obj':{'loss_0':[], 'loss_1':[] , 'acc_0':[], 'acc_1':[]},\
                     'output':{'loss_0':[], 'loss_1':[] , 'acc_0':[], 'acc_1':[]}}


        if data == 'bank':
            pd00, feats = load_bank_dataset()
        elif data =='income':
            pd00, feats = load_adult_dataset()
        elif data == 'default':
            pd00, feats = load_default_dataset()
        else:
            pd00, feats = load_compas_data()

        for eps in eps_list:
            for seed in range( num_seed):
                x_train, y_train, x_control_train, x_test, y_test, x_control_test, train_df, test_df, X_train, X_val, Z_train, Z_val, Y_train, Y_val = get_data_v2(
                        pd00, feats, seed= seed, bs=200)

                z_test = x_control_test['sex']

                if train_df['label'].min() == 0:
                    train_df['label'] = train_df['label'] *2 -1

                # objective perturbation
                feat_names  = [col for col in train_df.columns.tolist() if 'feat' in col]

                w_sol = dp_lr(train_df[feat_names].values, train_df['label'].values, method='obj', epsilon= eps, Lambda=1e-1)
                y_pred = (np.dot(test_df[feat_names].values, w_sol) >= 0).astype(int)
                _, _, acc_0, acc_1 = compute_fairness_score(test_df['label'].values, y_pred, z_test)

                res[data][eps]['obj']['acc_0'].append(copy.deepcopy(acc_0))
                res[data][eps]['obj']['acc_1'].append(copy.deepcopy(acc_1))

                y_soft_pred = sigmoid(np.dot(test_df[feat_names], w_sol))
                loss_0 = log_loss(y_test[z_test==0], y_soft_pred[z_test==0])
                loss_1 = log_loss(y_test[z_test==1], y_soft_pred[z_test==1])
                res[data][eps]['obj']['loss_0'].append(copy.deepcopy(loss_0))
                res[data][eps]['obj']['loss_1'].append(copy.deepcopy(loss_1))

                # output perturbation

                w_sol = dp_lr(train_df[feat_names].values, train_df['label'].values, method='output', epsilon=eps, Lambda=1e-1)
                y_pred = (np.dot(test_df[feat_names].values, w_sol) >= 0).astype(int)
                _, _, acc_0, acc_1 = compute_fairness_score(test_df['label'].values, y_pred, z_test)

                res[data][eps]['output']['acc_0'].append(copy.deepcopy(acc_0))
                res[data][eps]['output']['acc_1'].append(copy.deepcopy(acc_1))

                y_soft_pred = sigmoid(np.dot(test_df[feat_names], w_sol))
                loss_0 = log_loss(y_test[z_test == 0], y_soft_pred[z_test == 0])
                loss_1 = log_loss(y_test[z_test == 1], y_soft_pred[z_test == 1])
                res[data][eps]['output']['loss_0'].append(copy.deepcopy(loss_0))
                res[data][eps]['output']['loss_1'].append(copy.deepcopy(loss_1))


    file_handle = open(file_path + 'income_obj_vs_output_dp.pkl', 'wb')
    pickle.dump(res, file_handle)


if __name__ == '__main__':
    test()