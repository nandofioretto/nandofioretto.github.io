
# We implemented fair model under NEW DEFINITION of privacy
# protect individual sensitive information
# we act gradient clipping over only Lagrangian term.
# Our hopes is that this model can bring fairness and privacy at the same time


from dp_classifier import *

import torch
from torch import nn

import warnings

warnings.filterwarnings("ignore")



class NewFairAccModel(IndBinClf):
    def __init__(self, params):
        super(NewFairAccModel, self).__init__(params)

        self.logs['grad_add_loss'] = []
        self.logs['lambda'] = []

    def get_grad(self, model, options):
        # extract gradient from model
        w_dict = {}
        for name, p in model.named_parameters():
            if not options['dp']:
                w_dict[name] = p.grad.data  # consider p.grad.data here
            else:
                w_dict[name] = p.grad.data + torch.FloatTensor(p.grad.shape).normal_(0, self.sigma * self.C)
        return copy.deepcopy(w_dict)

    def fit(self, options):
        torch.manual_seed(0)
        model = Net(options['model_params'])
        bce_criterion = nn.BCELoss(reduce='mean')
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-1)
        lambda_ = options['lambda_']
        mult_lr = options.get('mult_lr', 0.2)

        print(self.sigma, self.C)
        if options['clip_norm'] or options['dp']:
            clip_engine = PerSampleGradientClipper(model, max_norm=self.C)

        for epoch in range(self.epochs):
            model.train()
            avg_grad_norm_list_0 = []
            avg_grad_norm_list_1 = []
            avg_grad_norm_list_all = []
            avg_grad_norm_list_add_loss = []
            violation_list = []

            for x_train, y_train in self.train_loader:

                x_train = x_train.to(self.device)
                z_train = x_train[:, self.input_size]
                x_train = x_train[:, :self.input_size]
                y_train = y_train.to(self.device)
                n_0, n_1 = float(len(y_train[z_train == 0])), float(len(y_train[z_train == 1]))
                if n_0 == 0 or n_1 == 0 :
                    continue

                 # Step 1: get gradient of the average loss of group z=0, we hope the gradient norm converges to zero

                output_0, _ = model(x_train[z_train == 0, :])
                loss_0 = bce_criterion(output_0, y_train[z_train == 0])

                loss_0.backward(retain_graph=True)
                avg_grad_norm_0 = 0.0
                for p in model.parameters():
                    avg_grad_norm_0 += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_0.append(avg_grad_norm_0.item())
                clear_backprops(model)

                # Step 2: get gradient of the average loss of group z= 1, we hope the gradient norm converges to zero

                output_1, _ = model(x_train[z_train == 1, :])
                loss_1 = bce_criterion(output_1, y_train[z_train == 1])
                loss_1.backward(retain_graph=True)
                avg_grad_norm_1 = 0.0
                for p in model.parameters():
                    avg_grad_norm_1 += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_1.append(avg_grad_norm_1.item())
                clear_backprops(model)

                # get gradient of classification losss

                clf_loss = n_0 / (n_0 + n_1) * loss_0 + n_1 / (n_0 + n_1) * loss_1
                clf_loss.backward(retain_graph=True)
                avg_grad_norm_all = 0.0
                for p in model.parameters():
                    avg_grad_norm_all += torch.norm(p.grad.data, 2)
                avg_grad_norm_list_all.append(avg_grad_norm_all.item())
                clear_backprops(model)

                add_loss = torch.abs(loss_0 - loss_1)
                avg_grad_norm_add_loss = 0.0
                violation_list.append(add_loss.item())

                add_loss.backward(retain_graph=True)

                for p in model.parameters():
                    avg_grad_norm_add_loss += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_add_loss.append(avg_grad_norm_add_loss)


                ### NOW MOVE TO THE MAIN IMPORTANT PART,

                clear_backprops(model)


                output, _ = model(x_train)
                loss_0 = bce_criterion(output[z_train == 0], y_train[z_train == 0])
                loss_1 = bce_criterion(output[z_train == 1], y_train[z_train == 1])

                lagrangian_term = torch.abs(loss_0 - loss_1)
                lagrangian_term.backward(retain_graph = True)
                if options['clip_norm'] or options['dp']:
                    clip_engine.step()
                w_add_dict = self.get_grad(model, options) # save gradients of Lagrangian term to this dictionary, will be used later

                optimizer.zero_grad()

                output, _ = model(x_train)
                clf_loss = bce_criterion(output, y_train)
                clf_loss.backward()
                for name, p in model.named_parameters():
                    if name in w_add_dict.keys():
                        p.grad.data += lambda_ * w_add_dict[name]  # add gradient of the Lagrangian term here,
                        # note that there are possible some weight name not in dictionary

                optimizer.step()

            lambda_ += mult_lr * np.mean(violation_list)

            self.logs['grad_0'].append(copy.deepcopy(np.mean(avg_grad_norm_list_0)))
            self.logs['grad_1'].append(copy.deepcopy(np.mean(avg_grad_norm_list_1)))
            self.logs['grad_clf_all'].append(copy.deepcopy(np.mean(avg_grad_norm_list_all)))
            self.logs['grad_add_loss'].append(copy.deepcopy(np.mean(avg_grad_norm_list_add_loss)))
            self.logs['lambda'].append(lambda_)

            self.write_logs(model)

        self.model = model

        return