# generator of synthetic dataset
import numpy as np
import pandas as pd

np.random.seed(0)
d = 5
mean1 = np.random.randn(d)
mean0 = mean1 + 0.5*np.random.randn(d)
n1 = 5000
n0 = 500
X1 = np.random.multivariate_normal(mean1, np.identity(d), n1)
X0 = np.random.multivariate_normal(mean0, np.identity(d), 500)
X1.shape, X0.shape

diff_level = 0.4
beta1 = np.random.rand(d,1)
beta0 = beta1 + diff_level* np.random.randn(d,1)
#beta0 = beta1
f1 = np.dot(X1, beta1)
f0 = np.dot(X0, beta0)

pd00 = pd.DataFrame(data = np.r_[X1, X0], columns = ['feat_{}'.format(i) for i in range(d)])
pd00['f'] = np.log( np.r_[f1, f0]**2 +1.0) - 3.5 + np.random.randn(5500,1)
pd00['z'] = np.r_[ np.ones(n1), np.zeros(n0)]
pd00['label'] = (pd00['f']>=0).astype(int)
feats = ['feat_{}'.format(i) for i in range(d)]
print( pd00[pd00['z']==0]['f'].describe())
print(pd00[pd00['z']==1]['f'].describe())

pd00['intercept'] = 1.0
