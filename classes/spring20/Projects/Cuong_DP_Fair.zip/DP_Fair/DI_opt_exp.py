from utils import *
import pickle
from DI_optimizer import  *

def test():
    dataset_list  = ['bank', 'income', 'compas', 'default']
    C_list = [1e-5, 1e-3, 1, 10]
    sigma = 5
    res = {}
    for data in dataset_list:
        res[data] = {'fair':None, 'cn_fair':{}, 'dp_fair':{}}
    for data in dataset_list:
        if data == 'bank':
            pd00, feats = load_bank_dataset()
        elif data == 'income':
            pd00, feats = load_adult_dataset()
        elif data =='default':
            pd00, feats = load_default_dataset()
        else:
            pd00, feats = load_compas_data()

        seed = 0
        x_train, y_train, x_control_train, x_test, y_test, x_control_test, train_df, test_df, X_train, X_val, Z_train, Z_val, Y_train, Y_val = get_data_v2(
            pd00, feats, seed=seed, bs=200)

        gen_params = {}
        gen_params['X_val'] = X_val
        gen_params['y_val'] = Y_val

        gen_params['z_val'] = Z_val
        gen_params['X_train'] = X_train
        gen_params['y_train'] = Y_train
        gen_params['z_train'] = Z_train
        gen_params['device'] = 'cpu'
        gen_params['epochs'] = 100
        gen_params['batch_size'] = 512
        gen_params['C'] = 1e-3
        gen_params['sigma'] = sigma

        curr_options = {}
        curr_options['delta'] = 1e-5
        curr_options['lambda_'] = 0.0
        curr_options['model_params'] = {'i_dim': X_val.shape[1], 'h_dim': [int(X_val.shape[1] * 2 / 3)], 'o_dim': 1,
                                        'n_layers': 1}
        curr_options['dp'] = False
        curr_options['clip_norm'] = False

        fair_model = DI_Optimizer(gen_params)
        fair_model.fit(curr_options)
        res[data]['fair'] = copy.deepcopy(fair_model.logs)
        for C in C_list:
            gen_params['C'] = C
            curr_options['clip_norm'] = True
            curr_options['dp'] = False
            cn_model = DI_Optimizer(gen_params)
            cn_model.fit(curr_options)
            res[data]['cn_fair'][C] = copy.deepcopy(cn_model.logs)

        for C in C_list:
            gen_params['C'] = C
            curr_options['clip_norm'] = False
            curr_options['dp'] = True
            cn_model = DI_Optimizer(gen_params)
            cn_model.fit(curr_options)
            res[data]['dp_fair'][C] = copy.deepcopy(cn_model.logs)











