import numpy as np
from scipy.optimize import minimize

def noisevector( scale, Length ):

    r1 = np.random.normal(0, 1, Length)#standard normal distribution
    n1 = np.linalg.norm( r1, 2 )#get the norm of this random vector
    r2 = r1 / n1#the norm of r2 is 1
    normn = np.random.gamma( Length, 1/scale, 1 )#Generate the norm of noise according to gamma distribution
    res = r2 * normn#get the result noise vector
    return res

def lr( z ):

    logr = np.log( 1 + np.exp( -z ) )
    return logr

def lr_output_train( data, labels, epsilon, Lambda ):

    L = len( labels )
    l = len( data[0] )#length of a data point
    scale = L * Lambda * epsilon / 2#chaudhuri2011differentially corollary 11, part 1
    noise = noisevector( scale, data.shape[1] )
    x0 = np.zeros( l )#starting point with same length as any data point

    def obj_func(x):
        jfd = lr( labels[0] * np.dot( data[0] , x ) )
        for i in range( 1, L ):
            jfd = jfd + lr( labels[i] * np.dot( data[i], x ) )
        f = (1/L) * jfd + (1/2) * Lambda * ( np.linalg.norm(x)**2 )
        return f

    #minimization procedure
    f = minimize( obj_func, x0, method='Nelder-Mead').x#empirical risk minimization using scipy.optimize minimize function
    fpriv = f + noise
    return fpriv

def lr_objective_train(data, labels, epsilon, Lambda ):

    #parameters in objective perturbation method
    c = 1 / 4#chaudhuri2011differentially corollary 11, part 2
    L = len( labels )#number of data points in the data set
    l = len( data[0] )#length of a data point
    x0 = np.zeros( l )#starting point with same length as any data point
    Epsilonp = epsilon - 2 * np.log( 1 + c / ( Lambda * L ) )
    if Epsilonp > 0:
        Delta = 0
    else:
        Delta = c / ( L * ( np.exp( epsilon / 4 ) - 1 ) ) - Lambda
        Epsilonp = epsilon / 2
    scale = Epsilonp / 2
    noise = noisevector( scale, l )

    def obj_func( x ):
        jfd = lr( labels[0] * np.dot( data[0], x ) )
        for i in range( 1, L ):
            jfd = jfd + lr( labels[i] * np.dot( data[i], x ) )
        f = (1/L) * jfd + (1/2) * Lambda * ( np.linalg.norm(x)**2 ) + (1/L) * np.dot(noise, x) + (1/2) * Delta * (np.linalg.norm(x)**2)
        return f

    #minimization procedure
    fpriv = minimize(obj_func, x0, method='Nelder-Mead').x#empirical risk minimization using scipy.optimize minimize function
    return fpriv

def dp_lr(data, labels, method='obj', epsilon=0.1, Lambda = 0.01 ):


    if epsilon < 0.0:
        print('ERROR: Epsilon should be positive.')
        return
    else:

        if method == 'obj':
            fpriv = lr_objective_train(data, labels, epsilon, Lambda )
        else:
            fpriv = lr_output_train( data, labels, epsilon, Lambda )

        return fpriv