
from dp_classifier import *

import torch
from torch import nn

import warnings

warnings.filterwarnings("ignore")



class FairAccClassifier(IndBinClf):
    def __init__(self, params):
        super(FairAccClassifier, self).__init__(params)

        self.logs['grad_add_loss'] = []
        self.logs['lambda'] = []

    def fit(self, options):
        torch.manual_seed(0)
        model = Net(options['model_params'])
        bce_criterion = nn.BCELoss(reduce='mean')
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-1)
        lambda_ = options['lambda_']
        mult_lr = options.get('mult_lr', 0.2)

        print(self.sigma, self.C)
        if options['dp']:
            privacy_engine = PrivacyEngine(
                model,
                batch_size=self.bs,
                sample_size=len(self.x_train),
                alphas=[1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64)),
                noise_multiplier=self.sigma,
                max_grad_norm=self.C
            )
            privacy_engine.attach(optimizer)
        if options['clip_norm']:
            clip_engine = PerSampleGradientClipper(model, max_norm=self.C)

        for epoch in range(self.epochs):
            model.train()
            avg_grad_norm_list_0 = []
            avg_grad_norm_list_1 = []
            avg_grad_norm_list_all = []
            avg_grad_norm_list_add_loss = []
            violation_list = []

            for x_train, y_train in self.train_loader:

                x_train = x_train.to(self.device)
                z_train = x_train[:, self.input_size]
                x_train = x_train[:, :self.input_size]
                y_train = y_train.to(self.device)
                n_0, n_1 = float(len(y_train[z_train == 0])), float(len(y_train[z_train == 1]))
                if n_0 == 0:
                    continue

                output_0, _ = model(x_train[z_train == 0, :])
                loss_0 = bce_criterion(output_0, y_train[z_train == 0])

                loss_0.backward(retain_graph=True)
                avg_grad_norm_0 = 0.0
                for p in model.parameters():
                    avg_grad_norm_0 += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_0.append(avg_grad_norm_0.item())
                clear_backprops(model)

                output_1, _ = model(x_train[z_train == 1, :])
                loss_1 = bce_criterion(output_1, y_train[z_train == 1])
                loss_1.backward(retain_graph=True)
                avg_grad_norm_1 = 0.0
                for p in model.parameters():
                    avg_grad_norm_1 += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_1.append(avg_grad_norm_1.item())
                clear_backprops(model)

                # output, score_func = model(x_train)
                # clf_loss = bce_criterion(output, y_train)
                # already normalize loss_0 and loss_1 by number of samples per group.
                clf_loss = n_0 / (n_0 + n_1) * loss_0 + n_1 / (n_0 + n_1) * loss_1
                clf_loss.backward(retain_graph=True)
                avg_grad_norm_all = 0.0
                for p in model.parameters():
                    avg_grad_norm_all += torch.norm(p.grad.data, 2)
                avg_grad_norm_list_all.append(avg_grad_norm_all.item())
                clear_backprops(model)

                add_loss = torch.abs(loss_0 - loss_1)
                avg_grad_norm_add_loss = 0.0
                violation_list.append(add_loss.item())

                add_loss.backward(retain_graph=True)

                for p in model.parameters():
                    avg_grad_norm_add_loss += torch.norm(p.grad.data, 2)

                avg_grad_norm_list_add_loss.append(avg_grad_norm_add_loss)

                clear_backprops(model)

                output, _ = model(x_train)
                loss_0 = bce_criterion(output[z_train == 0], y_train[z_train == 0])
                loss_1 = bce_criterion(output[z_train == 1], y_train[z_train == 1])

                total_loss = n_0 / (n_0 + n_1) * loss_0 + n_1 / (n_0 + n_1) * loss_1 + lambda_ * torch.abs(
                    loss_0 - loss_1)
                optimizer.zero_grad()
                total_loss.backward()
                if options['clip_norm']:
                    clip_engine.step()
                optimizer.step()

                if options['dp']:
                    epsilon, best_alpha = optimizer.privacy_engine.get_privacy_spent(options['delta'])
                    self.logs['eps'].append(epsilon)

            lambda_ += mult_lr * np.mean(violation_list)
            self.logs['lambda'].append(copy.deepcopy(lambda_))

            self.logs['grad_0'].append(copy.deepcopy(np.mean(avg_grad_norm_list_0)))
            self.logs['grad_1'].append(copy.deepcopy(np.mean(avg_grad_norm_list_1)))
            self.logs['grad_clf_all'].append(copy.deepcopy(np.mean(avg_grad_norm_list_all)))
            self.logs['grad_add_loss'].append(copy.deepcopy(np.mean(avg_grad_norm_list_add_loss)))

            self.write_logs(model)

        self.model = model

        return

