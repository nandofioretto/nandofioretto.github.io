
# clone the repo first to import some implemented functions
#!git clone https: // github.com / mbilalzafar / fair - classification
# from google.colab import drive
# drive.mount('/content/drive')

import sys, os
if not os.path.exists('/content/fair-classification/fair_classification/'):
    print
    'No problem when import  AISTAT path'

sys.path.insert(1, '/content/fair-classification/disparate_impact/synthetic_data_demo')
sys.path.insert(1, '/content/fair-classification/disparate_impact/adult_data_demo/')
sys.path.insert(1, '/content/fair-classification/fair_classification/')

# from decision_boundary_demo import *
import loss_funcs as lf
from prepare_adult_data import *
from scipy.optimize import minimize



def get_constraints(model, x_arr, y, z, thresh, order):
    """
    
    :param model:  model parameter w in R^d, d is the number of input features (intercept included)
    :param x_arr: x_train : training input data nxd
    :param y:   y_train training output data nx1
    :param z:  sensitive variable information for training data nx1
    :param thresh:  we require the covariance between model and z is smaller than thresh, the smaller the thresh is, the more fairness we require
    :param order: the default order is 1. Cuong added one more (order of 2 to check)
    :return: optimal parameter  w*
    """
    arr = np.dot(model, x_arr.T)  # the product with the weight vector -- the sign of this is the output label

    arr = np.array(arr, dtype=np.float64)
    if order == 2:
        arr = arr ** 2
    cov = np.dot(z - np.mean(z), arr) / float(len(z))
    ans = thresh - abs(cov)
    return ans


# constraint over x_train, y_train, and we require the first order covariance between model and x_control_train['sex'] is smallest,
# threshold = 0.0 , i.e | cov(w, x_control_train['sex']) | <=0.0
c1 = (
{'type': 'ineq', 'fun': get_constraints, 'args': (x_train, y_train, x_control_train['sex'], 0.0, 1)})

# x_control_train['sex'] is gender

constraints = [c1]
loss_function = lf._logistic_loss


y_train[y_train == 0] = -1 # MUST CHANGE label set from (0,1) to (-1, 1)
max_iter = 300000
# constraints = get_constraint_list_cov(x, y, x_control, sensitive_attrs, sensitive_attrs_to_cov_thresh)
f_args = (x_train, y_train)
x0 = np.random.rand(x_train.shape[1], 1)
w = minimize(fun=loss_function,
             x0=x0,
             args=f_args,
             method='SLSQP',
             options={"maxiter": max_iter},
             constraints=constraints
             )

w_new = w.x