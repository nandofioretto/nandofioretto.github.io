import os, sys

from torch import nn
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
import torch
from os import path

from sklearn.metrics import *
import sklearn as sk
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from torch import Tensor
from sklearn.metrics import *
#torch.set_default_tensor_type(torch.cuda.FloatTensor)
import warnings
warnings.filterwarnings("ignore")
#!cd /content/pytorch-dp
sys.path.insert(1, '/home/cutran/pytorch-dp/')
from torchdp import PrivacyEngine
from torchdp import PerSampleGradientClipper

from torchvision import datasets, transforms
import warnings
from six.moves import xrange
import  copy
from sklearn.metrics import accuracy_score
import numpy as np
from os import path
import os, sys, pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import  StandardScaler, Normalizer
from torch.utils.data import DataLoader, TensorDataset

from torch import Tensor

from sklearn.metrics import *
from torch import Tensor
torch.set_default_tensor_type(torch.FloatTensor)


#WORK_PATH = '/home/cutran/Documents/privacy_with_fairness/'

WORK_PATH = '/content/drive/My Drive/research/privacy_with_fairness/'
def get_data_v2(pd00, feats, seed, bs):
  x_train, x_test, y_train, y_test, z_train, z_test = train_test_split(pd00[feats + ['intercept']].values,
                                                                       pd00['label'].values, pd00['z'].values,
                                                                       test_size=0.2, random_state=seed)
  x_control_train, x_control_test = {'sex': z_train}, {'sex': z_test}
  scaler = StandardScaler().fit(x_train)
  train_df = pd.DataFrame(data=scaler.transform(x_train),
                          columns=['feat_{}'.format(i) for i in range(x_train.shape[1])])

  # dataset for TF fairness model
  train_df['label'] = y_train
  train_df['male'] = z_train
  train_df['female'] = 1 - z_train

  test_df = pd.DataFrame(data=scaler.transform(x_test), columns=['feat_{}'.format(i) for i in range(x_test.shape[1])])
  test_df['label'] = y_test
  test_df['male'] = z_test
  test_df['female'] = 1 - z_test

  ### dataset for our model

  X_train, X_val, Y_train, Y_val, Z_train, Z_val = train_test_split(x_train, y_train, z_train, test_size=0.25,
                                                                    random_state=seed)

  return x_train, y_train, x_control_train, x_test, y_test, x_control_test, train_df, test_df, X_train, X_val, Z_train, Z_val, Y_train, Y_val


def load_adult_dataset(data_size=35000):

  pd00 = pd.read_csv(WORK_PATH + 'datasets/income.csv')
  pd00 = pd00.sample(n = data_size)
  feats = [col for col in pd00.columns.tolist() if 'feat' in col]

  return pd00, feats


def load_bank_dataset():
  bank_pd = pd.read_csv(WORK_PATH + 'datasets/bank.csv')
  bank_pd['z'] = bank_pd['age'].apply(lambda x: x < 25 or x > 60).astype(int)
  bank_pd['label'] = bank_pd['deposit'].apply(lambda x: x == 'yes').astype(int)
  if 'deposit' in bank_pd.columns.tolist():
    bank_pd = bank_pd.drop('deposit', axis=1)
  cat_cols = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'poutcome']
  for col in cat_cols:
    encod_type = bank_pd.groupby(col)['label'].mean()
    bank_pd.loc[:, col] = bank_pd[col].map(encod_type)
  feats = [x for x in bank_pd.columns.tolist() if x not in ['label', 'z', 'age']]

  def monthToNum(shortMonth):

    return {
      'jan': 1,
      'feb': 2,
      'mar': 3,
      'apr': 4,
      'may': 5,
      'jun': 6,
      'jul': 7,
      'aug': 8,
      'sep': 9,
      'oct': 10,
      'nov': 11,
      'dec': 12
    }[shortMonth]

  bank_pd['month'] = bank_pd['month'].apply(lambda x: monthToNum(x))

  bank_pd['intercept'] = 1

  return bank_pd, feats

def load_law_school_data() :
  pd00 = pd.read_csv(WORK_PATH + 'datasets/law_school.csv')
  feats = [col for col in pd00.columns.tolist() if 'feat' in col]
  return pd00, feats

def load_compas_data():
  compas_pd = pd.read_csv(WORK_PATH+ 'datasets/processed_compas.csv')

  compas_pd['z'] = compas_pd['race'].apply(lambda x: 1 - x).astype(int)
  compas_pd['intercept'] = 1
  if 'race' in compas_pd.columns.tolist():
    compas_pd = compas_pd.drop('race', axis=1)
  feats = [x for x in compas_pd.columns.tolist() if x not in ['label', 'z', 'race', 'intercept']]

  return compas_pd, feats


def load_default_dataset():
  pd00 = pd.read_excel(WORK_PATH + 'datasets/default_credit_card.xls')
  if 'Unnamed: 0' in pd00.columns.tolist():
    pd00 = pd00.drop('Unnamed: 0', axis=1)
  pd00.columns = pd00.loc[0, :].values.tolist()
  pd00 = pd00.iloc[1:,:]

  pd00['EDUCATION'] = pd00['EDUCATION'].apply(lambda x: min(x, 4))
  pd00.loc[pd00['EDUCATION'] == 0, 'EDUCATION'] = 4
  feats = [x for x in pd00.columns.tolist() if x not in ['SEX', 'default payment next month']]
  pd00['intercept'] = 1
  # pd00['label'] =  pd00['default payment next month'].astype(int)
  pd00['label'] = pd.to_numeric(pd00['default payment next month'], errors='coerce')
  pd00 = pd00[~pd00['label'].isnull()]
  if 'default payment next month' in pd00.columns.tolist():
    pd00 = pd00.drop('default payment next month', axis=1)
  pd00['z'] = pd00['SEX']
  pd00['z'] = pd00['z'].apply(lambda x: x - 1)
  if 'SEX' in pd00.columns.tolist():
    pd00 = pd00.drop('SEX', axis=1)

  for col in pd00.columns.tolist():
    pd00[col] = pd00[col].astype(float)

  return pd00, feats
def compute_fairness_score(y_true, y_pred, z_true):
  acc = accuracy_score(y_true, y_pred)
  p1 = y_pred[z_true==1]
  p0 = y_pred[z_true==0]
  p1 = np.sum(p1)/float(len(p1))
  p0 = np.sum(p0)/float(len(p0))
  acc0 = accuracy_score(y_true[z_true==0], y_pred[z_true==0])
  acc1 = accuracy_score(y_true[z_true==1], y_pred[z_true==1])
  return acc, abs(p1-p0), acc0, acc1

def clear_backprops(model: nn.Module) -> None:
    """Delete layer.backprops_list in every layer."""
    for layer in model.modules():
        if hasattr(layer, "backprops_list"):
            del layer.backprops_list