from network import *
from utils import *


class IndBinClf(object):
    def __init__(self, params):
        torch.manual_seed(0)
        self.y_val = params['y_val']
        self.z_val = params['z_val']
        self.bs = params.get('batch_size', 512)
        self.C = params['C']
        self.sigma = params['sigma']
        # self.scaler = Normalizer().fit(params['X_train'])
        # self.scaler = MinMaxScaler().fit(params['X_train'])
        self.scaler = StandardScaler().fit(params['X_train'])
        self.x_train = self.scaler.transform(params['X_train'])
        self.X_val = self.scaler.transform(params['X_val'])
        self.input_size = self.X_val.shape[1]
        self.y_train = params['y_train']
        self.z_train = params['z_train']
        train_tensor = TensorDataset(Tensor(np.c_[self.x_train, self.z_train]), Tensor(self.y_train))
        self.train_loader = DataLoader(dataset=train_tensor, batch_size=self.bs, shuffle=False)
        self.epochs = params.get('epochs', 50)
        self.device = params.get('device', 'cuda')
        # self.gradient_logs = {0:[], 1: []}
        self.logs = {'grad_0': [], 'grad_1': [], 'eps': [], 'acc_0': [], 'acc_1': [], 'all_acc': [], \
                     'grad_clf_all': []}
        self.logs['loss_0'] = []
        self.logs['loss_1'] = []
        self.logs['Delta_f1'] = []
        self.logs['Delta_f2'] = []
        self.logs['DI'] = []
        self.logs['TPR_1'] = []
        self.logs['TPR_0'] = []

    def write_logs(self, model):
        model.eval()
        bce_criterion = nn.BCELoss(reduce='mean')
        X_val = self.X_val
        if 'numpy' not in str(type(X_val)):
            X_val = X_val.values
        X_val = torch.FloatTensor(X_val).to(self.device)
        y_pred = model.predict(X_val)
        y_soft_pred_0, _ = model.forward(X_val[self.z_val == 0])
        y_soft_pred_1, _ = model.forward(X_val[self.z_val == 1])

        loss_0 = bce_criterion(y_soft_pred_0, torch.FloatTensor(self.y_val[self.z_val == 0]).to(self.device))

        loss_1 = bce_criterion(y_soft_pred_1, torch.FloatTensor(self.y_val[self.z_val == 1]).to(self.device))
        self.logs['loss_0'].append(loss_0.item())
        self.logs['loss_1'].append(loss_1.item())
        # y_pred = y_pred.detach().cpu().numpy()
        acc_0 = accuracy_score(self.y_val[self.z_val == 0], y_pred[self.z_val == 0])
        acc_1 = accuracy_score(self.y_val[self.z_val == 1], y_pred[self.z_val == 1])
        self.logs['acc_0'].append(copy.deepcopy(acc_0))
        self.logs['acc_1'].append(copy.deepcopy(acc_1))
        # print(acc_0, acc_1)
        all_acc = accuracy_score(self.y_val, y_pred)
        self.logs['all_acc'].append(copy.deepcopy(all_acc))
        ### DI score calc
        p1, p0 = y_pred[self.z_val == 1], y_pred[self.z_val == 0]
        p1 = float(np.sum(p1)) / float(len(p1))
        p0 = float(np.sum(p0)) / float(len(p0))
        self.logs['DI'].append(copy.deepcopy(abs(p1 - p0)))

        _, y_score_pred = model.forward(X_val)
        y_score_pred = y_score_pred.detach().cpu().numpy()
        delta_f1 = abs(np.mean(y_score_pred[self.z_val == 0]) - np.mean(y_score_pred[self.z_val == 1]))
        delta_f2 = abs(np.mean(y_score_pred[self.z_val == 0] ** 2) - np.mean(y_score_pred[self.z_val == 1] ** 2))
        self.logs['Delta_f1'].append(copy.deepcopy(delta_f1))
        self.logs['Delta_f2'].append(copy.deepcopy(delta_f2))

        #### TPR ###
        # print(np.max(y_pred), np.min(y_pred))
        p1 = y_pred[(self.y_val == 1) & (self.z_val == 1)]
        self.logs['TPR_1'].append(copy.deepcopy(np.sum(p1) / float(len(p1))))

        p0 = y_pred[(self.y_val == 1) & (self.z_val == 0)]
        self.logs['TPR_0'].append(copy.deepcopy(np.sum(p0) / float(len(p0))))

    def fit(self, options):
        torch.manual_seed(0)
        model = Net(options['model_params'])
        bce_criterion = nn.BCELoss(reduce='mean')
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-1)
        print(self.sigma, self.C)
        if options['dp']:
            privacy_engine = PrivacyEngine(
                model,
                batch_size=self.bs,
                sample_size=len(self.x_train),
                alphas=[1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64)),
                noise_multiplier=self.sigma,
                max_grad_norm=self.C
            )
            privacy_engine.attach(optimizer)
        if options['clip_norm']:
            clip_engine = PerSampleGradientClipper(model, max_norm=self.C)
            # start training
        for epoch in range(self.epochs):
            model.train()
            avg_grad_norm_list_0 = []
            avg_grad_norm_list_1 = []
            avg_grad_norm_list_all = []
            for x_train, y_train in self.train_loader:

                optimizer.zero_grad()
                x_train = x_train.to(self.device)
                z_train = x_train[:, self.input_size]
                x_train = x_train[:, :self.input_size]
                y_train = y_train.to(self.device)
                n_0, n_1 = float(len(y_train[z_train==0])), float(len(y_train[z_train==1]))
                if n_0 > 0 and n_1 > 0:
                    # get gradient info w.r.t avg loss of group z =0
                    output_0, _ = model(x_train[z_train == 0, :])
                    loss_0 = bce_criterion(output_0, y_train[z_train == 0])
                    loss_0.backward(retain_graph=True)
                    avg_grad_norm_0 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_0 += torch.norm(p.grad.data, 2)

                    avg_grad_norm_list_0.append(avg_grad_norm_0.item())
                    clear_backprops(model)
                    optimizer.zero_grad()

                    # get gradient info w.r.t avg loss of group z = 1.

                    output_1, _ = model(x_train[z_train == 1, :])
                    loss_1 = bce_criterion(output_1, y_train[z_train == 1])
                    loss_1.backward(retain_graph=True)
                    avg_grad_norm_1 = 0.0
                    for p in model.parameters():
                        avg_grad_norm_1 += torch.norm(p.grad.data, 2)

                    avg_grad_norm_list_1.append(avg_grad_norm_1.item())
                    clear_backprops(model)
                    optimizer.zero_grad()
                    output, _ = model(x_train)
                    loss = bce_criterion(output, y_train)
                    loss.backward()

                    # get gradient info of general (for the overall loss).

                    avg_grad_norm_all = 0.0
                    for p in model.parameters():
                        avg_grad_norm_all += torch.norm(p.grad.data, 2)
                    avg_grad_norm_list_all.append(avg_grad_norm_all.item())

                    if options['dp']:
                        epsilon, best_alpha = optimizer.privacy_engine.get_privacy_spent(options['delta'])
                        self.logs['eps'].append(epsilon)
                    if options['clip_norm']:
                        clip_engine.step()
                    optimizer.step()

            self.logs['grad_0'].append(copy.deepcopy(np.mean(avg_grad_norm_list_0)))
            self.logs['grad_1'].append(copy.deepcopy(np.mean(avg_grad_norm_list_1)))
            self.logs['grad_clf_all'].append(copy.deepcopy(np.mean(avg_grad_norm_list_all)))
            self.write_logs(model)

        self.model = model

        return

    def predict(self, X_test):
        self.model.eval()
        if 'numpy' not in str(type(X_test)):
            X_test = X_test.values
        X_test = torch.FloatTensor(self.scaler.transform(X_test)).to(self.device)
        X_test = X_test.to(self.device)
        return self.model.predict(X_test)