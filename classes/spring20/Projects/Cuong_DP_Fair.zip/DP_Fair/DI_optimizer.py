from utils import *
from network import *

class DI_Optimizer(object):
    def __init__(self, params):
        torch.manual_seed(0)
        self.y_val = params['y_val']
        self.z_val = params['z_val']
        self.bs = params.get('batch_size', 512)
        self.C = params['C']
        self.sigma = params['sigma']
        self.scaler = StandardScaler().fit(params['X_train'])
        self.x_train = self.scaler.transform(params['X_train'])
        self.X_val = self.scaler.transform(params['X_val'])
        self.input_size = self.X_val.shape[1]
        self.y_train = params['y_train']
        self.z_train = params['z_train']
        train_tensor = TensorDataset(Tensor(np.c_[self.x_train, self.z_train]), Tensor(self.y_train))
        self.train_loader = DataLoader(dataset=train_tensor, batch_size=self.bs, shuffle=False)
        self.epochs = params.get('epochs', 50)
        self.device = params.get('device', 'cpu')
        # self.gradient_logs = {0:[], 1: []}
        self.logs = {'di-score': [], 'all_acc': [], 'acc_0': [], 'acc_1': [], 'delta_f': [], 'grad_clf_loss': [], \
                     'grad_delta_f_after': [], 'eps': [], 'loss_0': [], 'loss_1': [], 'lambda': [], \
                     'grad_delta_f_before': []}

    def write_logs(self, model):
        model.eval()
        bce_criterion = nn.BCELoss(reduce='mean')
        X_val = self.X_val
        if 'numpy' not in str(type(X_val)):
            X_val = X_val.values
        X_val = torch.FloatTensor(X_val).to(self.device)
        y_pred = model.predict(X_val)
        y_soft_pred_0, _ = model.forward(X_val[self.z_val == 0])
        y_soft_pred_1, _ = model.forward(X_val[self.z_val == 1])

        loss_0 = bce_criterion(y_soft_pred_0, torch.FloatTensor(self.y_val[self.z_val == 0]).to(self.device))

        loss_1 = bce_criterion(y_soft_pred_1, torch.FloatTensor(self.y_val[self.z_val == 1]).to(self.device))
        self.logs['loss_0'].append(loss_0.item())
        self.logs['loss_1'].append(loss_1.item())
        # y_pred = y_pred.detach().cpu().numpy()
        acc_0 = accuracy_score(self.y_val[self.z_val == 0], y_pred[self.z_val == 0])
        acc_1 = accuracy_score(self.y_val[self.z_val == 1], y_pred[self.z_val == 1])
        self.logs['acc_0'].append(copy.deepcopy(acc_0))
        self.logs['acc_1'].append(copy.deepcopy(acc_1))
        # print(acc_0, acc_1)
        all_acc = accuracy_score(self.y_val, y_pred)
        self.logs['all_acc'].append(copy.deepcopy(all_acc))
        ### DI score calc
        p1, p0 = y_pred[self.z_val == 1], y_pred[self.z_val == 0]
        p1 = float(np.sum(p1)) / float(len(p1))
        p0 = float(np.sum(p0)) / float(len(p0))
        self.logs['di-score'].append(copy.deepcopy(abs(p1 - p0)))

        _, y_score_pred = model.forward(X_val)
        y_score_pred = y_score_pred.detach().cpu().numpy()
        delta_f1 = abs(np.mean(y_score_pred[self.z_val == 0]) - np.mean(y_score_pred[self.z_val == 1]))
        delta_f2 = abs(np.mean(y_score_pred[self.z_val == 0] ** 2) - np.mean(y_score_pred[self.z_val == 1] ** 2))
        self.logs['delta_f'].append(copy.deepcopy(delta_f1))

    def get_grad(self, model, options):
        # extract gradient from model
        w_dict = {}
        for name, p in model.named_parameters():
            if not options['dp']:
                w_dict[name] = p.grad.data  # consider p.grad.data here
            else:
                print('adding noise !')
                w_dict[name] = p.grad.data + torch.FloatTensor(p.grad.shape).normal_(0, self.sigma * self.C)
        return copy.deepcopy(w_dict)

    def fit(self, options):
        torch.manual_seed(20)
        model = Net(options['model_params'])
        bce_criterion = nn.BCELoss(reduce='mean')
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-1)
        lambda_ = options['lambda_']
        mult_lr = options.get('mult_lr', 0.2)
        if options['clip_norm'] or options['dp']:
            clip_engine = PerSampleGradientClipper(model, max_norm=self.C)

        for epoch in range(self.epochs):
            model.train()
            violation_list = []
            avg_grad_norm_list_delta_f_before = []
            avg_grad_norm_list_delta_f_after = []
            avg_grad_norm_list_clf = []
            violation_list = []

            for x_train, y_train in self.train_loader:

                x_train = x_train.to(self.device)
                z_train = x_train[:, self.input_size]
                x_train = x_train[:, :self.input_size]
                y_train = y_train.to(self.device)
                if (len(z_train[z_train == 0]) > 0) and (len(z_train[z_train == 1]) > 0):
                    clear_backprops(model)
                    optimizer.zero_grad()
                    output, score_func = model(x_train)
                    f11, f10 = torch.mean(score_func[z_train == 1]), torch.mean(score_func[z_train == 0])

                    delta_f = torch.abs(f11 - f10)
                    delta_f.backward(retain_graph=True)
                    violation_list.append(delta_f.item())
                    avg_grad_norm_delta_f_before = 0.0
                    for p in model.parameters():
                        avg_grad_norm_delta_f_before += copy.deepcopy(torch.norm(p.grad.data, 2))

                    avg_grad_norm_list_delta_f_before.append(copy.deepcopy(avg_grad_norm_delta_f_before.item()))
                    ###########
                    if options['clip_norm'] or options['dp']:
                        clear_backprops(model)
                        optimizer.zero_grad()
                        output, score_func = model(x_train)
                        f11, f10 = torch.mean(score_func[z_train == 1]), torch.mean(score_func[z_train == 0])

                        delta_f = torch.abs(f11 - f10)
                        delta_f.backward(retain_graph=True)
                        clip_engine.step()
                        avg_grad_norm_delta_f_after = 0.0
                        for p in model.parameters():
                            avg_grad_norm_delta_f_after += copy.deepcopy(torch.norm(p.grad.data, 2))

                        avg_grad_norm_list_delta_f_after.append(copy.deepcopy(avg_grad_norm_delta_f_after.item()))

                    w_add_dict = self.get_grad(model, options)

                    # clear_backprops(model)
                    output, score_func = model(x_train)
                    clf_loss = bce_criterion(output, y_train)

                    clf_loss.backward()

                    avg_grad_norm_clf = 0.0
                    for name, p in model.named_parameters():
                        avg_grad_norm_clf += copy.deepcopy(torch.norm(p.grad.data, 2))
                        if name in w_add_dict.keys():
                            p.grad.data += lambda_ * w_add_dict[name]  # add gradient of the first moment matching term
                        else:
                            pass

                    avg_grad_norm_list_clf.append(avg_grad_norm_clf)

                    optimizer.step()

            lambda_ += mult_lr * np.mean(violation_list)
            # print(copy.deepcopy(np.mean(avg_grad_norm_list_delta_f)))
            self.logs['lambda'].append(copy.deepcopy(lambda_))
            self.logs['grad_delta_f_after'].append(copy.deepcopy(np.mean(avg_grad_norm_list_delta_f_after)))
            self.logs['grad_delta_f_before'].append(copy.deepcopy(np.mean(avg_grad_norm_list_delta_f_before)))
            self.logs['grad_clf_loss'].append(copy.deepcopy(np.mean(avg_grad_norm_list_clf)))
            self.write_logs(model)
            # print(lambda_)

        self.model = model

        return