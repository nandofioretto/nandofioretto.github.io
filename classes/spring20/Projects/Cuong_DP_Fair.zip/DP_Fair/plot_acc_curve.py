import matplotlib.pyplot as plt

f, axes = plt.subplots(figsize=(12, 6), nrows=2, ncols=3, sharex=True, sharey='row')
dataset_list = ['bank', 'default', 'compas']

eps_list = np.asarray([0.1, 1, 10, 100])
for i in range(6):
    r, c = int(i / 3), int(i % 3)

    curr_ax = axes[r][c]
    mean_acc0_list = []
    mean_acc1_list = []
    if r == 0:
        for eps in eps_list:
            mean_acc0_list.append(round(np.mean(res[dataset_list[c]][eps]['obj']['acc_0']), 4))
            mean_acc1_list.append(round(np.mean(res[dataset_list[c]][eps]['obj']['acc_1']), 4))
    else:
        for eps in eps_list:
            mean_acc0_list.append(round(np.mean(res[dataset_list[c]][eps]['output']['acc_0']), 4))
            mean_acc1_list.append(round(np.mean(res[dataset_list[c]][eps]['output']['acc_1']), 4))

    curr_ax.plot(np.log10(eps_list), mean_acc0_list, marker='o', linestyle='dashed', label='group z=0')
    curr_ax.plot(np.log10(eps_list), mean_acc1_list, marker='o', linestyle='dashed', label='group z=1')
    curr_ax.set_xlabel('Epsilon(in Log 10 Scale)')
    curr_ax.set_ylabel('Accuracy')
    curr_ax.legend()
    if r == 0:
        curr_ax.set_title('Objective Perturb for ' + dataset_list[c])
    else:
        curr_ax.set_title('Output Perturb for ' + dataset_list[c])

    curr_ax.legend()

plt.tight_layout()
# plt.subplots_adjust(hspace=0.4)
# plt.subplots_adjust(vspace=0.4)

# f.suptitle(data)
plt.show()