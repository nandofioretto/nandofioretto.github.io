#!/bin/bash
ipynb-py-convert EvaluateUserCF.py EvaluateUserCF.ipynb
ipynb-py-convert EvaluationData.py EvaluationData.ipynb
ipynb-py-convert Evaluator.py Evaluator.ipynb
ipynb-py-convert KNNBakeOff.py KNNBakeOff.ipynb
ipynb-py-convert MovieLens.py MovieLens.ipynb
ipynb-py-convert RecommenderMetrics.py RecommenderMetrics.ipynb
ipynb-py-convert SimpleItemCF.py SimpleItemCF.ipynb
ipynb-py-convert SimpleUserCF.py SimpleUserCF.ipynb
